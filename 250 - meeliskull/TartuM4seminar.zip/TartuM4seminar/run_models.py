import sys
import os
import multiprocessing as mp
from tqdm import tqdm

from utmodels.Fearless import Fearless5
from utmodels import naive1
from utmodels import naive2
from utmodels.RandomF import randomforest1
from utmodels.RandomF import xgboost1
from utmodels.RandomF import xgboost2
from utmodels.RandomF.arimapreprocessed import RandomF_arima_preprocessed
# TODO: Add your model here


result_path = {'holdout': 'results_models/holdout',
               'test':    'results_models/test',
               'root':    'results_models'}

models = {
          # Fearless5.MODEL_NAME : Fearless5.main,
          naive1.MODEL_NAME: naive1.main,
          naive2.MODEL_NAME: naive2.main,
          RandomF_arima_preprocessed.MODEL_NAME: RandomF_arima_preprocessed.main
          # TODO: add your model_name and main function here 
          }
 

def placeholder(args):
    i, (model_name, model_main) = args
    tqdminfo = {'position': i, 'desc': model_name}
    model_main(dataset_path='datasets', result_path=result_path,
            validation_cut='full', tqdm_info=tqdminfo)
    return True


if __name__ == "__main__":
    sys.path.append(os.getcwd())
   
    # For debug:
    # Fearless5.main(dataset_path='datasets', result_path='results_models', \
                   # validation_cut='full')

    # naive1.main(dataset_path='datasets', result_path=result_path, \
                   # validation_cut='full')

    # naive2.main(dataset_path='datasets', result_path='results_models', \
                   # validation_cut='full')

    # randomforest1.main(dataset_path='datasets', result_path='results_models', \
                   # validation_cut='full')

    nr_cpu = 1 # TODO: argument parser
    with mp.Pool(processes=nr_cpu) as pool:
        list(tqdm(pool.map(placeholder, enumerate(models.items())), total=len(models)))
