# Datasets

Some information about the directory and the validation dataset generation
