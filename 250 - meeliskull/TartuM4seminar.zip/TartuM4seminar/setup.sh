#!/bin/bash

echo 'create results directories..'
mkdir -p results_models/holdout/ results_models/test/ results_models/naive results_models/correlations
mkdir -p results_final

# download necessary datasets
echo -e 'downloading the M4 dataset..\n'
#M4DataSet_path='https://www.m4.unic.ac.cy/wp-content/uploads/2017/12/M4DataSet.zip'
#M4Info_path='https://www.m4.unic.ac.cy/wp-content/uploads/2017/12/M4-info.csv'
M4DataSet_path="https://www.dropbox.com/s/fxx1pz4mprgzofg/M4DataSet.zip?dl=1"
M4Info_path="https://www.dropbox.com/s/wtxcdls0kjwhqgc/M4-info.csv?dl=1"
if ! [ -f datasets/M4DataSet.zip ]; then
  curl -L -o datasets/M4DataSet.zip ${M4DataSet_path}
fi
if ! [ -f datasets/M4-info.zip ]; then
  curl -L -o datasets/M4-info.csv ${M4Info_path} 
fi


# download validation set?
echo -e "\n"
read -p "Would you like to download pre-generated holdout dataset (Y/n)?" input1
if [[ $input1 == "Y" || $input1 == "y" ]]; then
  echo ' You chose yes'; 
  echo -e ' Downloading..\n'; 
  #file_id="1ptuVw5dnsbnXAT4Y6Ki17AiZHSlNW0G0"
  # "https://drive.google.com/uc?export=download&id=$file_id"
  holdoutset_path="https://www.dropbox.com/s/5a7d7p9wpr9zmmh/cut.zip?dl=1"
  curl -L -o datasets/cut.zip $holdoutset_path
else
  echo ' You chose no!'; 
  echo ' You can generate the validation set using the code provided in the /datasets';
fi

# download result of models
echo -e "\n"
read -p "Would you like to download previously obtained results of the models (Y/n)?" input2
if [[ $input2 == "Y" || $input2 == "y" ]]; then
  echo ' You chose yes'; 
  echo -e ' Downloading..\n'; 
  curl -L -o results_models/utmodels_results_full.zip "https://www.dropbox.com/s/mmzsiw3f3ak1eqt/utmodels_results.zip?dl=1"
else
  echo ' You chose no!'; 
  echo " You can run all models using 'run_models.py'";
fi

echo -e "\n"
read -p "Would you like the downloaded zip files to be removed after extraction (Y/n)?" remove

if [[ $remove == "Y" || $remove == "y" ]]; then
  remove=1
fi

# unzip downloaded files
#echo -e '\nunzipping..'
cd datasets
unzip M4DataSet.zip -d M4DataSet
unzip cut.zip

# cleanup
echo 'cleaning..'
if [[ $remove == 1 ]]; then
  rm M4DataSet.zip
fi

if [[ $input1 == "Y" || $input1 == "y" && $remove == 1 ]]; then
  rm cut.zip
fi

 #result of models (unzip and cleanup)
cd ../results_models
unzip utmodels_results_full.zip
if [[ $input2 == "Y" || $input2 == "y" && $remove == 1 ]]; then
  rm utmodels_results_full.zip
fi

echo 'done!'
