#!/bin/bash

# cleanup datasets
read -p "Cleanup datasets directory (Y/n)?" input
if [[ $input == "Y" || $input == "y" ]]; then
  echo ' You chose yes'; 
  rm -rvf datasets/cut datasets/M4DataSet datasets/*.zip datasets/*.csv
else
  echo ' You chose no!'; 
fi

echo -e "\n"
# cleanup models results
read -p "Cleanup results_models directory (Y/n)?" input
if [[ $input == "Y" || $input == "y" ]]; then
  echo ' You chose yes'; 
  rm -rvf results_models/
else
  echo ' You chose no!'; 
fi

echo -e "\n"
# cleanup ensembles results
read -p "Cleanup results_final directory (Y/n)?" input
if [[ $input == "Y" || $input == "y" ]]; then
  echo ' You chose yes'; 
  rm -rvf results_final/
else
  echo ' You chose no!'; 
fi
