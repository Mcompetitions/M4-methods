# M4UT

This repository contains final models used for submitting forcasts to the M4 Competition.
 
## Models

- [Naive1/Naive2](utmodels/)
- [XGBoost](utmodels/RandomF/XGBoost2)
- [ARIMA](utmodels/RF/arima)
- [ETS](utmodels/RF/ets)
- [LightGBM](utmodels/TeamPotap)
- Other:
  - [Stupidity](utmodels/TeamKaur/stupidity)
  - [Correlator](utmodels/TeamKaur/correlator)
  - [Fearless](utmodels/Fearless/)
  
  
## Configuration and setup

```setup.py``` downloads and prepares the project. Downloading: 

- Original M4 datasets (```M4DataSet.zip``` and ```M4-info.csv```)
- pre-generated holdout dataset (alternatively can be generated using the provided notebook)
- Results of above mentioned models (alternatively can be obtained by running each model)

To install required packages:

```
pip install -r requirements.txt
```

Some of the codes are in Jupyter-notebook, hence you'll need to have that too.
Simply run ```./run_jupyternb.sh``` to open the notebook in project path.


## Holdout dataset for validation

A hold-out dataset is generated with different sizes to evaluate and help
development of the models. This holdout dataset is used for the forecasting
as well as the ensembling procedures. You can either download and use
the pre-generated holdout set or you can use the [notebook](datasets/Dataset.ipynb) 
provided to generate the hold-out set. 

## Running Models and Ensembling

Models should be run individually to produce the results.

At the moment ```run_models.py``` only runs 3 of them in parallel.

You can either download the obtained results for each model, both on the
holdout and the test sets or run all models using above command or 
execute each individually to reproduce the results. 

Produced results are ensembled using another set of codes provided in the 
```ensembles``` directory. It needs the models' results to be available beforehand. 
If you are particularly interested in the ensembling process you can download the previously obtained results for each model 
and run the ensembling codes righaway. Otherwise, you can run each model
 separately or use [run_models.py](run_models.py) to run them all (not all models included). 
 Models can be run on parallel on multiple CPUs.


## Visualization

Results obtaine for the holdout dataset can be visualized using 
our [visualization tool](http://172.17.65.170/shiny/m4viz/).

### Note
- scrips are tested on Debian 9.0 amd64
