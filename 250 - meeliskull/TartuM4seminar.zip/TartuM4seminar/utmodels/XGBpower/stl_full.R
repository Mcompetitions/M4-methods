library(readr)
library(dplyr)
library(plotly)
library(forecast)

### Load full train dataset
Daily_train <- read_csv("dataset/full/train/Daily.csv")
Hourly_train <- read_csv("dataset/full/train/Hourly.csv")
Monthly_train <- read_csv("dataset/full/train/Monthly.csv")
Quarterly_train <- read_csv("dataset/full/train/Quarterly.csv")
Weekly_train <- read_csv("dataset/full/train/Weekly.csv")
Yearly_train <- read_csv("dataset/full/train/Yearly.csv")

### Load full test dataset
Daily_test <- read_csv("dataset/full/test/Daily.csv")
Hourly_test <- read_csv("dataset/full/test/Hourly.csv")
Monthly_test <- read_csv("dataset/full/test/Monthly.csv")
Quarterly_test <- read_csv("dataset/full/test/Quarterly.csv")
Weekly_test <- read_csv("dataset/full/test/Weekly.csv")
Yearly_test <- read_csv("dataset/full/test/Yearly.csv")

### Load validation train dataset
Daily_val_train <- read_csv("dataset/full/val/train/Daily.csv")
Hourly_val_train <- read_csv("dataset/full/val/train/Hourly.csv")
Monthly_val_train <- read_csv("dataset/full/val/train/Monthly.csv")
Quarterly_val_train <- read_csv("dataset/full/val/train/Quarterly.csv")
Weekly_val_train <- read_csv("dataset/full/val/train/Weekly.csv")
Yearly_val_train <- read_csv("dataset/full/val/train/Yearly.csv")

### Load validation test dataset
Daily_val_test <- read_csv("dataset/full/val/test/Daily.csv")
Hourly_val_test <- read_csv("dataset/full/val/test/Hourly.csv")
Monthly_val_test <- read_csv("dataset/full/val/test/Monthly.csv")
Quarterly_val_test <- read_csv("dataset/full/val/test/Quarterly.csv")
Weekly_val_test <- read_csv("dataset/full/val/test/Weekly.csv")
Yearly_val_test <- read_csv("dataset/full/val/test/Yearly.csv")

sMAPE <- function(y,y_hat){
    return(mean(200*abs(y-y_hat)/(abs(y)+abs(y_hat))))
}

MASE <- function(y,y_hat,m){
    return(mean(abs(y-y_hat))/mean(abs(y[(m+1):length(y)]-y[1:(length(y)-m)])))
}

Make_all_forecasts <- function(train_data,test_data,val_train_data,val_test_data,h,freq){
    rows <- lapply(train_data$V1,function(id){
        print(id)
        
        # validation train timeseries
        timeseries <- c(val_train_data[val_train_data$V1==id,-1])
        timeseries <- as.numeric(timeseries[!is.na(timeseries)])
        timeseries_intfreq <- ts(timeseries,frequency = round(freq,0))
        timeseries <- ts(timeseries,frequency = freq)
        
        # validation test data
        val_ts <-  as.numeric(val_test_data[val_train_data$V1==id,])
        
        # full test data
        test_ts <- as.numeric(test_data[train_data$V1==id,])
        
        # full train data timeseries
        full_ts <- c(train_data[train_data$V1==id,-1])
        full_ts <- as.numeric(full_ts[!is.na(full_ts)])
        
        # ALL DATA TIMESERIES
        ALL_ts <- c(full_ts,test_ts)
        
        # Making ts for full train    
        full_ts_intfreq <- ts(full_ts,frequency = round(freq,0))
        full_ts <- ts(full_ts,frequency = freq)
        
        # Making ts for ALL DATA    
        ALL_ts_intfreq <- ts(ALL_ts,frequency = round(freq,0))
        ALL_ts <- ts(ALL_ts,frequency = freq)
        
        # build models on val_train data
        model_arima <- auto.arima(timeseries,seasonal = T)
        model_ets <- ets(timeseries)
        model_stl_ets <- tryCatch({
            stlm(timeseries_intfreq,method="ets")
        },
        error=function(cond) {
            message(paste("Err: ETS_stl does not work, returning null. len(ts)=",
                          length(timeseries)))
            return(NULL)
        })
        model_stl_arima <- tryCatch({
            stlm(timeseries_intfreq,method="arima")
        },
        error=function(cond) {
            message(paste("Err: ARIMA_stl does not work, returning null. len(ts)=",
                          length(timeseries)))
            return(NULL)
        })
        model_stl_thetaf <- tryCatch({
            stlm(timeseries_intfreq,modelfunction=thetaf)
        },
        error=function(cond) {
            message(paste("Err: Theta_stl does not work, returning null. len(ts)=",
                          length(timeseries)))
            return(NULL)
        })
        
        # predict on val_test data
        pred_arima <- forecast(model_arima,h=h)$mean
        pred_ets <- forecast(model_ets,h=h)$mean
        pred_stl_ets <- tryCatch({
            forecast(model_stl_ets,h=h)$mean
        },
        error=function(cond) {
            message("Err: ETS does not work, returning null")
            return(NULL)
        })
        pred_stl_arima <- tryCatch({
            forecast(model_stl_arima,h=h)$mean
        },
        error=function(cond) {
            message("Err: ARIMA does not work, returning null")
            return(NULL)
        })
        pred_stl_theta <- tryCatch({
            forecast(model_stl_thetaf,h=h)$mean
        },
        error=function(cond) {
            message("Err: Theta does not work, returning null")
            return(NULL)
        })
        
        # select best model
        pred_list <- list(pred_arima,pred_ets,pred_stl_ets,
                          pred_stl_arima,pred_stl_theta)
        val_smape <- sapply(pred_list,function(x) sMAPE(as.numeric(x),val_ts))
        best_model_num <- which.min(val_smape)
        
        # retrain on whole train data
        final_model <- switch(best_model_num,
                              Arima(full_ts,model=model_arima),
                              ets(full_ts,model=model_ets,use.initial.values=TRUE),
                              stlm(full_ts_intfreq,model=model_stl_ets),
                              stlm(full_ts_intfreq,model=model_stl_arima),
                              stlm(full_ts_intfreq,modelfunction=thetaf,model=model_stl_thetaf))
        
        # retrain on ALL data
        final_model_ALLDATA <- switch(best_model_num,
                              Arima(ALL_ts,model=model_arima),
                              ets(ALL_ts,model=model_ets,use.initial.values=TRUE),
                              stlm(ALL_ts_intfreq,model=model_stl_ets),
                              stlm(ALL_ts_intfreq,model=model_stl_arima),
                              stlm(ALL_ts_intfreq,modelfunction=thetaf,model=model_stl_thetaf))
        
        # make predictions for test dataset
        final_pred <- forecast(final_model,h=h)$mean
        
        # make predictions for ALL DATA
        final_pred_ALLDATA <- forecast(final_model_ALLDATA,h=h)$mean
        
        return(c(id,as.numeric(final_pred),as.numeric(final_pred_ALLDATA),best_model_num))
    })
    
    df <- do.call("rbind.data.frame",rows)
    Houldout_pred <- df[,1:(ncol(df)/2)]
    colnames(Houldout_pred) <- c("name",seq(ncol(Houldout_pred$DF)-1))
    Submit_pred <- df[,c(1,(ncol(df)/2+1):(ncol(df)-1))]
    colnames(Submit_pred) <- c("name",seq(ncol(Submit_pred$DF)-1))
    return(list(Houldout_pred = Houldout_pred,
                Submit_pred = Submit_pred))
                #,Model = unlist(df[,ncol(df)])))
}

Hourly_forecasts_list <- Make_all_forecasts(Hourly_train, Hourly_test, Hourly_val_train, Hourly_val_test, h=48,freq=24)
saveRDS(Hourly_forecasts_list,"Hourly_forecasts_stl_full.RDS")
Hourly_forecasts_holdout <- Hourly_forecasts_list$Houldout_pred
Hourly_forecasts_submit <- Hourly_forecasts_list$Submit_pred
#Hourly_models <- Hourly_forecasts_list$Model
write.csv(Hourly_forecasts_holdout,"Hourly_XGBpower_stl_holdout.csv",row.names = F,quote = F,na = "")
write.csv(Hourly_forecasts_submit,"Hourly_XGBpower_stl_submit.csv",row.names = F,quote = F,na = "")

Weekly_forecasts_list <- Make_all_forecasts(Weekly_train, Weekly_test, Weekly_val_train, Weekly_val_test, h=13,freq=4.357)
saveRDS(Weekly_forecasts_list,"Weekly_forecasts_stl_full.RDS")
Weekly_forecasts_holdout <- Weekly_forecasts_list$Houldout_pred
Weekly_forecasts_submit <- Weekly_forecasts_list$Submit_pred
#Weekly_models <- Weekly_forecasts_list$Model
write.csv(Weekly_forecasts_holdout,"Weekly_XGBpower_stl_holdout.csv",row.names = F,quote = F,na = "")
write.csv(Weekly_forecasts_submit,"Weekly_XGBpower_stl_submit.csv",row.names = F,quote = F,na = "")

Daily_forecasts_list <- Make_all_forecasts(Daily_train, Daily_test, Daily_val_train, Daily_val_test, h=14,freq=7)
saveRDS(Daily_forecasts_list,"Daily_forecasts_stl_full.RDS")
Daily_forecasts_holdout <- Daily_forecasts_list$Houldout_pred
Daily_forecasts_submit <- Daily_forecasts_list$Submit_pred
#Daily_models <- Daily_forecasts_list$Model
write.csv(Daily_forecasts_holdout,"Daily_XGBpower_stl_holdout.csv",row.names = F,quote = F,na = "")
write.csv(Daily_forecasts_submit,"Daily_XGBpower_stl_submit.csv",row.names = F,quote = F,na = "")

Yearly_forecasts_list <- Make_all_forecasts(Yearly_train, Yearly_test, Yearly_val_train, Yearly_val_test, h=6,freq=2)
saveRDS(Yearly_forecasts_list,"Yearly_forecasts_stl_full.RDS")
Yearly_forecasts_holdout <- Yearly_forecasts_list$Houldout_pred
Yearly_forecasts_submit <- Yearly_forecasts_list$Submit_pred
#Yearly_models <- Yearly_forecasts_list$Model
write.csv(Yearly_forecasts_holdout,"Yearly_XGBpower_stl_holdout.csv",row.names = F,quote = F,na = "")
write.csv(Yearly_forecasts_submit,"Yearly_XGBpower_stl_submit.csv",row.names = F,quote = F,na = "")

Quarterly_forecasts_list <- Make_all_forecasts(Quarterly_train, Quarterly_test, Quarterly_val_train, Quarterly_val_test, h=8,freq=4)
saveRDS(Quarterly_forecasts_list,"Quarterly_forecasts_stl_full.RDS")
Quarterly_forecasts_holdout <- Quarterly_forecasts_list$Houldout_pred
Quarterly_forecasts_submit <- Quarterly_forecasts_list$Submit_pred
#Quarterly_models <- Quarterly_forecasts_list$Model
write.csv(Quarterly_forecasts_holdout,"Quarterly_XGBpower_stl_holdout.csv",row.names = F,quote = F,na = "")
write.csv(Quarterly_forecasts_submit,"Quarterly_XGBpower_stl_submit.csv",row.names = F,quote = F,na = "")

Monthly_forecasts_list <- Make_all_forecasts(Monthly_train, Monthly_test, Monthly_val_train, Monthly_val_test, h=18,freq=12)
saveRDS(Monthly_forecasts_list,"Monthly_forecasts_stl_full.RDS")
Monthly_forecasts_holdout <- Monthly_forecasts_list$Houldout_pred
Monthly_forecasts_submit <- Monthly_forecasts_list$Submit_pred
#Monthly_models <- Monthly_forecasts_list$Model
write.csv(Monthly_forecasts_holdout,"Monthly_XGBpower_stl_holdout.csv",row.names = F,quote = F,na = "")
write.csv(Monthly_forecasts_submit,"Monthly_XGBpower_stl_submit.csv",row.names = F,quote = F,na = "")
