# Fearless5 seasonal decomposition and fitting to the trend and residuals with
# linear, exponential and sinusoidal curves

plots_on = False # to turn the plots on or off

import sys, os
from os.path import join
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt
from random import randrange
from pandas import Series
from statsmodels.tsa.seasonal import seasonal_decompose
import itertools
from argparse import ArgumentParser
from tqdm import tqdm

# TODO: use a common tools for following functions

# class Fearless5:
def smape(a, b):
    """
    Calculates sMAPE

    :param a: actual values
    :param b: predicted values
    :return: sMAPE
    """
    a = a.reshape((-1,))
    b = b.reshape((-1,))
    return np.mean(2.0 * np.abs(a - b) / (np.abs(a) + np.abs(b))).item()


def mase(insample, y_test, y_hat_test, freq):
    """
    Calculates MAsE

    :param insample: insample data
    :param y_test: out of sample target values
    :param y_hat_test: predicted values
    :param freq: data frequency
    :return:
    """
    y_hat_naive = []
    for i in range(freq, len(insample)):
        y_hat_naive.append(insample[(i - freq)])

    masep = np.mean(abs(insample[freq:] - y_hat_naive))

    return np.mean(abs(y_test - y_hat_test)) / masep


def load_serie_info(m4info, ts_id):
    ts_info = m4info[m4info['M4id'] == ts_id] # get m4info of this serie
    fh = ts_info['Horizon'].values[0]         # forecasting horizon
    freq = ts_info['Frequency'].values[0]     # data frequency
    return fh, freq


def func_lin(x, a, b, c):
    return a*x + b


def func_exp(x, a, b, c):
    return a * np.exp(-b * x) + c


def my_sin(x, freq, amplitude, phase, offset):
    return np.sin(x * freq + phase) * amplitude + offset


def fit_trend(serie, func='lin'):
    tss = serie
    x = np.linspace(0,len(tss),len(tss))
    if func == 'exp':
        popt, pcov = curve_fit(func_exp, x, tss, maxfev= 10000)
        if plots_on:
            plt.plot(x, func_exp(x, *popt), 'r-', label="Fitted Curve")
            plt.plot(serie)
            plt.title('exponential fitting to the trend')
    else: 
        popt, pcov = curve_fit(func_lin, x, tss, maxfev= 10000)
        if plots_on:
            plt.plot(x, func_lin(x, *popt), 'r-', label="Fitted Curve")
            plt.plot(serie)
            plt.title('linear fitting to the trend')
    if plots_on:
        plt.show()
    return popt
    

def fit_resid(data, freq):
    # N = 1000 # number of data points
    N = data.shape[0]
    t = np.linspace(0, 4*np.pi, N)
    # data = 3.0*np.sin(t+0.001) + 0.5 + np.random.randn(N) # create artificial data with noise

    guess_freq = freq 
    guess_amplitude = 3*np.std(data)/(2**0.5)
    guess_phase = 0
    guess_offset = np.mean(data)

    p0=[guess_freq, guess_amplitude,
        guess_phase, guess_offset]

    # now do the fit
    fit = curve_fit(my_sin, t, data, p0=p0, maxfev=10000)

    # we'll use this to plot our first estimate. This might already be good enough for you
    data_first_guess = my_sin(t, *p0)

    # recreate the fitted curve using the optimized parameters
    data_fit = my_sin(t, *fit[0])

    if plots_on:
        plt.plot(data, '.')
        plt.plot(data_fit, label='after fitting')
        plt.plot(data_first_guess, label='first guess')
        plt.title('fitting to the residuals')
        plt.legend()
        plt.show()

    fh_range = range(len(data), len(data)+fh)
    if plots_on:
        plt.plot(fh_range,data)
        plt.plot(fh_range, my_sin(fh_range, *fit[0]))
        plt.show()
    
    return fit[0]


# Fitting Process
def fearless5(train, m4info, test=None, datasets = [], verbose=True, variation_pick={}, start_row=-1, tqdm_info=None):
    """using linear, exponential and sinosoidal fittings on seasonal decomposition of the ts
    Args:
        train (dict): a dictionary datasets (i.e. Yearly) and timeseries of each (ie. Y1, .., Y23000)
        test (dict): if there is a hold-out dataset to measure the accuracy with
        datasets (dict): datasets to be consider - the list must contain the keys existing in train and test dictionaries
        verbose (bool): whether to print some of the debugging/informative information
        variation_pick (dict): based on performance on hold-out id of best prediction variation can be obtained...
                        which is useful for the final submission otherwise a default variation is chosen! (recommended)
        start_row (int): start prediction for this row onwards from 
    Returns:
        preds (dict): predictions with each ts 
        id_of_bests (dict): id of best prediction to be used for each ts
    """
    
    preds = {} # the predictions itself
    id_of_bests = {} # keep track of combination of predictions used
    if datasets:
        dsets = [d for d in train.keys() if d in datasets]
    else:
        dsets = [d for d in train.keys()]
    #print("picked dataset(s) : ", dsets)
    #print("starting row: ", start_row)
    # progress bar
    total=0
    for d in dsets:
        total+=train[d].shape[0]
    pbar = tqdm(total=total, position=tqdm_info['position'], desc=tqdm_info['desc'])
    try:
        for d in dsets:
            # print(d)
            for i, row in train[d].iterrows():
                if pbar:
                    pbar.update(1)
                if i < start_row:
                    continue
                    
                ts_id = row['V1']
                # print(type(ts_id))
                # print(variation_pick.keys())
                fh, freq = load_serie_info(m4info, ts_id)
                if freq == 1:
                    freq=2 # hack for better decomposition, affects yearly and hourly
                
                if verbose:
                    print(ts_id)
                    print(fh, freq)

                tr = row[1:].dropna().astype('float')
                if test is not None:
                    te = test[d].iloc[i,1:]

                #plt.plot(range(len(tr)), tr)
                #plt.plot(range(len(tr), len(tr)+len(te)), te)
                #plt.show()

                result = seasonal_decompose(tr.dropna().tolist(), model='add', freq=freq, two_sided=False)
                if plots_on:
                    result.plot()
                    plt.show()

                chop = fh
                resid = result.resid[-chop:]
                trend = result.trend[-chop:]
                resid[np.isnan(resid)] = 0
                trend[np.isnan(trend)] = 0

                # make forecast
                fh_range = range(chop, chop+fh)
                trend_pred = None
                resid_pred = None
                seasonal_pred = result.seasonal[-fh:]

                # fitting trend
                trend_coef = fit_trend(trend, func='lin')
                trend_pred = func_lin(fh_range, *trend_coef)
                try:
                    trend_coef2 = fit_trend(trend, func='exp')
                    trend_pred2 = func_exp(fh_range, *trend_coef)
                except:
                    trend_coef2 = fit_trend(trend, func='lin')
                    trend_pred2 = func_lin(fh_range, *trend_coef)

                # fitting residuals
                try:
                    resid_coef = fit_resid(resid, freq)
                    resid_pred = my_sin(fh_range, *resid_coef)
                except:
                    resid_coef = fit_trend(resid, func='lin')
                    resid_pred = func_lin(fh_range, *resid_coef)
                resid_coef = fit_trend(resid, func='lin')
                resid_pred2 = func_lin(fh_range, *resid_coef)

                # calculate different possible combination of predictions
                trends = [trend_pred, trend_pred2, result.trend[-fh:]]
                resids = [resid_pred, resid_pred2, result.resid[-fh:]]
                y_hats = []
                for t in trends:
                    for r in resids:
                        y_hats.append(t+r+seasonal_pred)

                # calculate error basd on hold-out
                errors = [] 
                if test: 
                    for yhat in y_hats:
                        errors.append( mase(tr[-fh:], te, yhat, 1) )
                    id_of_bests[ts_id] = np.argmin(errors)
                    
                # pick the prediction
                if errors:
                    yhat = y_hats[np.argmin(errors)]
                elif ts_id in variation_pick.keys(): # based on previous hold-out experience
                    yhat = y_hats[variation_pick[ts_id]]
                else:
                    print(ts_id, "Caution: better to pick based on variation_pick for final submission!")
                    yhat = y_hats[0]
                
                # store the prediction
                preds[str(row[0])] = yhat

                # plot the print final result 
                if test is not None:
                    smape_err = smape(te, yhat)
                    mase_err = mase(tr[-fh:], te, yhat, 1) # only for yearly freq=1
                    if verbose:
                        print("smape=%3.3f" % smape_err)
                        print("mase=%3.3f" % mase_err)
                    
                if plots_on and test is not None:
                    plt.plot(fh_range, te)
                    plt.plot(fh_range, yhat)
                    plt.title('final prediction result')
                    plt.legend(['test', 'yhat'])
                    plt.show()
                
                print("#"*10) if verbose else None
            # end of loop on the rows
        # end of loop on dataset
    except Exception as e:
        print("An error occurred on this row: ", ts_id)
        print("error msg: ", e)
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        pbar.close()
        return (preds, id_of_bests) # latest predictions so that the rest could be continued in another execution
    pbar.close()
    #
    return (preds, id_of_bests)


def load_data_set(path, validation_cut):
    # Paths and file names
    cutsize = validation_cut # path to the dataset split size. 
                             # options: 1000, 10000, and full
    path_train = join(path, "cut", cutsize, "train")
    path_test = join(path, "cut", cutsize, "test")
    # files = ["Daily.csv", "Hourly.csv", "Monthly.csv", "Quarterly.csv", "Weekly.csv", "Yearly.csv"]
    files = ["Yearly.csv"]

    train = {}
    test = {}

    for f in files:
        train[f.split(".")[0]] = pd.read_csv(join(path_train, f))
        test[f.split(".")[0]] = pd.read_csv(join(path_test, f))    

    # fix the IDs from training set
    for key in test.keys():
        if cutsize != 'full':
            train[key] = train[key].drop(['Unnamed: 0'], axis=1)
            test[key] = test[key].drop(['Unnamed: 0'], axis=1)
        test[key] = pd.concat([train[key]['V1'], test[key]], axis=1)

    files = ["Yearly-train.csv"]
    # files = ["Yearly-train.csv", "Weekly-train.csv", "Quarterly-train.csv", "Monthly-train.csv", "Hourly-train.csv", "Daily-train.csv"]
    path_m4 = join(path, "M4DataSet") # path could be altered.
    train_f = {}
    for f in files:
        train_f[f.split("-")[0]] = pd.read_csv(join(path_m4, f))

    # M4 info
    m4info = pd.read_csv(join(path, "M4-info.csv"))
    
    return train, test, train_f, m4info


MODEL_NAME='fearless5'

def main(dataset_path, result_path, validation_cut='full', **kwargs):
    train, test, train_f, m4info = load_data_set(dataset_path, validation_cut)
    if 'tqdm_info' in kwargs.keys():
        tqdm_info = kwargs['tqdm_info']
    else:
        tqdm_info = {'position': 0, 'desc': MODEL_NAME}


    # Forecast on hold-out
    preds_holdout, id_of_best_calc = fearless5(train=train, m4info=m4info, test=test, datasets=[], verbose=False, tqdm_info=tqdm_info)

    # some explanatory of which method used how much
    #plt.hist(id_of_best_calc.values())
    #plt.show()
    
    # Final forecast for the competition
    # id_of_best_calc = {row_id:0 for row_id in train['Yearly']['V1']} # for debug purposes
    preds_final, _ = fealess5(train=train_f, m4info=m4info, test=None, datasets=[], verbose=False, variation_pick=id_of_best_calc, tqdm_info=tqdm_info)

    # Save the predictions
    all_preds_holdout = pd.DataFrame.from_dict(preds_holdout, orient='index')
    all_preds_holdout.to_csv(join(result_path["holdout"], "fearless5_all_holdout.csv"), float_format='%.f')
    all_preds_final = pd.DataFrame.from_dict(preds_final, orient='index')
    all_preds_final.to_csv(join(result_path["test"], "fearless5_all_test.csv"), float_format='%.f')


# standalone execution of the model
if __name__ == "__main__":
    # Parsing arguments
    parser = ArgumentParser(description='A model source code example')
    parser.add_argument('-d', '--dataset-dir', required=True, help='Path to the dataset directory')
    parser.add_argument('-r', '--results-dir', required=True, nargs=1, help='Path to the results directory')
    parser.add_argument('-c', '--validation-cut', default='full', nargs=1, help='validation cut: 1000, 10000, full ')
    # parser.add_argument('-s', '--datasets', default=[], nargs='+', help='list of datasets, i.e. [Hourly, Daily]')

    args = parser.parse_args()
    results_dir = {'holdout': os.path.join(args.results_dir[0], 'holdout'),
                   'test': os.path.join(args.results_dir[0], 'test'),
                   'root': args.results_dir[0] }

    main(args.dataset_dir, results_dir, args.validation_cut[0])
 
