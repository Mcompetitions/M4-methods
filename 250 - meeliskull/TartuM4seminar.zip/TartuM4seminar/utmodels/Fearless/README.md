# Fearless

1. seasonal decomposition on the time series => breaks up to trend, seasonal, residuals
2. fit linear, exponential to the trend
   fit linear, sinusoidal to the residuals
*seasonal is a fixed periodic signal
3. try out different combinations of fits, and basically:
   prediction per ts = fitted_trend + seasonal + fitted_residual
4. remember which combination was good on which row on the holdout
5. make prediction test set (similar procedures except apply the best combination for each row)

more explanation and documentation of code available on the notebook!

Questions: novin@ut.ee
