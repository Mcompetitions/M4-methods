# In[25]:
import pandas as pd
import numpy as np
import os
from tqdm import tqdm

import lightgbm as lgb
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import GridSearchCV

# In[26]:
train_path = "C:/Users/Anton/Desktop/M4/datasets/final/"
result_path = "C:/Users/Anton/Desktop/M4/results/lightgbm/final/"

files             = ["Quarterly.csv", "Weekly.csv", "Yearly.csv", "Daily.csv", "Monthly.csv", "Hourly.csv"]
# Predicted horizont
fc_horizon        = [8, 13, 6, 14, 18, 48]
# Smallest sliding window size for each datasets
window_sizes_from = [4, 5,  4, 30, 12, 24]
# Biggest sliding window size for each datasets
window_sizes_to   = [9, 26, 9, 46, 19, 37]
# Step size change window
window_sizes_step = [4, 20, 4, 15, 6, 12]

np.random.seed(0)

if not os.path.isdir(result_path):
    os.makedirs(result_path)
# In[28]:


# convert time series into supervised learning problem
def series_to_supervised(data, window_size=1):
    df = pd.DataFrame(data)
    x_cols = list()
    y_cols = list()
    # input sequence (t-n, ... t-1)
    for i in range(window_size, 0, -1):
        x_cols.append(df.shift(i))
    # forecast sequence (t, t+1, ... t+n)
    for i in range(0, 1):
        y_cols.append(df.shift(-i))
    # put it all together
    X = pd.concat(x_cols, axis=1)
    y = pd.concat(y_cols, axis=1)
    X = X.values
    y = y.values
    X = X[window_size:]
    y = y[window_size:]
    return X, y.reshape(-1)


# Obtaining differences between time steps
def difference(dataset):
    interval = 1
    diff = list()
    for i in range(interval, len(dataset)):
        value = dataset[i] - dataset[i - interval]
        diff.append(value)
    return pd.Series(diff)


# Dataset preprocessing
def prepare_data(series, window_size):
    # extract raw values
    raw_values = series.values
    # transform data to be stationary
    diff_series = difference(raw_values)
    diff_values = diff_series.values
    diff_values = diff_values.reshape(len(diff_values), 1)
    # data scaling
    scaler = MinMaxScaler()
    scaled_values = scaler.fit_transform(diff_values)
    scaled_values = scaled_values.reshape(len(scaled_values), 1)
    # transform to supervised learning problem
    X_train, y_train = series_to_supervised(scaled_values, window_size)
    X_test = scaled_values[-window_size:].reshape(1, window_size)
    return scaler, X_train, y_train, X_test


# invert differenced forecast
def inverse_difference(last_ob, forecast):
    # invert first forecast
    inverted = list()
    inverted.append(forecast[0] + last_ob)
    # propagate difference forecast using inverted first value
    for i in range(1, len(forecast)):
        inverted.append(forecast[i] + inverted[i - 1])
    return inverted


# inverse data transform on forecasts
def inverse_transform(series, forecast, scaler):
    # invert scaling
    inv_scale = scaler.inverse_transform(forecast)
    inv_scale = inv_scale[0, :]
    last_ob = series[-1]
    # transform from differences to original time series
    inv_diff = inverse_difference(last_ob, inv_scale)
    return np.array(inv_diff)


# In[29]:
class Processor:
    def __init__(self, train_set, horizon, ws_from, ws_to, ws_step, file):
        self.train_set = train_set
        self.horizon = horizon
        self.window_size_min = ws_from
        self.window_size_max = ws_to
        self.window_size_step = ws_step
        self.results = {}
        self.hyper_params_result = {}
        self.problems = {}
        self.file = file

    def predict(self, model, X_test):
        result = []
        for i in range(self.horizon):
            prediction = model.predict(X_test)
            result.append(prediction)
            X_test = np.append(X_test[:, 1:], prediction.reshape(1, 1), axis=1)
        result = np.array(result).reshape(1, -1)
        return result

    def get_estimator(self, series, window_size):
        # Not enough data for cv splitting
        if series.shape[0] < window_size + self.horizon + 3:
            return None
        scaler, X_train, y_train, X_test = prepare_data(series, window_size)
        # Create parameters to search
        gridParams = {
            'learning_rate': [0.01, 0.1, 0.5],
            'n_estimators': [8, 20, 32],
            'max_depth': [-1, 7, 15],
            'min_split_gain': [0, 0.5],
            'random_state': [0],
            'reg_lambda': [0, 1.5],
            'min_data_in_bin': [1],
            'verbosity': [-1]
        }
        model = lgb.LGBMRegressor(objective='regression_l2', min_child_samples=1,
                                  verbose=-1, max_bin=512, num_leaves=130)
        cb_model = GridSearchCV(model, gridParams, scoring="neg_mean_squared_error", cv=3, iid=True)
        cb_model.fit(X_train, y_train)
        return cb_model.best_params_, cb_model.best_score_, cb_model.best_estimator_

    def clip_series(self, series, max_series_size):
        if max_series_size is None:
            return series
        max_size = self.window_size_max + self.horizon + max_series_size
        if series.shape[0] > max_size:
            series = series[-max_size:]
        return series

    def process_row(self, original_series, row_id):
        max_series_sizes = [None, 40]
        max_series_sizes = [None]
        best_params = None
        # HIGHER BETTER!!!!!!!!!!
        best_score = -np.inf
        best_estimator = None
        best_max_series_size = None
        best_window_size = None

        for max_series_size in max_series_sizes:
            series = original_series.copy()
            series = self.clip_series(series, max_series_size)
            for window_size in range(self.window_size_min, self.window_size_max, self.window_size_step):
                result = self.get_estimator(series, window_size)
                if result is None:
                    continue
                params, score, estimator = result
                if score > best_score:
                    best_score = score
                    best_params = params
                    best_estimator = estimator
                    best_max_series_size = max_series_size
                    best_window_size = window_size
            del series

        if best_estimator is None:
            window_size = original_series.shape[0] - self.horizon - 3
            result = self.get_estimator(original_series, window_size)
            if result is None:
                print("Not enough data")
                return
            print("Use min window size")
            best_params, best_score, best_estimator = result

        series = original_series.copy()
        series = self.clip_series(series, best_max_series_size)
        scaler, X_train, y_train, X_test = prepare_data(series, best_window_size)
        y_pred = self.predict(best_estimator, X_test)
        # inverse transform forecasts and test
        y_pred = inverse_transform(series, y_pred, scaler)
        self.results[row_id] = y_pred

        best_params['window_size'] = best_window_size
        best_params['score'] = best_score
        best_params['clipping'] = 0 if best_max_series_size is None else best_max_series_size
        self.hyper_params_result[row_id] = best_params

    def run(self):
        print("====================== Producer Start. ======================")
        for row_id in tqdm(range(self.train_set.shape[0])):
            series = self.train_set.iloc[row_id].dropna()
            # Training set does not contain any data.
            if series.shape[0] == 0:
                print("Row skipped")
                continue
            # Here we have at least window_size elements
            # Time series preprocessing
            # prepare data
            try:
                self.process_row(series, row_id)
            except Exception as e:
                # TODO log problematic rows
                self.problems[row_id] = e
                print("Error", row_id)
        pd.DataFrame.from_dict(self.results, orient="index").to_csv(result_path + self.file)
        pd.DataFrame.from_dict(self.hyper_params_result, orient="index").to_csv(result_path + os.path.splitext(self.file)[0] + "_params.csv")

        print("====================== Producer Stoped. ======================")
        return
# In[30]:
def main():
    problematic_rows = {}
    # ["Quarterly.csv", "Weekly.csv", "Yearly.csv", "Daily.csv", "Monthly.csv", "Hourly.csv"]
    ids = [1, 2, 5]
    for data_id in range(len(files)):
        if data_id not in ids:
            continue
        problematic_rows[data_id] = []
        file = files[data_id]
        print("============== Dataset %s =======================" % file)
        train_set = pd.read_csv(train_path + file)
        # Drop first column that contains time series ID
        train_set = train_set.iloc[:, 2:]
        producer = Processor(train_set, fc_horizon[data_id], window_sizes_from[data_id],
                             window_sizes_to[data_id], window_sizes_step[data_id], file)
        producer.run()
        problematic_rows[data_id] = producer.problems
    print("====================== Done. Exit. ======================")
if __name__ == '__main__':
    main()
