# TeamPotap

only on yearly!

Model is LightGBM. One model per row for a yearly dataset. Considered different sliding window sizes and hyperparameters (grid search with cross-validation). Prediction based on a normalized difference between time steps. Used min-max normalization.