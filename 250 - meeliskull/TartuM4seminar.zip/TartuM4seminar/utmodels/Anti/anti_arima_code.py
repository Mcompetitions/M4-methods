
# coding: utf-8

from rpy2.robjects.packages import importr
import rpy2.robjects as ro
from rpy2.robjects import numpy2ri
numpy2ri.activate()

from os.path import join
import time
from collections import defaultdict

import os
import numpy as np
import pandas as pd
from argparse import ArgumentParser
import warnings
warnings.filterwarnings('ignore')
from tqdm import tqdm



def load_dataset(dataset_path, files):
    all_data = []
    for file in files:  # Go through all the files
        data_train = pd.read_csv(join(dataset_path, file))  # Read in files as pandas dataframe
        all_data.append(data_train)
    return all_data


MODEL_NAME = 'anti_arima'


# to be called by the run_models.py in the root of the project
def main(dataset_path, result_path, validation_cut='full', **kwargs):
    path_train = join(dataset_path, "cut", validation_cut, "train")  # Path to train datasets
    path_test = join(dataset_path, "cut", validation_cut, "test")  # Path to test datasets

    files = ["Daily.csv", "Hourly.csv", "Monthly.csv", "Quarterly.csv", "Weekly.csv",
             "Yearly.csv"]  # Used files in path

    (train_da, test_da), (train_ho, test_ho), (train_mo, test_mo), \
    (train_qu, test_qu), (train_we, test_we), (train_ye, test_ye) = load_all_data_pd(path_train, files)

    all_data = {"daily" : (train_da, test_da),
                "hourly": (train_ho, test_ho),
                "monthly": (train_mo, test_mo),
                "quarterly": (train_qu, test_qu),
                "weekly": (train_we, test_we),
                "yearly": (train_ye, test_ye)}

    # tqdm info setup
    if 'tqdm_info' in kwargs.keys():
        tqdm_info = kwargs['tqdm_info']
    else: # on standalone
        tqdm_info = {'position': 0, 'desc': MODEL_NAME}
    total=0
    for _, (train, _) in all_data.items():
       total+= train.shape[0]
    tqdm_info=kwargs['tqdm_info']
    pbar = tqdm(total=total, position=tqdm_info['position'], desc=tqdm_info['desc'])

    preds, mases, smapes = train_model_arima(all_data)
    pbar.close()

    # Save the prediction
    save_path = join(result_path['holdout'], "anti_arima_" + validation_cut + "_holdout.csv")
    export_preds(all_data, preds, save_path)
    # use the result_path to save the model
    # run once for validation on full dataset once for the final submission
    result_path['root']  # root directory for the results
    result_path['holdout']  # directory for saving the holdouts predictions
    result_path['test']  # directory for saving the test predictions

    # naming convention for the prediction files:
    # TEAMNAME_METHOD_DATASET/CUTSIZE_TYPE
    # examples: RandomF_arima_full_holdout.csv
    #           RandomF_arima_yeaerlfull_holdout.csv
    #           RandomF_arima_daily1000_holdout.csv
    #           RandomF_arima_full_test.csv


def load_all_data_pd(path_train, files):
    all_data = []
    for file in files:  # Go through all the files

        data_train = pd.read_csv(join(path_train, file))  # Read in files as pandas dataframe

        all_data.append(data_train)

    return all_data


def train_model_arima(data, filler_cols = (1,0)):
    '''
    Use all the data to train models for each row using given method
    
    Parameters:
        method: method used for model (i.e LinearRegression, MLPRegressor, RandomForestRegressor, etc)
        data: (dict) containing key: train, test
        filler_cols: (tuple) 2-element tuple containing number of filler cols for train and test
        multiplier: (int) how many seasons are taken into account for data sampling
        methods_kwargs: (dict) dictionary that contains keyword argument pairs for method using for training the model
        fit_kwargs: (dict) dictionary that contains keyword argument pairs for fitting method of the model.
        
    Returns:
        y_preds: (list) list containing all the predictions
    '''
    season_horizon = {
        "daily": (1, 14),
        "hourly": (24, 48),
        "monthly": (12, 18),
        "quarterly": (4, 8),
        "weekly": (1, 13),
        "yearly": (1, 6)
    }
    forecast = importr('forecast')

    a = time.time()  # Starting time

    preds = defaultdict(list)
    mases = defaultdict(list)
    smapes = defaultdict(list)

    for freq, (train) in data.items():

        season, horizon = season_horizon[freq]  # Get seasonality and horizon (frequence)
        
        a1 = time.time()  # Time end

        # Get predictions one by one
        for i, (ix, item) in enumerate(train.iterrows()):
            # specific stuff
            train_row = np.array(item[filler_cols[0]:].dropna().values, dtype=np.float32)
            
            # Train model
            # https://www.rdocumentation.org/packages/forecast/versions/7.3/topics/auto.arima
            ro.globalenv["train"] = train_row
            fit = forecast.auto_arima(ro.globalenv["train"], max_order = 8, start_p = 0, start_q = 0, stepwise=False, approximation=False)
            preds_tmp = forecast.forecast(fit, h=horizon)
            preds_treal = np.array(preds_tmp[3], dtype=np.float32)
            
            preds[freq].append(preds_treal)

        b1 = time.time()  # Time end
        total1 = b1 - a1
        print("%s: %.3f" % (freq, total1))

    # Time 
    b = time.time()
    total = b - a
    print("Total time taken: ", total, "\n")  # How much time spent?

    return preds, mases, smapes


def export_preds(all_data, preds, outp_name):
    dfs = []

    for i, (freq, train) in enumerate(all_data.items()):
        len_t = len(train)
        temp_preds = preds[freq]
        df = pd.DataFrame(temp_preds)
        df.index = train['V1']
        dfs.append(df)

    df_all = pd.concat(dfs)    
    df_all.to_csv(outp_name + ".csv", header=True)


if __name__ == "__main__":
    # Parsing arguments
    parser = ArgumentParser(description='A model source code example')
    parser.add_argument('-d', '--dataset-dir', required=True, help='Path to the dataset directory')
    parser.add_argument('-r', '--results-dir', required=True, nargs=1, help='Path to the results directory')
    parser.add_argument('-c', '--validation-cut', default='full', nargs=1, help='validation cut: 1000, 10000, full ')
    # parser.add_argument('-s', '--datasets', nargs='+', help='list of datasets, i.e. [Hourly, Daily]')

    args = parser.parse_args()
    results_dir = {'holdout': os.path.join(args.results_dir[0], 'holdout'),
                   'test': os.path.join(args.results_dir[0], 'test'),
                   'root': args.results_dir[0] }

    print(args.dataset_dir, results_dir, args.validation_cut[0])
    main(args.dataset_dir, results_dir, args.validation_cut[0])

