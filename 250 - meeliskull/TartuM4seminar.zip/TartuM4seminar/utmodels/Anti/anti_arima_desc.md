# auto.arima from R forecast package (run through python using rpy2)

Parameters: max_order = 8, start_p = 0, start_q = 0, stepwise=False, approximation=False