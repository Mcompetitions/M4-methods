# Models

some info on the models and guide for running each individually/together 