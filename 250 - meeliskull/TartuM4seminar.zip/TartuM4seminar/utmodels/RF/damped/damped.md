# ETS (R forecast) 

is trained on all rows separately, where damped parameter is set to True.