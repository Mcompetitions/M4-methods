
# coding: utf-8

# # Setup
# 
# * conda install rpy2
# * conda install -c r r
# * conda install -c r r-forecast
# 
# Kasulikku:
# 
#  * https://en.wikipedia.org/wiki/Autoregressive_integrated_moving_average
#  * https://sites.google.com/site/aslugsguidetopython/data-analysis/pandas/calling-r-from-python
#  * https://www.analyticsvidhya.com/blog/2018/02/time-series-forecasting-methods/
#  * https://www.cheatography.com/weidadeyue/cheat-sheets/jupyter-notebook/

import numpy as np
import pandas as pd
from rpy2.robjects.packages import importr
import rpy2.robjects as ro
from rpy2.robjects import numpy2ri
numpy2ri.activate()

from load_data import load_all_data_pd
from os.path import join

import time
from evaluation import sMAPE, MASE, owa_10k, OWA, save_results
from collections import defaultdict
season_horizon = {"daily" : (1, 14),
                "hourly": (24, 48),
                "monthly": (12, 18),
                "quarterly": (4, 8), 
                "weekly": (1, 13),
                "yearly": (1, 6)}

path_train = join("..", "..", "data","full","train")
path_test = join("..", "..", "data","full","test")
path_naive = join("naive_results", "naive1_full_preds.csv")
files = ["Daily.csv", "Hourly.csv", "Monthly.csv", "Quarterly.csv", "Weekly.csv", "Yearly.csv"]
(train_da, test_da), (train_ho, test_ho), (train_mo, test_mo),(train_qu, test_qu), (train_we, test_we), (train_ye, test_ye) = load_all_data_pd(path_train, path_test, files)

all_data = {"daily" : (train_da, test_da),
            "hourly": (train_ho, test_ho),
            "monthly": (train_mo, test_mo),
            "quarterly": (train_qu, test_qu), 
            "weekly": (train_we, test_we),
            "yearly": (train_ye, test_ye)}

forecast = importr('forecast')

def train_model_single(data, filler_cols = (2,1), multiplier = 2, 
                       method_kwargs = {}, fit_kwargs = {}, is_final_train = False, csv_name = None):
    '''
    Use all the data to train models for each row using given method.
    
    Parameters:
        method: method used for model (i.e LinearRegression, MLPRegressor, RandomForestRegressor, etc)
        data: (dict) containing key: train, test
        filler_cols: (tuple) 2-element tuple containing number of filler cols for train and test
        multiplier: (int) how many seasons are taken into account for data sampling
        methods_kwargs: (dict) dictionary that contains keyword argument pairs for method using for training the model
        fit_kwargs: (dict) dictionary that contains keyword argument pairs for fitting method of the model.
        is_final_train: (bool) merges train and test set to train final results.
        csv_name: (string) name of csv file were the results are saved to (default = None, no saving done)
        
    Returns:
        y_preds: (list) list containing all the predictions
    '''
    

    a = time.time()  # Starting time

    mases = []  # TODO convert to np.array
    smapes = []
    preds_all = []


    for freq, (train, test) in data.items():

        a1 = time.time()  # Time start

        test = test.values[:, filler_cols[1]:]  # Drop filler cols
        season, horizon = season_horizon[freq]  # Get seasonality and horizon (frequence)
        preds_single = np.zeros_like(test)

        # Get predictions one by one
        for ix, item in train.iterrows():
            train_row = np.array(item[filler_cols[0]:].dropna().values, dtype=np.float32)
            test_row = np.array(test[ix], dtype=np.float32)
            
            if is_final_train:  # add the test_row in the end of train_row if final results needed
                train_row = np.concatenate([train_row, test_row])
            
            # Train model
            ro.globalenv["train"] = train_row
            ro.globalenv["test"] = test_row
            fit = forecast.ets(ro.globalenv["train"], damped=True)
            
            preds_tmp = forecast.forecast(fit, h=horizon)
            preds_treal = np.array(preds_tmp[3], dtype=np.float32)
            
            preds_single[ix] = np.array(preds_treal, dtype=np.float32)  # Add preds to list.
            
            if not is_final_train:  # Only evaluate if not final training
                mases.append(MASE(train_row, test_row, preds_treal, season))            
                smapes.append(sMAPE(test_row, preds_treal))

        preds_single = np.array(preds_single)  # Back to numpy array
        preds_all.append(preds_single)

        b1 = time.time()  # Time end
        total1 = b1 - a1
        print("%s: %.3f" % (freq, total1))

    # Time 
    b = time.time()
    total = b - a
    print("Total time taken: ", total, "\n")  # How much time spent?

    if not is_final_train:  # Get evaluation measures only if not final scores.    
        print("MASEs:", len(mases))
        print("sMAPEs:", len(smapes))    
        print("MASEs min: %.3f max: %.3f" % (min(mases), max(mases)))
        print("SMAPES min: %.3f max: %.3f\n" % (min(smapes), max(smapes)))

        # Average scores
        mase_avg = np.mean(mases)
        smape_avg = np.mean(smapes)
        owa = OWA(mase_avg, smape_avg)  # Weighted average
        print("MASE avg:", mase_avg)
        print("sMAPE avg:", smape_avg)
        print("OWA:", owa)
        
    if csv_name != None:
        save_results(preds_all, data, csv_name)

    return preds_all

filler_cols = (1,0) if "full" in path_train else (2,1)
preds = train_model_single(all_data, filler_cols=filler_cols, is_final_train=True, csv_name="RF_ets_test")

