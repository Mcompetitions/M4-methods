# ETS (R forecast)

It is trained on all rows separately. Default parameters.