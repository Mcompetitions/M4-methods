# Auto arima (R forecast)

It is trained on all rows separately. Parameters that were changed from default: max_order=20, start_d = 0, start_p = 0.