# Stupidity v1

For each predicted time point T(i) and predefined season length S, the prediction is
T(i) = T(i-S) + T(i-1-S) - T(i-1)
In other words, it uses adds the difference between time points T(i-1-S) and T(i-1), which are exactly one season apart, and adds it to the time point exactly one season prior to T(i).