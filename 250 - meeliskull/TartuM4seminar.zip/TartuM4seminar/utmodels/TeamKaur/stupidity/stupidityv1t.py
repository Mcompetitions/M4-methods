import pandas as pd
import numpy as np

sizes = ["1000", "10000", "full"]
times = ["Monthly","Daily","Hourly","Quarterly","Weekly","Yearly"]
horis = [18, 14, 48, 8, 13, 6]
peris = [12,  7, 24, 4, 4, 3]
direc = "cut"

def predict(row, horizon, period):
	
	x_2 = np.array(row)
	res = []
	# Do check if this should be good approach
	"""
	check1 = x_2[-1]-x_2[-period-1]
	check2 = x_2[-2]-x_2[-period-2]
	check3 = x_2[-3]-x_2[-period-3]
	check4 = x_2[2+period]-x_2[2]
	check5 = x_2[-4]-x_2[-period-4]
#	if not (abs(check1) > 3 and abs(check2) > 3 and abs(check3) > 3 and abs(check4) > 3):	# Low variance means no further checks
	if check1*check2 < 0 or check2*check3 < 0 or check1*check3 < 0 or check1*check4<0 or check1*check5 < 0:	# Trend impossible
		return None
	if (check1!=0 and check3!=0 ) and (check1/check3 > 2 or check3/check1 > 2):
		return None
	if (check2!=0 and check4!=0 ) and (check2/check4 > 2 or check4/check2 > 2):
		return None
	if (check1!=0 and check5!=0 ) and (check1/check5 > 2 or check5/check1 > 2):
		return None
	"""
	# Do good approach
	for time in range(horizon):
		value = x_2[-period]+(x_2[-1] - x_2[-period-1])
		x_2=np.append(x_2, value)
		res.append(value) # send predicted value to be stored
	return res


size = 2
for time in [0,1,2,3,4,5]:#range(1,len(times)):
	print("Doing",times[time],"now")
	#data = pd.read_csv(sizes[size]+"/train/"+times[time]+".csv")
	data = open(times[time]+"-train.csv")
	series = []
	results = []
	period = peris[time]
	for data_row in data:
		row = data_row.split(",")
		if row[0]=='"V1"':
			name_ind = 0
			continue
		else:
			if row[1]=="V1":
				name_ind = 1
				continue
		sm_df = pd.DataFrame()

		stop = 0
		tr_data = np.array([float(num.strip()[1:-1]) for num in row[2:] if num.strip()[1:-1] != ""])

		length = len(tr_data)
		r = predict(tr_data,horis[time],peris[time])
		if r is None:
			continue
		else:
			results.append((row[name_ind],r))
	data.close()


	with open("predictions_st1_"+str(sizes[size])+".csv","a") as f:
		#f.write("," + ",".join([str(n) for n in list(range(horis[time]))]) + "\n")
		for name, result in results:
			f.write(name)
			for num in result:
				if num > 0:
					f.write(","+str(num))
				else:
					f.write(",0")
			f.write("\n")
