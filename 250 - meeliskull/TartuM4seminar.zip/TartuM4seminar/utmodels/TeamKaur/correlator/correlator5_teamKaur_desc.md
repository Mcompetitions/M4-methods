# Correlator ver5.1

The correlator works by going over all time series of a certain type (Monthly, Daily, etc.) in a sliding window approach.
The width of the window is 2*season length, where the season length is hardcoded (7 for Daily, 24 for Hourly, 4 for Quarterly etc.).
The last window seen on each time series is exactly 1 horizon (number of time points to be predicted) short of the end of the time series.
All seen windows are stored in memory, windows of a certain type can require a significant amount of memory (in some cases there are over 9 000 000 stored windows).


For each row, a window is taken from its end ("end-of-row window"). That window (e.g W1) is compared against all stored windows. The highest correlated window (e.g W2)'s location is found and time points immediately following the window (H2) are used to make the prediction for the row.
The correlation value for the window that is used to make a prediction is stored in a separate file. That file can  be used for filtering - low-correlated rows might not result in good predictions. On those rows, other approaches should be considered.
The time points are renormalized according to the mean values and standard deviations of the two windows:

H1 (horizon for 1st window) = (H2 - mean(W2)) / std(W2) * std(W1)+ mean(W1)

As Pearson correlation can be construed as matrix dot products, the correlation values for each window can be found very quickly. The drawback is that the more rows are found correlations for, the more memory is required.
For this reason, the code includes an "optimization" that limits the number of rows used for finding correlations for, depending on the number of windows each row has to be compared to. For instance, on Hourly data, near 300 rows can find the most correlating positions from all other rows can be found in a single step, but on Monthly, fewer than 10 rows can be used.
As a corollary, Hourly data can be fully processed in half a minute, Monthly data may require several days.

**There are two failchecks:**
1. Due to the implementation of Pearson correlation used, any window with constant values, including the end-of-row windows can result in a correlation value of NaN. If this happens to the end-of-row window, Naive1 is used instead, no correlation value is stored.
2. Some windows that are found to be well-correlating can make predictions of a cliff or a sharp jump. To avoid these, the standard deviation of the prediction can be up to 2.5 times the standard deviation of the end-of-row window. If it is not, the next highest-correlating window is used to make a new prediction instead.

**Usage:**

"python3 slow_corr_sub.py t #"
Where # is to be replaced by a number 0-5, which defines which type of time series (Monthly, Daily, Hourly, Quarterly, Weekly, Yearly) to analyze and predict for.

**POST-PROCESSING**

- ```sitrep2.py``` loads a prediction file, adds the first row (numbers from 0 to 47, no "V") and also saves the names of the rows seen in a separate file.
- ```clfilter.py``` loads the names of the rows seen in two cases - one resulted from using holdout data (a dataset created by slicing off a horizon-length piece from every time series in the training data) and one from the real training data. It then finds the intersection (in case an further filtering has been made) and stores the results from only those rows in a separate file.