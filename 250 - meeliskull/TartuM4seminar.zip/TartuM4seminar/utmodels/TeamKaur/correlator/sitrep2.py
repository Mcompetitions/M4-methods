from sys import argv
res = {}
rows = set()
output = []
if len(argv)==3:
	limit = float(argv[2])	# Min correlation to let through
else:
	print("WARNING: this assumes limit = 0.995")
	limit = 0.995
with open(argv[1]) as f:
	for row in f:
		rowtitle = row.split(",")[0]
		if rowtitle=="":
			continue
		res[rowtitle[0]] = res.get(rowtitle[0],0) + 1
		if rowtitle in rows:
			continue
		rows.add(rowtitle)
		output.append(row)	# No strip :)

allowed = []
with open("5m_res.csv") as f:
	for row in f:
		content = row.strip().split(",")
		rowtitle = content[0]
		rowvalue = content[1]
		if rowvalue.endswith("+"):	#Mishap
			rowvalue=rowvalue[:-1]
		rowvalue = float(rowvalue)
		if rowvalue >= limit:	# If over limit
			allowed.append(rowtitle)	# I'll allow it
		
print(res)
print("Rowstotal:", len(output))
print("Allowed:",len(allowed))
with open("s_"+argv[1], "w") as f:
	f.write(",0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47\n")
	for row in output:
		f.write(row)
with open("lim"+str(limit)[2:]+"_"+argv[1],"w") as f:
	f.write(",0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47\n")
	for row in output:
		if row.split(",")[0] in allowed:
			f.write(row)
with open("rows.txt","w") as f:
	for rowtitle in rows:
		f.write(rowtitle+"\n")
with open("rows_corr.txt","w") as f:
	for rowtitle in allowed:
		f.write(rowtitle+"\n")