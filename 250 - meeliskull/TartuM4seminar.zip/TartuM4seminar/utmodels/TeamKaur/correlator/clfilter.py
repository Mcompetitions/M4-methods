from sys import argv

rowsfile = "rows.txt"
if "corr" in argv[1]:
	rowsfile = "rows_corr.txt"
with open(rowsfile) as f1:
	settwo = set()
	for row in f1:
		c = row.strip().split(",")
		if "V" not in c[0]:
			settwo.add(c[0])
with open("cut/"+rowsfile) as f2:
	setone = set()
	for row in f2:
		c = row.strip().split(",")
		if "V" not in c[0]:
			setone.add('"'+c[0]+'"')
with open("real"+rowsfile,"w") as f3:
	setthree = setone & settwo
	for thing in setthree:
		f3.write(thing+"\n")
print(len(setone))
print(len(settwo))
print(len(setthree))
if "/" in argv[1]:
	sub = True
else:
	sub = False
with open(argv[1]) as f4:
	sh_name = argv[1].split("/")
	if sub:
		oppath = "/".join(sh_name[:-1])+"/ss_"+sh_name[-1]
	else:
		oppath = "ss_"+argv[1]
	with open(oppath,"w") as f5:
		for row in f4:
			c = row.split(",")
			if "V" in c[0]:
				f5.write(row)
				continue
			if sub:
				if '"'+c[0].strip()+'"' in setthree:
					f5.write(row)
			else:
				if c[0].strip() in setthree:
					f5.write(row)