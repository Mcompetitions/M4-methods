import pandas as pd
import numpy as np

from sys import argv
from time import time
import logging
from sys import exit

sizes = ["1000", "10000", "full"]
times = ["Monthly","Daily","Hourly","Quarterly","Weekly","Yearly"]
horis = [18, 14, 48, 8, 13, 6]
peris = [12,  7, 24, 4, 4, 3]
direc = "cut"
now = time()


def predict(row, horizon, period, lkp, all, r_ind, c_mat, rname, att):
	x_2 = row
	res = []
	x_2 = x_2[-2*period:]
	
	#print(c_mat.shape)
	inverse = False
	choice_inds = np.argsort(c_mat[r_ind])
	k = att
	b_ind = choice_inds[-k]
	if np.isnan(c_mat[r_ind][choice_inds[0]]):	# No suitable indexes on row, assume constant window
		return np.ones(horizon) * np.average(x_2)
	while np.isnan(c_mat[r_ind][b_ind]) and k<len(choice_inds)-1:
		k += 1
		b_ind = choice_inds[-k]
	
	# Find row of correlation
	row_ind = 0
	loc = 0
	while loc < b_ind:
		loc += lkp[row_ind]
		row_ind+=1
	row_ind-=1
	# Use row index to find the fake horizon data
	in_row = b_ind-(loc-lkp[row_ind])+2*period
	tr_i = all[row_ind][in_row-2*period:in_row]
	tr_j = all[row_ind][in_row:in_row+horizon]

	prop_res = fit(tr_i, x_2, tr_j)
	if np.std(prop_res) > np.std(tr_i) * 2.5 and -k != len(choice_inds):	# Too shaky to believe
		return predict(row, horizon, period, lkp, all, r_ind, c_mat, rname, k+1)
	else:
		with open("5m_res.csv","a") as ff:
			ff.write(str(rname)+","+str(c_mat[r_ind][b_ind])+"+\n")
		return prop_res
def fit(row1, row2, res1):
	res1_a = np.array(res1, dtype=np.float64)
	avg1 = np.average(row1)
	std1 = np.std(row1)
	avg2 = np.average(row2)
	std2 = np.std(row2)
	if std1 == 0:
		res2 = res1_a - avg1 + avg2
	else:
		res2 = ( res1_a - avg1 ) / std1 * std2 + avg2
	return list(res2)
def corr2_coeff(A,B):	# https://stackoverflow.com/questions/30143417/computing-the-correlation-coefficient-between-two-multi-dimensional-arrays
	# Rowwise mean of input arrays & subtract from input arrays themselves
	A_mA = A - A.mean(1)[:,None]
	B_mB = B - B.mean(1)[:,None]
	# Sum of squares across rows
	ssA = (A_mA**2).sum(1);
	ssB = (B_mB**2).sum(1);
	# Finally get corr coeff
	return np.dot(A_mA,B_mB.T)/np.sqrt(np.dot(ssA[:,None],ssB[None]))
def done(choice):
	doneset = set()
	with open("predictions_corr5__"+str(sizes[size])+".csv") as fz:
		for row in fz:
			doneset.add(row.split(",")[0])
	return doneset
	
# Parse arguments
timez = int(argv[2])
if argv[1] == "t":
	size = 2
	toadd = "-train.csv"
	path_to = times[timez]+"-train.csv"
else:
	size = int(argv[1])
	path_to = sizes[size]+"/train/"+times[timez]+".csv"

f = open("predictions_corr5zzzz__"+str(sizes[size])+".csv","a")

doneset = done(sizes[size])
# Do work
results = []
rows = []
print("Doing",times[timez],"now")
data = open(path_to)
lookup = []	# number of series gained from each row
series = []
period = peris[timez]
horizon = horis[timez]
counter = 0
alldata = []
rownames = []
for data_row in data:
	if len(data_row) < 2:
		continue
	if counter % 200 == 0:
		print("at",counter, time()-now)
	counter+=1
	row = data_row.split(",")
	if row[0]=="V1" or row[0] == '"V1"':
		name_ind = 0
		continue
	else:
		if row[1]=="V1":
			name_ind = 1
			continue
	
	stop = 0
	if argv[1] != "t":
		tr_data = np.array([float(num) for num in row[name_ind+1:] if num.strip() != ""])
	else:
		tr_data = np.array([float(num.strip()[1:-1]) for num in row[name_ind+1:] if num.strip()[1:-1] != ""])
	rownames.append(row[name_ind])
	alldata.append(tr_data)
	rows.append(tr_data[-2*period:])
	
	length = len(tr_data)
	start = 0
	end = length-2*period-horizon
	if end > 0:
		window_mp = 2
	else:
		lookup.append(0)
		continue
	added = 0
	for i in range(start,end):
		on_row = tr_data[i:i+window_mp*period]
		#if np.count_nonzero(on_row) == 0:
		#	continue
		series.append(on_row)
		added += 1
	lookup.append(added)
data.close()
print("Items:",len(series))
print("Lookup:",sum(lookup))

jump = max(int(100000000/len(series)), 1)
print("jump",jump)
counter = 0
for gap in range(0, len(alldata), jump):
	corr_matrix = corr2_coeff(np.array(rows[gap:gap+jump]),np.array(series))
	print("Matrix done",time()-now)
	
	# Trim transforms to same length for comparisons
	#tr_length = min([len(tf) for tf in row_transforms])
	#tr_length = period+1
	#row_transforms = [tf[:tr_length] for tf in row_transforms]
	
	# Start working on predicting
	#data = open(path_to)
	
	period = peris[timez]
	horizon = horis[timez]
	row_index = 0
	for row_ind2 in range(gap, min(gap+jump,len(alldata))):
		data_row = alldata[row_ind2]
		if counter % 200 == 0:
			print("at",counter, time()-now)
		if row_index < 40000 or rownames[row_ind2] in doneset:
			row_index += 1
			continue
		counter += 1
		name = rownames[row_ind2]
		#tr_data = np.array([float(num) for num in row[name_ind+1:] if num.strip() != ""])
		result = predict(data_row, horizon, period, lookup, alldata, row_index, corr_matrix, name, 1)
		f.write(name)
		for num in result:
			if num > 0:
				f.write(","+str(num))
			else:
				f.write(",0")
		f.write("\n")
		row_index += 1
	f.flush()
data.close()
f.close()