# XGBoost1 scripts

from utmodels.utils.load_data import load_all_data, load_all_data_pd, get_labels
from utmodels.utils.evaluation import MASE, sMAPE, OWA
from .training import train_model

from os.path import join
import numpy as np
from xgboost import XGBRegressor  # Install XGBoost, (http://xgboost.readthedocs.io/en/latest/python/python_intro.html).


def main(dataset_path, result_path, validation_cut='full'):
    # Load only hourly data
    path_train = join(dataset_path, "cut", "full","train")  # Path to train datasets
    path_test = join(dataset_path, "cut","full","test")  # Path to test datasets
    files = [#"Daily.csv",
             "Hourly.csv"
            #, "Monthly.csv", "Quarterly.csv", "Weekly.csv", "Yearly.csv"
    ]
    
    t = load_all_data_pd(path_train, path_test, files)
    train_ho = t[0][0]
    test_ho = t[0][1]
    ho_data = {"hourly": (train_ho, test_ho)}
    
    kwargs = {"max_depth":3, "n_estimators":100, "n_jobs":-1, "learning_rate":0.1, 'objective':'reg:linear'}
    y_preds_xgb_final = train_model_single(XGBRegressor, ho_data, filler_cols=(1,0), method_kwargs=kwargs, 
                                           is_final_train = True, csv_name="RandomF_XGBoost1_test")


# standalone execution 
if __name__ == "__main__":
    # TODO: receive from the input
    dataset_path = None
    result_path = None
    validation_cut = None
    main(dataset_path, result_path, validation_cut)      
