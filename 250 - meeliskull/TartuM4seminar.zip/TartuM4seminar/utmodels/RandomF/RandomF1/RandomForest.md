# RandomForest (RandomF1)

- kwargs = {"n_jobs":-1, "n_estimators":100}
- sklearn method "RandomForestRegressor" (http://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestRegressor.html)
- models trained using all the data together, taking all up to last as training features and last element as training.
- all scripts used are in folder "RandomF" in "M4UT" repository, "Training Baseline" notebook contains training process
- notebook in Google Drive "Notebooks" folder, add it to RandomF repo folder to use it 

Contact: Markus Kängsepp (markus93@ut.ee) for questions