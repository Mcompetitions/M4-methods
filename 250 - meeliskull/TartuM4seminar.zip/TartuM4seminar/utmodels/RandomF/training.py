# Methods necessary for training

import numpy as np
from utmodels.utils.evaluation import MASE, sMAPE, OWA, save_results
import time
import pandas as pd

# Constants
season_horizon = {"daily" : (1, 14),
                "hourly": (24, 48),
                "monthly": (12, 18),
                "quarterly": (4, 8), 
                "weekly": (1, 13),
                "yearly": (1, 6)}

def split_into_horizons(time_series, horizon):
    
    '''
    Split data into lengths of horizon. Meaning j elements are taken as features and j+1 as class, 
    continuing so until length of a time series.

    Parameters:
        row: (np.array) 1D array containing one time serie
        horizon: (int) number of features for each horizon
    
    '''
    
    len_data = len(time_series)
    rows = len_data - horizon # Minus 1 for test set

    temp_x = np.zeros((rows, horizon))
    temp_y = np.zeros(rows)

    for i in range(rows):
        temp_x[i] = time_series[i:(horizon+i)]
        temp_y[i] = time_series[horizon+i]

    return (temp_x, temp_y)


def predict_horizon(model, x, horizon = 18):
    
    '''
    Predict horizon based on the model
    
    Arguments:
        model: previously trained model, must have "fit" method
        x: (np.array) training data, features to predict from
        horizon: length of test elements to predict
    
    Returns:
        y_preds: (np.array) contains prediction for each row in training set, 
                            shape [[y1_1,y1_2, .. , y1_h], [y2_1,y2_2, .., y2_h], ..]
    '''
          
    y_preds = np.zeros((x.shape[0], horizon))
    
    for i in range(horizon):
        
        pred_temp  = model.predict(x)
        y_preds[:, i] = pred_temp
        x = np.column_stack((x[:, 1:], pred_temp))
    
    return y_preds
    
    
def train_model_single(method, data, filler_cols = (2,1), multiplier = 2, 
                       method_kwargs = {}, fit_kwargs = {}, is_final_train = False, csv_name = None):
    '''
    Use all the data to train models for each row using given method.
    
    Parameters:
        method: method used for model (i.e LinearRegression, MLPRegressor, RandomForestRegressor, etc)
        data: (dict) containing key: train, test
        filler_cols: (tuple) 2-element tuple containing number of filler cols for train and test
        multiplier: (int) how many seasons are taken into account for data sampling
        methods_kwargs: (dict) dictionary that contains keyword argument pairs for method using for training the model
        fit_kwargs: (dict) dictionary that contains keyword argument pairs for fitting method of the model.
        is_final_train: (bool) merges train and test set to train final results.
        csv_name: (string) name of csv file were the results are saved to (default = None, no saving done)
        
    Returns:
        y_preds: (list) list containing all the predictions
    '''
    

    a = time.time()  # Starting time

    mases = []  # TODO convert to np.array
    smapes = []
    preds_all = []


    for freq, (train, test) in data.items():

        a1 = time.time()  # Time start

        test = test.values[:, filler_cols[1]:]  # Drop filler cols
        season, horizon = season_horizon[freq]  # Get seasonality and horizon (frequence)
        preds_single = np.zeros_like(test)
        
        # Calculate input lenght for each freq ("daily", "hourly", etc)
        if season == 1:
            next_hor = horizon
        else:
            next_hor = season*multiplier

        # Get predictions one by one
        for ix, item in train.iterrows():
            values = item[filler_cols[0]:].values  # Drop filler cols
            train_row = values[~pd.isnull(values)]  # Drop NA values
            test_row = test[ix]  # Get correct row and drop filler cols
            
            if is_final_train:  # add the test_row in the end of train_row if final results needed
                train_row = np.concatenate([train_row, test_row])

            # Data to horizons, based on seasonality or horizon of predictions
            x_train, y_train = split_into_horizons(train_row, next_hor)
            
            # Train model
            model = method(**method_kwargs)  # Initialize model
            model.fit(x_train, y_train, **fit_kwargs)  # train model
            # Get predictions for horizon
            y_preds = predict_horizon(model, train_row[-next_hor:].reshape(1,-1), horizon=horizon)
            
            preds_single[ix] = y_preds[0]  # Add preds to list.
            
            if not is_final_train:  # Only evaluate if not final training
                mases.append(MASE(train_row, test_row, y_preds[0], season))            
                smapes.append(sMAPE(test_row, y_preds[0]))

        preds_single = np.array(preds_single)  # Back to numpy array
        preds_all.append(preds_single)

        b1 = time.time()  # Time end
        total1 = b1 - a1
        print("%s: %.3f" % (freq, total1))

    # Time 
    b = time.time()
    total = b - a
    print("Total time taken: ", total, "\n")  # How much time spent?

    if not is_final_train:  # Get evaluation measures only if not final scores.    
        print("MASEs:", len(mases))
        print("sMAPEs:", len(smapes))    
        print("MASEs min: %.3f max: %.3f" % (min(mases), max(mases)))
        print("SMAPES min: %.3f max: %.3f\n" % (min(smapes), max(smapes)))

        # Average scores
        mase_avg = np.mean(mases)
        smape_avg = np.mean(smapes)
        owa = OWA(mase_avg, smape_avg)  # Weighted average
        print("MASE avg:", mase_avg)
        print("sMAPE avg:", smape_avg)
        print("OWA:", owa)
        
    if csv_name != None:
        save_results(preds_all, data, csv_name)

    return preds_all

    
def train_model(method, data, method_kwargs = {}, fit_kwargs = {}, is_final_train = True, csv_name = None, labels = []):
    ''''
    Use all the data to train models for each frequency ("daily", "monthly", etch) using given method
    
    Parameters:
        method: method used for model (i.e LinearRegression, MLPRegressor, RandomForestRegressor, etc)
        data: (dict) containing key: train, test
        methods_kwargs: (dict) dictionary that contains keyword argument pairs for method using for training the model
        fit_kwargs: (dict) dictionary that contains keyword argument pairs for fitting method of the model.
        is_final_train: (bool) merges train and test set to train final results.
        csv_name: (string) name of csv file were the results are saved to (default = None, no saving done)
        labels: (list) list with data labels
    Returns:
        y_preds: (list) list containing all the predictions
    '''

    a = time.time()  # Starting time

    mases = []
    smapes = []
    preds_all = []


    for freq, (train, test) in data.items():

        a1 = time.time()  # Time start

        x_train = train[:,:-1]
        y_train = train[:, -1]  # Take last feature as y-value

        season, horizon = season_horizon[freq]
        
        if is_final_train:
            train = np.hstack([train, test])
            x_train = train[:, :-1]
            y_train = train[:, -1]

        model = method(**method_kwargs)
        model.fit(x_train, y_train, **fit_kwargs)

        y_preds = predict_horizon(model, train[:, 1:], horizon=horizon)  # Leave out first feature and give y as extra feature

        if not is_final_train:
            for i in range(y_preds.shape[0]):
                train_row = np.trim_zeros(train[i])
                mases.append(MASE(train_row, test[i], y_preds[i], season))
                smapes.append(sMAPE(test[i], y_preds[i]))
        
        preds_all.append(y_preds)

        b1 = time.time()  # Time end
        total1 = b1 - a1
        print("%s: %.3f" % (freq, total1))

    # Time 
    b = time.time()
    total = b - a
    print("Total time taken: ", total, "\n")  # How much time spent?
    
    if not is_final_train:
    

        print("MASEs:", len(mases))
        print("sMAPEs:", len(smapes))    
        print("MASEs min: %.3f max: %.3f" % (min(mases), max(mases)))
        print("SMAPES min: %.3f max: %.3f\n" % (min(smapes), max(smapes)))

        # Average scores
        mase_avg = np.mean(mases)
        smape_avg = np.mean(smapes)
        owa = OWA(mase_avg, smape_avg)  # Weighted average
        print("MASE avg:", mase_avg)
        print("sMAPE avg:", smape_avg)
        print("OWA:", owa)
        
    if csv_name != None and len(labels) != 0:
        save_results(preds_all, data, csv_name, labels)
    
    return preds_all
