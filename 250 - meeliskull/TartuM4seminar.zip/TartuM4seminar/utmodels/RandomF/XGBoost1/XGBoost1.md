# XGBoost1
with sliding window (HOURLY data only)

- parameters = {"max_depth":3, "n_estimators":100, "n_jobs":-1, "learning_rate":0.1, 'objective':'reg:linear'}
- XGBoost (http://xgboost.readthedocs.io/en/latest/python/python_intro.html)
- all scripts used are in folder "RandomF" in "M4UT" repository, "Training - Single using Samples" notebook contains training process 
- notebook in Google Drive "Notebooks" folder, add it to RandomF repo folder to use it

Contact: Markus Kängsepp (markus93@ut.ee) for questions