# Evaluation measures for time series
# Using methods from https://github.com/M4Competition/M4-methods/blob/master/ML_benchmarks.py

import numpy as np
import pandas as pd

def sMAPE(a, b):
    """
    Calculates sMAPE
    :param a: actual values
    :param b: predicted values
    :return: sMAPE
    """
    a = np.reshape(a, (-1,))
    b = np.reshape(b, (-1,))
    return np.mean(100*2.0 * np.abs(a - b) / (np.abs(a) + np.abs(b))).item()  
    # Added multiplication by 100, to get similar results to M3 scores and to Alina


def MASE(insample, y_test, y_hat_test, freq):
    """
    Calculates Mean Absolute Scaled Error
    :param insample: insample data  (training data)
    :param y_test: out of sample target values
    :param y_hat_test: predicted values
    :param freq: data frequency (seasonality)
    :return: MASE
    """
    y_hat_naive = []
    for i in range(freq, len(insample)):  # Best 2 lines ever... fortunately not mine
        y_hat_naive.append(insample[(i - freq)])

    # Get seasonal difference, i.e January 2017 - Jan 2016, Feb 2017 - Feb 2016, etc
    masep = np.mean(abs(insample[freq:] - y_hat_naive))

    return np.mean(abs(y_test - y_hat_test)) / masep
    

def OWA(MASE, sMAPE, naive_mase = 1.685, naive_smape = 15.201):
    """
    Overall Weighted Average of MASE and sMAPE using Naive2 scores
    
    Parameters:
        MASE: (float) mean absolute scaled error
        sMAPE: (float) mean absolute percentage error
        naive_mase: (float) MASE score of naive method
        naive_smape: (float) sMAPE score of naive method
    Returns:
        OWA: (float) owerall weighted average
    """
    
    return np.mean([MASE/naive_mase, sMAPE/naive_smape])  # Average of relative evaluation scores

    
def save_results(preds, all_data, name = "res", labels = []):
    """
    Save prediction to correct form in the csv file
    
    Parameters:
        preds: (numpy.ndarray) predictions in shape (files, samples, horizon)
        all_data: (dictionary) contains all the files for training and testing
        name: (string) the name of csv file
        labels: customly set label names, if using load_data with padding this might be useful.
    """

    dfs = []

    for i, (freq, (train, test)) in enumerate(all_data.items()):
        temp_preds = preds[i]
        df = pd.DataFrame(temp_preds)
        if len(labels) != 0:
            df.index = labels[i]
        else:
            df.index = train['V1']
        dfs.append(df)

    df_all = pd.concat(dfs)    
    df_all.to_csv(name + ".csv", header=True)
    
    
def save_results2(preds, all_data, name = "res"):
    """
    Save prediction to correct form in the csv file
    
    Parameters:
        preds: (numpy.ndarray) predictions in shape (samples, horizon)
        all_data: (dictionary) contains all the files for training and testing
        name: (string) the name of csv file
    """

    dfs = []
    
    pointer = 0

    for i, (freq, (train, test)) in enumerate(all_data.items()):
        len_t = len(train)
        temp_preds = preds[pointer:(pointer+len_t)]
        df = pd.DataFrame(temp_preds)
        df.index = train['V1']
        dfs.append(df)
        pointer += len_t

    df_all = pd.concat(dfs)    
    df_all.to_csv(name + ".csv", header=True)
    
# M4 Overall weighted average using Naive 1 as base
def owa_1k(mase, smape):
   naive_mase = 2.206989301
   naive_smape = 13.9261553
   return np.mean([mase/naive_mase, smape/naive_smape])

def owa_10k(mase, smape):
   naive_mase = 2.198950978
   naive_smape = 14.24176691
   return np.mean([mase/naive_mase, smape/naive_smape])

def owa_full(mase, smape):
   naive_mase = 2.207761361
   naive_smape = 14.30568004
   return np.mean([mase/naive_mase, smape/naive_smape])
