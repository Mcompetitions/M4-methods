# Auto-arima from forecasts package in R

Transformation selected by trying out different transformations on validation data and selecting the one with smallest MASE.
Set of transformations included: diff, log, diff log, boxcox, diff boxcox, none.

Questions: marten.veskimae@ut.ee