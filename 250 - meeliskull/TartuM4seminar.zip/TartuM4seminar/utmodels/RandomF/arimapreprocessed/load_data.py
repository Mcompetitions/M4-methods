# Script for loading in all the time-series data

import pandas as pd
from os.path import join
import numpy as np


def data_padding(df, filler_cols = 0):
    
    """
    Zero padding to the front
    
    Args:
        df: (pd.DataFrame)
        filler_cols: (int): how many columns to drop in front (i.e ID column)
        
    Return:
        array: (np.ndarray): zero-padded numpy array
    """
    
    array = np.zeros((df.shape[0], df.shape[1]-filler_cols))


    for ix, item in df.iterrows():

        values = item[filler_cols:].values
        values = values[~pd.isnull(values)]  # Drop out NA values
        array[ix,-len(values):] = values
        
    return array
    
    
def get_labels(path_train, files):
    """
    Get labels of data
    
    Parameters:
        path_train: (string) path to train folder
        files: (list) list containing all the file names (test and train file names must match)
        
    Returns:
        list: it contains all the labels of train files loaded.
        
    """
    
    labels = []
    
    for file in files:  # Go through all the files
        
        data_train = pd.read_csv(join(path_train,file))
        new_labels = np.array(data_train["V1"])  # Labels of data
        labels.append(new_labels)
     
    return np.array(labels)
    
    
def load_all_data(path_train, path_test, files, filler_cols = (2,1)):
    
    """
    Load in all the time series from all the specified files
    
    Parameters:
        path_train: (string) path to train folder
        path_test: (string) path to test folder
        files: (list) list containing all the file names (test and train file names must match)
        filler_cols: (tuple) how many filler columns does the train and test file have in front
        
    Returns:
        ((train_f1, test_f1), (train_f2, test_f2), ...): Tuple containing all the train and test files loaded.
        
    """
    
    all_data = []
    
    for file in files:  # Go through all the files
        
        data_train = pd.read_csv(join(path_train,file))  # Read in files as pandas dataframe
        data_test = pd.read_csv(join(path_test,file))
        
        array_train = data_padding(data_train, filler_cols[0])  # Front pad data and drop filler cols
        array_test = np.array(data_test)[:, filler_cols[1]:]  # Leave out filler columns in front
        
        all_data.append([array_train, array_test])
        
    all_data_t = tuple(map(tuple, all_data))  # Convert into tuple for return
        
    return all_data_t
    

def load_all_data_pd(path_train, path_test, files):
    
    """
    Load in all the time series data from all the specified files as Pandas Dataframes
    
    Parameters:
        path_train: (string) path to train folder
        path_test: (string) path to test folder
        files: (list) list containing all the file names (test and train file names must match)
        
    Returns:
        ((train_f1, test_f1), (train_f2, test_f2), ...): Tuple containing all the train and test files loaded.
        
    """
    
    all_data = []
    
    for file in files:  # Go through all the files
        
        data_train = pd.read_csv(join(path_train,file))  # Read in files as pandas dataframe
        data_test = pd.read_csv(join(path_test,file))
        
        all_data.append([data_train, data_test])
        
    all_data_t = tuple(map(tuple, all_data))
        
    return all_data_t
