# XGBoost2 scripts

from utmodels.utils.load_data import load_all_data, load_all_data_pd, get_labels
from utmodels.utils.evaluation import MASE, sMAPE, OWA
from .training import train_model

from os.path import join
import numpy as np
from xgboost import XGBRegressor  # Install XGBoost, (http://xgboost.readthedocs.io/en/latest/python/python_intro.html).


def main(dataset_path, result_path, validation_cut='full'):
    path_train = join(dataset_path, "cut", "full","train")  # Path to train datasets
    path_test = join(dataset_path, "cut","full","test")  # Path to test datasets
    files = ["Daily.csv", "Hourly.csv", "Monthly.csv", "Quarterly.csv", "Weekly.csv", "Yearly.csv"]  # Used files in path
    
    (train_da, test_da), (train_ho, test_ho), (train_mo, test_mo),\
    (train_qu, test_qu), (train_we, test_we), (train_ye, test_ye) = load_all_data_pd(path_train, path_test, files)

    all_data = {"daily" : (train_da, test_da),
                "hourly": (train_ho, test_ho),
                "monthly": (train_mo, test_mo),
                "quarterly": (train_qu, test_qu), 
                "weekly": (train_we, test_we),
                "yearly": (train_ye, test_ye)}

    y_preds_xgb = train_model(XGBRegressor, all_data, is_final_train = True, csv_name="RandomF_XGBoost2_test", labels=labels)


# standalone execution 
if __name__ == "__main__":
    # TODO: receive from the input
    dataset_path = None
    result_path = None
    validation_cut = None
    main(dataset_path, result_path, validation_cut)      
