# Naive 1 scripts

from utmodels.utils.load_data import load_all_data_pd
import numpy as np
from os.path import join

import numpy as np
from utmodels.utils.evaluation import MASE, sMAPE, OWA, save_results
import time
import pandas as pd
from tqdm import tqdm


season_horizon = {"daily" : (1, 14),
                "hourly": (24, 48),
                "monthly": (12, 18),
                "quarterly": (4, 8), 
                "weekly": (1, 13),
                "yearly": (1, 6)}

                
def train_model_naive(data, filler_cols = (2,1), method = "naive1", is_final_train=False, csv_name = None, pbar=None):
    '''
    Use all the data to train models for each row using given method
    
    Parameters:
        data: (dict) containing key: train, test
        filler_cols: (tuple) 2-element tuple containing number of filler cols for train and test
        method: (string) method name one of this set ("naive1", "naive2")
        
    Returns:
        y_preds: (list) list containing all the predictions
    '''
    

    a = time.time()  # Starting time

    mases = []  # TODO convert to np.array
    smapes = []
    preds_all = []
 
    for freq, (train, test) in data.items():
        a1 = time.time()  # Time start

        test = test.values[:, filler_cols[1]:]  # Drop filler cols
        season, horizon = season_horizon[freq]  # Get seasonality and horizon (frequence)
        preds_single = np.zeros_like(test)

        # Get predictions one by one
        for ix, item in train.iterrows():
            if pbar:
                pbar.update(1)
            values = item[filler_cols[0]:].values  # Drop filler cols
            train_row = values[~pd.isnull(values)]  # Drop NA values
            test_row = test[ix]  # Get correct row and drop filler cols
            
            if is_final_train:  # add the test_row in the end of train_row if final results needed
                train_row = np.concatenate([train_row, test_row])

            # Get Naive results
            if method == "naive1":
                y_preds = [train_row[-1]]*horizon  # Get last element as predictions (Naive 1)\n",
            else: #1method == "naive2":
                y_preds = [train_row[-season + (i % season)] for i in range(horizon)]  # Get last element as predictions (Naive 2)\n",
            preds_single[ix, :] = y_preds
            
            if not is_final_train:
                mase = MASE(train_row, test_row, y_preds, season)

                if mase < 10000000:
                    mases.append(mase)            
                    smapes.append(sMAPE(test_row, y_preds))

        preds_single = np.array(preds_single)  # Back to numpy array
        preds_all.append(preds_single)

        b1 = time.time()  # Time end
        total1 = b1 - a1
        #print("%s: %.3f" % (freq, total1))

    # Time 
    b = time.time()
    total = b - a
    print("Total time taken: ", total, "\n")  # How much time spent?
    
    if not is_final_train:

        print("MASEs:", len(mases))
        print("sMAPEs:", len(smapes))    
        print("MASEs min: %.3f max: %.3f" % (min(mases), max(mases)))
        print("SMAPES min: %.3f max: %.3f\n" % (min(smapes), max(smapes)))

        # Average scores
        mase_avg = np.mean(mases)
        smape_avg = np.mean(smapes)
        owa = OWA(mase_avg, smape_avg)  # Weighted average
        print("MASE avg:", mase_avg)
        print("sMAPE avg:", smape_avg)
        print("OWA:", owa)
        
    if csv_name != None:
        save_results(preds_all, data, csv_name)

    return preds_all, mases


MODEL_NAME = 'naive1'

def main(dataset_path, result_path, validation_cut='full', **kwargs):
    path_train = join(dataset_path, "cut", "full","train")  # Path to train datasets
    path_test = join(dataset_path, "cut","full","test")  # Path to test datasets
    files = ["Daily.csv", "Hourly.csv", "Monthly.csv", "Quarterly.csv", "Weekly.csv", "Yearly.csv"]  # Used files in path
    
    (train_da, test_da), (train_ho, test_ho), (train_mo, test_mo),\
    (train_qu, test_qu), (train_we, test_we), (train_ye, test_ye) = load_all_data_pd(path_train, path_test, files)

    all_data = {"daily" : (train_da, test_da),
                "hourly": (train_ho, test_ho),
                "monthly": (train_mo, test_mo),
                "quarterly": (train_qu, test_qu), 
                "weekly": (train_we, test_we),
                "yearly": (train_ye, test_ye)}

    # tqdm info setup
    if 'tqdm_info' in kwargs.keys():
        tqdm_info = kwargs['tqdm_info']
    else: # on standalone
        tqdm_info = {'position': 0, 'desc': MODEL_NAME}
    total=0
    for _, (train, _) in all_data.items():
       total+= train.shape[0]
    tqdm_info=kwargs['tqdm_info']
    pbar = tqdm(total=total, position=tqdm_info['position'], desc=tqdm_info['desc'])

    save_path = join(result_path['root'], "naive1_full_holdout.csv")

    # train and prediction 
    y_preds_n1_full = train_model_naive(method="naive1", data = all_data,
                                        filler_cols=(1,0), is_final_train=False,
                                        csv_name=save_path, pbar=pbar)
    pbar.close()

    # TODO: do the same for the test data


# standalone execution of the model
if __name__ == "__main__":
    # Parsing arguments
    parser = ArgumentParser(description='A model source code example')
    parser.add_argument('-d', '--dataset-dir', required=True, help='Path to the dataset directory')
    parser.add_argument('-r', '--results-dir', required=True, nargs=1, help='Path to the results directory')
    parser.add_argument('-c', '--validation-cut', default='full', nargs=1, help='validation cut: 1000, 10000, full ')
    # parser.add_argument('-s', '--datasets', nargs='+', help='list of datasets, i.e. [Hourly, Daily]')

    args = parser.parse_args()
    results_dir = {'holdout': os.path.join(args.results_dir[0], 'holdout'),
                   'test': os.path.join(args.results_dir[0], 'test'),
                   'root': args.results_dir[0] }

    print(args.dataset_dir, results_dir, args.validation_cut[0])
    main(args.dataset_dir, results_dir, args.validation_cut[0])
