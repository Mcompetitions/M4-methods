import os 
import numpy as np
import pandas as pd
from argparse import ArgumentParser


def example_method(data, test, train_f, m4info, bpar):
    return None


def save_preds(preds, path):
    pass


def load_dataset(dataset_path, files):
    """ you own dataset loading procedure """
    return None, None, None, None


MODEL_NAME = 'example'

# to be called by the run_models.py in the root of the project
def main(dataset_path, result_path, validation_cut='full', **kwargs):
    # loading data
    train, test, train_final, m4info = load_dataset(dataset_path, sets)

    # tqdm info setup
    if 'tqdm_info' in kwargs.keys():
        tqdm_info = kwargs['tqdm_info']
    else: # on standalone
        tqdm_info = {'position': 0, 'desc': MODEL_NAME}
    total=0
    for k in train.keys():
       total += train[k].shape[0]
    tqdm_info=kwargs['tqdm_info']
    pbar = tqdm(total=total, position=tqdm_info['position'], desc=tqdm_info['desc'])

    # Your model and its prediction
    y_preds = example_method(train, test, train_final, m4info, bpar)
    pbar.close()
    
    # Save the prediction
    save_path = join(result_path['root'], "example_full_holdout.csv")
    save_preds(preds, save_path)
    # use the result_path to save the model
    # run once for validation on full dataset once for the final submission
    result_path['root'] # root directory for the results
    result_path['holdout'] # directory for saving the holdouts predictions
    result_path['test'] # directory for saving the test predictions

    # naming convention for the prediction files:
    # TEAMNAME_METHOD_DATASET/CUTSIZE_TYPE
    # examples: RandomF_arima_full_holdout.csv
    #           RandomF_arima_yeaerlfull_holdout.csv
    #           RandomF_arima_daily1000_holdout.csv
    #           RandomF_arima_full_test.csv
 

# standalone execution of the model
if __name__ == "__main__":
    # Parsing arguments
    parser = ArgumentParser(description='A model source code example')
    parser.add_argument('-d', '--dataset-dir', required=True, help='Path to the dataset directory')
    parser.add_argument('-r', '--results-dir', required=True, nargs=1, help='Path to the results directory')
    parser.add_argument('-c', '--validation-cut', default='full', nargs=1, help='validation cut: 1000, 10000, full ')
    # parser.add_argument('-s', '--datasets', nargs='+', help='list of datasets, i.e. [Hourly, Daily]')

    args = parser.parse_args()
    results_dir = {'holdout': os.path.join(args.results_dir[0], 'holdout'),
                   'test': os.path.join(args.results_dir[0], 'test'),
                   'root': args.results_dir[0] }

    print(args.dataset_dir, results_dir, args.validation_cut[0])
    main(args.dataset_dir, results_dir, args.validation_cut[0])
