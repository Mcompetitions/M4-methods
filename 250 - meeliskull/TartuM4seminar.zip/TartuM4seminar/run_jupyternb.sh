export PYTHONPATH=${PYTHONPATH}:${PWD}
export PATH=${PATH}:${PWD}
jupyter notebook --notebook-dir=./
