library(readxl)
library(dplyr)

Hourly_submit <- read_excel("Hourly_test.xlsx")
in_test <- Hourly_submit[,c("V1","team")]

submit_final <- inner_join(Hourly_submit,in_test,by=c("V1","team")) %>%
    group_by(V1) %>%
    summarise_at(vars(-team),median)
submit_final[submit_final<0] <- 0
write.csv(submit_final,"submit_final.csv",row.names = F,quote = F,na = "")