﻿Option Strict Off
Option Explicit On

Public Class clsCommonMath

    Public Shared Function MeanOfArray(ByRef dValues() As Double, _
                                                                      Optional ByVal bIncludeZeroPosition As Boolean = False) As Double
        'Find the Mean of an Array
        Dim n As Integer

        On Error GoTo ErrorHandler

        Dim L As Long
        Dim U As Long

        'estimate lower bound
        L = LBound(dValues)
        If L = 0 And bIncludeZeroPosition = False Then
            L = 1
        End If

        'estimate upper bound
        U = UBound(dValues)

        'number of points
        n = U - L + 1

        'Calc mean
        MeanOfArray = SumOfArray(dValues) / n

        GoTo CleanExit

        Exit Function

ErrorHandler:

CleanExit:

    End Function

    Public Shared Function SumOfArray(ByRef dValues() As Double, _
                                                                Optional ByVal bIncludeZeroPosition As Boolean = False) As Double
        'Find the Sum of an Array
        Dim dSum As Double
        Dim i As Integer

        On Error GoTo ErrorHandler

        Dim L As Long
        Dim U As Long

        'estimate lower bound
        L = LBound(dValues)
        If L = 0 And bIncludeZeroPosition = False Then
            L = 1
        End If

        'estimate upper bound
        U = UBound(dValues)

        'Calc sum
        dSum = 0
        For i = L To U
            dSum = dSum + dValues(i)
        Next

        SumOfArray = dSum

        GoTo CleanExit

        Exit Function

ErrorHandler:

CleanExit:

    End Function

    Public Shared Function Diakimansi(ByRef dValues() As Double) As Double
        'Õðïëïãéóìüò Äéákýìáíóçò
        Dim dSum As Double
        Dim dMean As Double
        Dim i As Integer
        Dim n As Integer

        dSum = 0
        n = UBound(dValues)
        dMean = MeanOfArray(dValues)

        For i = 1 To n
            dSum = dSum + (dValues(i) - dMean) ^ 2
        Next i

        If (n - 1) <> 0 Then
            Diakimansi = System.Math.Sqrt(dSum / (n - 1))
        Else
            'MsgBox "Only one data ." + Chr(10) + "Returned value equal to zero.", 16, "Subroutine S_Array - Error 01."
            Diakimansi = 0
            Exit Function
        End If

    End Function

    Public Shared Function TipikiApoklisi(ByRef dValues() As Double) As Double
        'Õðïëïãéóìüò ôõðéêÞò áðüêëéóçò
        'checked OK
        Dim dSum As Double
        Dim dMean As Double
        Dim i As Integer
        Dim n As Integer

        dSum = 0
        dMean = MeanOfArray(dValues)
        n = UBound(dValues)

        For i = 1 To n
            dSum = dSum + (dValues(i) - dMean) ^ 2
        Next i

        If (n - 1) <> 0 Then
            TipikiApoklisi = dSum / (n - 1)
        Else
            'MsgBox "Only one data ." + Chr(10) + "Returned value equal to zero.", 16, "Subroutine S2_Array - Error 01."
            Exit Function
            TipikiApoklisi = 0
        End If

    End Function

    Public Shared Function Max_FromTwo(ByVal dFirst As Double, _
                                                                    ByVal dSecond As Double) As Double
        'checked OK
        Dim dMax As Double

        On Error GoTo ErrorHandler

        If dFirst >= dSecond Then
            dMax = dFirst
        Else
            dMax = dSecond
        End If

        Max_FromTwo = dMax

        GoTo CleanExit

        Exit Function

ErrorHandler:
        'MsgBox(Err.Description, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Max_FromTwo")

CleanExit:

    End Function

    Public Shared Function Min_FromTwo(ByRef dFirst As Double,
                                                                    ByRef dSecond As Double) As Double
        'checked OK
        Dim dMin As Double

        On Error GoTo ErrorHandler

        If dFirst <= dSecond Then
            dMin = dFirst
        Else
            dMin = dSecond
        End If

        Min_FromTwo = dMin

        GoTo CleanExit

        Exit Function

ErrorHandler:
        MsgBox(Err.Description, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Min_FromTwo")

CleanExit:

    End Function

    Public Shared Function Min_FromArray(ByRef dValues() As Double,
                                                                            ByVal iStartFrom As Long,
                                                                            ByRef dMin As Double,
                                                                            ByRef iMinPosition As Integer,
                                                                            ByRef sErrorMessage As String) As Boolean
        'checked OK
        Dim i As Integer

        Try
            'init

            If iStartFrom < 0 Then iStartFrom = LBound(dValues)
            dMin = dValues(iStartFrom)
            iMinPosition = iStartFrom

            For i = iStartFrom + 1 To UBound(dValues)
                If dValues(i) < dMin Then
                    dMin = dValues(i)
                    iMinPosition = i
                End If
            Next i

            Min_FromArray = True

        Catch ex As Exception
            Min_FromArray = False
        Finally

        End Try

    End Function

    Public Shared Function Return_Min_FromArray(ByRef dValues() As Double,
                                                                            ByVal iStartFrom As Long,
                                                                            ByRef sErrorMessage As String) As Double
        'checked OK
        Dim i As Integer
        Dim dMin As Double
        Dim iMinPosition As Integer

        Try
            'init

            If iStartFrom < 0 Then iStartFrom = LBound(dValues)
            dMin = dValues(iStartFrom)
            iMinPosition = iStartFrom

            For i = iStartFrom + 1 To UBound(dValues)
                If dValues(i) < dMin Then
                    dMin = dValues(i)
                    iMinPosition = i
                End If
            Next i

            Return_Min_FromArray = dMin

        Catch ex As Exception
            Return_Min_FromArray = 0
        Finally

        End Try

    End Function

    Public Shared Function Max_FromArray(ByRef dValues() As Double,
                                                                            ByVal iStartFrom As Long,
                                                                            ByRef dMax As Double,
                                                                            ByRef iMinPosition As Integer,
                                                                            ByRef sErrorMessage As String) As Boolean
        'checked OK
        Dim i As Integer

        Try
            'init

            If iStartFrom < 0 Then iStartFrom = LBound(dValues)
            dMax = dValues(iStartFrom)
            iMinPosition = iStartFrom

            For i = iStartFrom + 1 To UBound(dValues)
                If dValues(i) > dMax Then
                    dMax = dValues(i)
                    iMinPosition = i
                End If
            Next i

            Max_FromArray = True

        Catch ex As Exception
            Max_FromArray = False
        Finally

        End Try

    End Function

    Public Shared Function Return_Max_FromArray(ByRef dValues() As Double,
                                                                            ByVal iStartFrom As Long,
                                                                            ByRef sErrorMessage As String) As Double
        'checked OK
        Dim i As Integer
        Dim dMax As Double
        Dim iMaxPosition As Integer

        Try
            'init

            If iStartFrom < 0 Then iStartFrom = LBound(dValues)
            dMax = dValues(iStartFrom)
            iMaxPosition = iStartFrom

            For i = iStartFrom + 1 To UBound(dValues)
                If dValues(i) > dMax Then
                    dMax = dValues(i)
                    iMaxPosition = i
                End If
            Next i

            Return_Max_FromArray = dMax

        Catch ex As Exception
            Return_Max_FromArray = 0
        Finally

        End Try

    End Function
    Public Shared Function IsOdd(ByVal iNum As Integer) As Boolean

        IsOdd = (Convert.ToInt16(iNum \ 2) * 2 <> iNum)

    End Function

    Public Shared Function Sort_BySelection(ByRef dList() As Double) As Boolean
        'Selectionsort is a very simple algorithm. First you search the list for
        'the smallest item. Then you swap that item with the item at the top of
        'the list. Next you find the second smallest item and swap it with the
        'second item in the list. You continue finding the next smallest item and
        'swapping it into its final position in the list until you have swapped
        'all of the items to their final positions

        'checked OK

        Dim i As Integer
        Dim j As Integer
        Dim dMin As Double
        Dim iPos As Integer
        Dim dTemp As Double
        Dim sErrorMessage As String = String.Empty

        On Error GoTo ErrorHandler

        j = LBound(dList)
        Do Until j >= UBound(dList)
            Min_FromArray(dList, j, dMin, iPos, sErrorMessage)
            dTemp = dList(j)
            dList(j) = dMin
            dList(iPos) = dTemp
            j = j + 1
        Loop

        Sort_BySelection = True

        GoTo CleanExit

        Exit Function

ErrorHandler:
        Sort_BySelection = False

CleanExit:


    End Function

    Public Shared Function Median(ByRef dValues() As Double) As Double
        'Find the Median of an Array
        'checked OK
        Dim dTemp As Double
        Dim iPos As Integer
        Dim n As Integer

        On Error GoTo ErrorHandler

        'sort the list
        Sort_BySelection(dValues)

        'Number of items
        n = UBound(dValues) '- LBound(dValues) + 1

        If n Mod 2 = 0 Then
            'odd items
            iPos = (n / 2) '+ LBound(dValues) - 1
            dTemp = (dValues(iPos) + dValues(iPos + 1)) / 2
        Else
            'even items
            iPos = ((n + 1) / 2) '+ LBound(dValues) - 1
            dTemp = dValues(iPos)
        End If

        Median = dTemp

        GoTo CleanExit

        Exit Function

ErrorHandler:

CleanExit:

    End Function

    Public Shared Function LongNumber_IsPrime(ByVal iNumber As Long) As Boolean

        'checked OK

        Dim TestNum As Long
        Dim TestLimit As Long

        'Eliminate even numbers
        If iNumber Mod 2 = 0 Then Exit Function

        'Loop through ODD numbers starting with 3
        TestNum = 3
        TestLimit = iNumber
        Do While TestLimit > TestNum

            If iNumber Mod TestNum = 0 Then
                'Uncomment this if you really want to know
                'MsgBox "Divisible by " & TestNum
                Exit Function
            End If

            'There's logic to this.  Think about it.
            TestLimit = iNumber \ TestNum

            'Remember, we only bother to check odd numbers
            TestNum = TestNum + 2
        Loop

        'If we made it through the loop, the number is a prime.
        LongNumber_IsPrime = True

    End Function

    Public Shared Function Number_InBetweenXY(ByVal Num As Object,
                                                                                    ByVal X As Object,
                                                                                    ByVal Y As Object) As Boolean
        'checked OK

        Dim bResult As Boolean

        'init
        bResult = False

        'check
        If IsNumeric(Num) And IsNumeric(X) And IsNumeric(Y) Then
            If X < Y Then
                If Num > X And Num < Y Then
                    bResult = True
                End If
            ElseIf Y < X Then
                If Num > Y And Num < X Then
                    bResult = True
                End If
            End If
        End If

        'result
        Number_InBetweenXY = bResult

    End Function

End Class
