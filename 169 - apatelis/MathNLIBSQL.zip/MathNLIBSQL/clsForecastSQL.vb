﻿Option Strict Off
Option Explicit On

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports Microsoft.SqlServer.Server

Public Class clsForecastSQL

    <Microsoft.SqlServer.Server.SqlFunction(IsDeterministic:=True, IsPrecise:=False)>
    Public Shared Function SQL_Forecast_SQ_LevelUp(sValuesSQL As SqlString, sDatesSQL As SqlString, sValuesSQL2 As SqlString, sDatesSQL2 As SqlString, sValuesSQL3 As SqlString, sDatesSQL3 As SqlString, sValuesSQL4 As SqlString, sDatesSQL4 As SqlString,
                                                                        sValuesSQL5 As SqlString, sDatesSQL5 As SqlString, sValuesSQL6 As SqlString, sDatesSQL6 As SqlString, sValuesSQL7 As SqlString, sDatesSQL7 As SqlString, sValuesSQL8 As SqlString, sDatesSQL8 As SqlString,
                                                                        sValuesSQL9 As SqlString, sDatesSQL9 As SqlString, sValuesSQL10 As SqlString, sDatesSQL10 As SqlString, sValuesSQL11 As SqlString, sDatesSQL11 As SqlString, sValuesSQL12 As SqlString, sDatesSQL12 As SqlString,
                                                                        sValuesSQL13 As SqlString, sDatesSQL13 As SqlString, sValuesSQL14 As SqlString, sDatesSQL14 As SqlString, sValuesSQL15 As SqlString, sDatesSQL15 As SqlString, sValuesSQL16 As SqlString, sDatesSQL16 As SqlString,
                                                                        sValuesSQL17 As SqlString, sDatesSQL17 As SqlString, sValuesSQL18 As SqlString, sDatesSQL18 As SqlString, sValuesSQL19 As SqlString, sDatesSQL19 As SqlString, sValuesSQL20 As SqlString, sDatesSQL20 As SqlString,
                                                                        sValuesSQL21 As SqlString, sDatesSQL21 As SqlString, sValuesSQL22 As SqlString, sDatesSQL22 As SqlString, sValuesSQL23 As SqlString, sDatesSQL23 As SqlString, sValuesSQL24 As SqlString, sDatesSQL24 As SqlString,
                                                                        sValuesSQL25 As SqlString, sDatesSQL25 As SqlString,
                                                                                                iSeasonalitySQL As SqlInt32,
                                                                                                sSeasonalityPatternSQL As SqlString,
                                                                                                iHorizonSQL As SqlInt32,
                                                                                                iMethodSQL As SqlInt32) As SqlString

        'Values are sent in a string (separator is @# --> every value up to 10  charts
        'Dates are in yyyymmdd format, in a string (separator is @#) --> thus every date needs 10 chars --> We can send up to 400 points
        'Time we can create ourselfes
        Dim sReturnForecasts As SqlString
        Dim sSeparator As String = "@#"

        'Build the INITIAL ARRAYS
        Dim bFlag As Boolean
        Dim iStep As Integer
        Dim iFrom As Integer
        Dim iTotal As Integer

        'split them
        Dim dData() As Double
        Dim dtDate() As Date
        Dim dTime() As Double

        'READ THE PACKAGE --> 1
        iTotal = Convert.ToString(sValuesSQL).Length / 10
        bFlag = False
        iStep = 0
        iFrom = 0
        Do Until bFlag = True
            iStep = iStep + 1
            iFrom = ((iStep - 1) * 10) + 1
            ReDim Preserve dData(iStep)
            ReDim Preserve dtDate(iStep)
            ReDim Preserve dTime(iStep)

            dData(iStep) = Convert.ToDouble(Mid(sValuesSQL, iFrom, 8))
            dtDate(iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL, iFrom + 6, 2)))
            dTime(iStep) = iStep

            If iStep >= iTotal Then
                bFlag = True
            Else
                bFlag = False
            End If
        Loop

        'READ THE PACKAGE --> 2
        If Convert.ToString(sValuesSQL2).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL2).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(400 + iStep)
                ReDim Preserve dtDate(400 + iStep)
                ReDim Preserve dTime(400 + iStep)

                dData(400 + iStep) = Convert.ToDouble(Mid(sValuesSQL2, iFrom, 8))
                dtDate(400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL2, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL2, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL2, iFrom + 6, 2)))
                dTime(400 + iStep) = 400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 3
        If Convert.ToString(sValuesSQL3).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL3).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(800 + iStep)
                ReDim Preserve dtDate(800 + iStep)
                ReDim Preserve dTime(800 + iStep)

                dData(800 + iStep) = Convert.ToDouble(Mid(sValuesSQL3, iFrom, 8))
                dtDate(800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL3, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL3, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL3, iFrom + 6, 2)))
                dTime(800 + iStep) = 800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 4
        If Convert.ToString(sValuesSQL4).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL4).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(1200 + iStep)
                ReDim Preserve dtDate(1200 + iStep)
                ReDim Preserve dTime(1200 + iStep)

                dData(1200 + iStep) = Convert.ToDouble(Mid(sValuesSQL4, iFrom, 8))
                dtDate(1200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL4, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL4, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL4, iFrom + 6, 2)))
                dTime(1200 + iStep) = 1200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 5
        If Convert.ToString(sValuesSQL5).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL5).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(1600 + iStep)
                ReDim Preserve dtDate(1600 + iStep)
                ReDim Preserve dTime(1600 + iStep)

                dData(1600 + iStep) = Convert.ToDouble(Mid(sValuesSQL5, iFrom, 8))
                dtDate(1600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL5, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL5, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL5, iFrom + 6, 2)))
                dTime(1600 + iStep) = 1600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 6
        If Convert.ToString(sValuesSQL6).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL6).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(2000 + iStep)
                ReDim Preserve dtDate(2000 + iStep)
                ReDim Preserve dTime(2000 + iStep)

                dData(2000 + iStep) = Convert.ToDouble(Mid(sValuesSQL6, iFrom, 8))
                dtDate(2000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL6, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL6, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL6, iFrom + 6, 2)))
                dTime(2000 + iStep) = 2000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 7
        If Convert.ToString(sValuesSQL7).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL7).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(2400 + iStep)
                ReDim Preserve dtDate(2400 + iStep)
                ReDim Preserve dTime(2400 + iStep)

                dData(2400 + iStep) = Convert.ToDouble(Mid(sValuesSQL7, iFrom, 8))
                dtDate(2400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL7, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL7, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL7, iFrom + 6, 2)))
                dTime(2400 + iStep) = 2400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 8
        If Convert.ToString(sValuesSQL8).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL8).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(2800 + iStep)
                ReDim Preserve dtDate(2800 + iStep)
                ReDim Preserve dTime(2800 + iStep)

                dData(2800 + iStep) = Convert.ToDouble(Mid(sValuesSQL8, iFrom, 8))
                dtDate(2800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL8, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL8, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL8, iFrom + 6, 2)))
                dTime(2800 + iStep) = 2800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 9
        If Convert.ToString(sValuesSQL9).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL9).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(3200 + iStep)
                ReDim Preserve dtDate(3200 + iStep)
                ReDim Preserve dTime(3200 + iStep)

                dData(3200 + iStep) = Convert.ToDouble(Mid(sValuesSQL9, iFrom, 8))
                dtDate(3200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL9, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL9, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL9, iFrom + 6, 2)))
                dTime(3200 + iStep) = 3200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 10
        If Convert.ToString(sValuesSQL10).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL10).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(3600 + iStep)
                ReDim Preserve dtDate(3600 + iStep)
                ReDim Preserve dTime(3600 + iStep)

                dData(3600 + iStep) = Convert.ToDouble(Mid(sValuesSQL10, iFrom, 8))
                dtDate(3600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL10, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL10, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL10, iFrom + 6, 2)))
                dTime(3600 + iStep) = 3600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 11
        If Convert.ToString(sValuesSQL11).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL11).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(4000 + iStep)
                ReDim Preserve dtDate(4000 + iStep)
                ReDim Preserve dTime(4000 + iStep)

                dData(4000 + iStep) = Convert.ToDouble(Mid(sValuesSQL11, iFrom, 8))
                dtDate(4000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL11, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL11, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL11, iFrom + 6, 2)))
                dTime(4000 + iStep) = 4000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 12
        If Convert.ToString(sValuesSQL12).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL12).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(4400 + iStep)
                ReDim Preserve dtDate(4400 + iStep)
                ReDim Preserve dTime(4400 + iStep)

                dData(4400 + iStep) = Convert.ToDouble(Mid(sValuesSQL12, iFrom, 8))
                dtDate(4400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL12, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL12, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL12, iFrom + 6, 2)))
                dTime(4400 + iStep) = 4400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 13
        If Convert.ToString(sValuesSQL13).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL13).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(4800 + iStep)
                ReDim Preserve dtDate(4800 + iStep)
                ReDim Preserve dTime(4800 + iStep)

                dData(4800 + iStep) = Convert.ToDouble(Mid(sValuesSQL13, iFrom, 8))
                dtDate(4800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL13, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL13, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL13, iFrom + 6, 2)))
                dTime(4800 + iStep) = 4800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 14
        If Convert.ToString(sValuesSQL14).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL14).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(5200 + iStep)
                ReDim Preserve dtDate(5200 + iStep)
                ReDim Preserve dTime(5200 + iStep)

                dData(5200 + iStep) = Convert.ToDouble(Mid(sValuesSQL14, iFrom, 8))
                dtDate(5200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL14, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL14, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL14, iFrom + 6, 2)))
                dTime(5200 + iStep) = 5200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 15
        If Convert.ToString(sValuesSQL15).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL15).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(5600 + iStep)
                ReDim Preserve dtDate(5600 + iStep)
                ReDim Preserve dTime(5600 + iStep)

                dData(5600 + iStep) = Convert.ToDouble(Mid(sValuesSQL15, iFrom, 8))
                dtDate(5600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL15, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL15, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL15, iFrom + 6, 2)))
                dTime(5600 + iStep) = 5600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 16
        If Convert.ToString(sValuesSQL16).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL16).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(6000 + iStep)
                ReDim Preserve dtDate(6000 + iStep)
                ReDim Preserve dTime(6000 + iStep)

                dData(6000 + iStep) = Convert.ToDouble(Mid(sValuesSQL16, iFrom, 8))
                dtDate(6000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL16, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL16, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL16, iFrom + 6, 2)))
                dTime(6000 + iStep) = 6000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 17
        If Convert.ToString(sValuesSQL17).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL17).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(6400 + iStep)
                ReDim Preserve dtDate(6400 + iStep)
                ReDim Preserve dTime(6400 + iStep)

                dData(6400 + iStep) = Convert.ToDouble(Mid(sValuesSQL17, iFrom, 8))
                dtDate(6400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL17, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL17, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL17, iFrom + 6, 2)))
                dTime(6400 + iStep) = 6400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 18
        If Convert.ToString(sValuesSQL18).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL18).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(6800 + iStep)
                ReDim Preserve dtDate(6800 + iStep)
                ReDim Preserve dTime(6800 + iStep)

                dData(6800 + iStep) = Convert.ToDouble(Mid(sValuesSQL18, iFrom, 8))
                dtDate(6800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL18, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL18, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL18, iFrom + 6, 2)))
                dTime(6800 + iStep) = 6800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 19
        If Convert.ToString(sValuesSQL19).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL19).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(7200 + iStep)
                ReDim Preserve dtDate(7200 + iStep)
                ReDim Preserve dTime(7200 + iStep)

                dData(7200 + iStep) = Convert.ToDouble(Mid(sValuesSQL19, iFrom, 8))
                dtDate(7200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL19, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL19, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL19, iFrom + 6, 2)))
                dTime(7200 + iStep) = 7200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 20
        If Convert.ToString(sValuesSQL20).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL20).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(7600 + iStep)
                ReDim Preserve dtDate(7600 + iStep)
                ReDim Preserve dTime(7600 + iStep)

                dData(7600 + iStep) = Convert.ToDouble(Mid(sValuesSQL20, iFrom, 8))
                dtDate(7600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL20, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL20, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL20, iFrom + 6, 2)))
                dTime(7600 + iStep) = 7600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 21
        If Convert.ToString(sValuesSQL21).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL21).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(8000 + iStep)
                ReDim Preserve dtDate(8000 + iStep)
                ReDim Preserve dTime(8000 + iStep)

                dData(8000 + iStep) = Convert.ToDouble(Mid(sValuesSQL21, iFrom, 8))
                dtDate(8000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL21, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL21, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL21, iFrom + 6, 2)))
                dTime(8000 + iStep) = 8000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 22
        If Convert.ToString(sValuesSQL22).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL22).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(8400 + iStep)
                ReDim Preserve dtDate(8400 + iStep)
                ReDim Preserve dTime(8400 + iStep)

                dData(8400 + iStep) = Convert.ToDouble(Mid(sValuesSQL22, iFrom, 8))
                dtDate(8400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL22, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL22, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL22, iFrom + 6, 2)))
                dTime(8400 + iStep) = 8400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 23
        If Convert.ToString(sValuesSQL23).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL23).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(8800 + iStep)
                ReDim Preserve dtDate(8800 + iStep)
                ReDim Preserve dTime(8800 + iStep)

                dData(8800 + iStep) = Convert.ToDouble(Mid(sValuesSQL23, iFrom, 8))
                dtDate(8800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL23, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL23, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL23, iFrom + 6, 2)))
                dTime(8800 + iStep) = 8800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 24
        If Convert.ToString(sValuesSQL24).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL24).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(9200 + iStep)
                ReDim Preserve dtDate(9200 + iStep)
                ReDim Preserve dTime(9200 + iStep)

                dData(9200 + iStep) = Convert.ToDouble(Mid(sValuesSQL24, iFrom, 8))
                dtDate(9200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL24, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL24, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL24, iFrom + 6, 2)))
                dTime(9200 + iStep) = 9200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 25
        If Convert.ToString(sValuesSQL25).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL25).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(9600 + iStep)
                ReDim Preserve dtDate(9600 + iStep)
                ReDim Preserve dTime(9600 + iStep)

                dData(9600 + iStep) = Convert.ToDouble(Mid(sValuesSQL25, iFrom, 8))
                dtDate(9600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL25, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL25, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL25, iFrom + 6, 2)))
                dTime(9600 + iStep) = 9600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'rest variables
        Dim iSeasonality As Integer
        iSeasonality = iSeasonalitySQL
        Dim iSeasonalPattern(iSeasonality) As Integer
        Dim j As Integer
        For j = 1 To iSeasonality
            iSeasonalPattern(j) = Convert.ToInt32(Mid(sSeasonalityPatternSQL, j, 1))
        Next j
        Dim iHorizon As Integer
        iHorizon = iHorizonSQL
        Dim iMethod As Integer
        iMethod = iMethodSQL

        'Correction for HOURLY data, since we are not passing the hour of the dtDates
        If iSeasonality = 24 Then
            For k = 1 To UBound(dtDate)
                dtDate(k) = dtDate(k).AddHours(k)
            Next k
        End If

        'Now you can call the forecast method, as before
        Dim dForecasts() As Double
        clsForecast.Forecast_SQ_LevelUp(iMethod, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecasts)

        'OK. 
        'now return the results as a string
        Dim sEmpty As String = "        "
        sReturnForecasts = ""
        For j = 1 To UBound(dForecasts)
            If Convert.ToString(dForecasts(j)).Length <= 8 Then
                sReturnForecasts = sReturnForecasts + Convert.ToString(dForecasts(j)) + Left(sEmpty, 8 - Convert.ToString(dForecasts(j)).Length) + "@#"
            Else
                sReturnForecasts = sReturnForecasts + Left(Convert.ToString(dForecasts(j)), 8) + "@#"
            End If
        Next j

        Return sReturnForecasts

    End Function

    <Microsoft.SqlServer.Server.SqlFunction(IsDeterministic:=True, IsPrecise:=False)>
    Public Shared Function SQL_ForecastAverageTwo(sValuesSQL As SqlString, sDatesSQL As SqlString, sValuesSQL2 As SqlString, sDatesSQL2 As SqlString, sValuesSQL3 As SqlString, sDatesSQL3 As SqlString, sValuesSQL4 As SqlString, sDatesSQL4 As SqlString,
                                                                        sValuesSQL5 As SqlString, sDatesSQL5 As SqlString, sValuesSQL6 As SqlString, sDatesSQL6 As SqlString, sValuesSQL7 As SqlString, sDatesSQL7 As SqlString, sValuesSQL8 As SqlString, sDatesSQL8 As SqlString,
                                                                        sValuesSQL9 As SqlString, sDatesSQL9 As SqlString, sValuesSQL10 As SqlString, sDatesSQL10 As SqlString, sValuesSQL11 As SqlString, sDatesSQL11 As SqlString, sValuesSQL12 As SqlString, sDatesSQL12 As SqlString,
                                                                        sValuesSQL13 As SqlString, sDatesSQL13 As SqlString, sValuesSQL14 As SqlString, sDatesSQL14 As SqlString, sValuesSQL15 As SqlString, sDatesSQL15 As SqlString, sValuesSQL16 As SqlString, sDatesSQL16 As SqlString,
                                                                        sValuesSQL17 As SqlString, sDatesSQL17 As SqlString, sValuesSQL18 As SqlString, sDatesSQL18 As SqlString, sValuesSQL19 As SqlString, sDatesSQL19 As SqlString, sValuesSQL20 As SqlString, sDatesSQL20 As SqlString,
                                                                        sValuesSQL21 As SqlString, sDatesSQL21 As SqlString, sValuesSQL22 As SqlString, sDatesSQL22 As SqlString, sValuesSQL23 As SqlString, sDatesSQL23 As SqlString, sValuesSQL24 As SqlString, sDatesSQL24 As SqlString,
                                                                        sValuesSQL25 As SqlString, sDatesSQL25 As SqlString,
                                                                                            iSeasonalitySQL As SqlInt32,
                                                                                            iSeasonalitySQLForCalcNextDate As SqlInt32,
                                                                                            sSeasonalityPatternSQL As SqlString,
                                                                                            sSeasonalityPatternSQLForCalcNextDate As SqlString,
                                                                                            iHorizonSQL As SqlInt32,
                                                                                            iMethodSQLA As SqlInt32, iMethodSQLB As SqlInt32,
                                                                                            iWeightSQLA As SqlInt32, iWeightSQLB As SqlInt32,
                                                                                            iMethodSQLA_SQ_LU As SqlInt32, iMethodSQLB_SQ_LU As SqlInt32) As SqlString

        'Values are sent in a string (separator is @# --> every value up to 10  charts
        'Dates are in yyyymmdd format, in a string (separator is @#) --> thus every date needs 10 chars --> We can send up to 400 points
        'Time we can create ourselfes
        Dim sReturnForecasts As SqlString
        Dim sSeparator As String = "@#"

        'Build the INITIAL ARRAYS
        Dim bFlag As Boolean
        Dim iStep As Integer
        Dim iFrom As Integer
        Dim iTotal As Integer


        'split them
        Dim dData() As Double
        Dim dtDate() As Date
        Dim dTime() As Double

        'READ THE PACKAGE --> 1
        iTotal = Convert.ToString(sValuesSQL).Length / 10
        bFlag = False
        iStep = 0
        iFrom = 0
        Do Until bFlag = True
            iStep = iStep + 1
            iFrom = ((iStep - 1) * 10) + 1
            ReDim Preserve dData(iStep)
            ReDim Preserve dtDate(iStep)
            ReDim Preserve dTime(iStep)

            dData(iStep) = Convert.ToDouble(Mid(sValuesSQL, iFrom, 8))
            dtDate(iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL, iFrom + 6, 2)))
            dTime(iStep) = iStep

            If iStep >= iTotal Then
                bFlag = True
            Else
                bFlag = False
            End If
        Loop

        'READ THE PACKAGE --> 2
        If Convert.ToString(sValuesSQL2).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL2).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(400 + iStep)
                ReDim Preserve dtDate(400 + iStep)
                ReDim Preserve dTime(400 + iStep)

                dData(400 + iStep) = Convert.ToDouble(Mid(sValuesSQL2, iFrom, 8))
                dtDate(400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL2, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL2, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL2, iFrom + 6, 2)))
                dTime(400 + iStep) = 400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 3
        If Convert.ToString(sValuesSQL3).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL3).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(800 + iStep)
                ReDim Preserve dtDate(800 + iStep)
                ReDim Preserve dTime(800 + iStep)

                dData(800 + iStep) = Convert.ToDouble(Mid(sValuesSQL3, iFrom, 8))
                dtDate(800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL3, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL3, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL3, iFrom + 6, 2)))
                dTime(800 + iStep) = 800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 4
        If Convert.ToString(sValuesSQL4).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL4).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(1200 + iStep)
                ReDim Preserve dtDate(1200 + iStep)
                ReDim Preserve dTime(1200 + iStep)

                dData(1200 + iStep) = Convert.ToDouble(Mid(sValuesSQL4, iFrom, 8))
                dtDate(1200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL4, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL4, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL4, iFrom + 6, 2)))
                dTime(1200 + iStep) = 1200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 5
        If Convert.ToString(sValuesSQL5).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL5).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(1600 + iStep)
                ReDim Preserve dtDate(1600 + iStep)
                ReDim Preserve dTime(1600 + iStep)

                dData(1600 + iStep) = Convert.ToDouble(Mid(sValuesSQL5, iFrom, 8))
                dtDate(1600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL5, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL5, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL5, iFrom + 6, 2)))
                dTime(1600 + iStep) = 1600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 6
        If Convert.ToString(sValuesSQL6).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL6).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(2000 + iStep)
                ReDim Preserve dtDate(2000 + iStep)
                ReDim Preserve dTime(2000 + iStep)

                dData(2000 + iStep) = Convert.ToDouble(Mid(sValuesSQL6, iFrom, 8))
                dtDate(2000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL6, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL6, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL6, iFrom + 6, 2)))
                dTime(2000 + iStep) = 2000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 7
        If Convert.ToString(sValuesSQL7).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL7).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(2400 + iStep)
                ReDim Preserve dtDate(2400 + iStep)
                ReDim Preserve dTime(2400 + iStep)

                dData(2400 + iStep) = Convert.ToDouble(Mid(sValuesSQL7, iFrom, 8))
                dtDate(2400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL7, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL7, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL7, iFrom + 6, 2)))
                dTime(2400 + iStep) = 2400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 8
        If Convert.ToString(sValuesSQL8).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL8).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(2800 + iStep)
                ReDim Preserve dtDate(2800 + iStep)
                ReDim Preserve dTime(2800 + iStep)

                dData(2800 + iStep) = Convert.ToDouble(Mid(sValuesSQL8, iFrom, 8))
                dtDate(2800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL8, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL8, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL8, iFrom + 6, 2)))
                dTime(2800 + iStep) = 2800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 9
        If Convert.ToString(sValuesSQL9).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL9).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(3200 + iStep)
                ReDim Preserve dtDate(3200 + iStep)
                ReDim Preserve dTime(3200 + iStep)

                dData(3200 + iStep) = Convert.ToDouble(Mid(sValuesSQL9, iFrom, 8))
                dtDate(3200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL9, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL9, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL9, iFrom + 6, 2)))
                dTime(3200 + iStep) = 3200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 10
        If Convert.ToString(sValuesSQL10).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL10).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(3600 + iStep)
                ReDim Preserve dtDate(3600 + iStep)
                ReDim Preserve dTime(3600 + iStep)

                dData(3600 + iStep) = Convert.ToDouble(Mid(sValuesSQL10, iFrom, 8))
                dtDate(3600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL10, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL10, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL10, iFrom + 6, 2)))
                dTime(3600 + iStep) = 3600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 11
        If Convert.ToString(sValuesSQL11).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL11).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(4000 + iStep)
                ReDim Preserve dtDate(4000 + iStep)
                ReDim Preserve dTime(4000 + iStep)

                dData(4000 + iStep) = Convert.ToDouble(Mid(sValuesSQL11, iFrom, 8))
                dtDate(4000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL11, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL11, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL11, iFrom + 6, 2)))
                dTime(4000 + iStep) = 4000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 12
        If Convert.ToString(sValuesSQL12).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL12).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(4400 + iStep)
                ReDim Preserve dtDate(4400 + iStep)
                ReDim Preserve dTime(4400 + iStep)

                dData(4400 + iStep) = Convert.ToDouble(Mid(sValuesSQL12, iFrom, 8))
                dtDate(4400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL12, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL12, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL12, iFrom + 6, 2)))
                dTime(4400 + iStep) = 4400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 13
        If Convert.ToString(sValuesSQL13).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL13).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(4800 + iStep)
                ReDim Preserve dtDate(4800 + iStep)
                ReDim Preserve dTime(4800 + iStep)

                dData(4800 + iStep) = Convert.ToDouble(Mid(sValuesSQL13, iFrom, 8))
                dtDate(4800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL13, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL13, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL13, iFrom + 6, 2)))
                dTime(4800 + iStep) = 4800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 14
        If Convert.ToString(sValuesSQL14).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL14).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(5200 + iStep)
                ReDim Preserve dtDate(5200 + iStep)
                ReDim Preserve dTime(5200 + iStep)

                dData(5200 + iStep) = Convert.ToDouble(Mid(sValuesSQL14, iFrom, 8))
                dtDate(5200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL14, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL14, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL14, iFrom + 6, 2)))
                dTime(5200 + iStep) = 5200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 15
        If Convert.ToString(sValuesSQL15).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL15).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(5600 + iStep)
                ReDim Preserve dtDate(5600 + iStep)
                ReDim Preserve dTime(5600 + iStep)

                dData(5600 + iStep) = Convert.ToDouble(Mid(sValuesSQL15, iFrom, 8))
                dtDate(5600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL15, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL15, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL15, iFrom + 6, 2)))
                dTime(5600 + iStep) = 5600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 16
        If Convert.ToString(sValuesSQL16).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL16).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(6000 + iStep)
                ReDim Preserve dtDate(6000 + iStep)
                ReDim Preserve dTime(6000 + iStep)

                dData(6000 + iStep) = Convert.ToDouble(Mid(sValuesSQL16, iFrom, 8))
                dtDate(6000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL16, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL16, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL16, iFrom + 6, 2)))
                dTime(6000 + iStep) = 6000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 17
        If Convert.ToString(sValuesSQL17).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL17).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(6400 + iStep)
                ReDim Preserve dtDate(6400 + iStep)
                ReDim Preserve dTime(6400 + iStep)

                dData(6400 + iStep) = Convert.ToDouble(Mid(sValuesSQL17, iFrom, 8))
                dtDate(6400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL17, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL17, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL17, iFrom + 6, 2)))
                dTime(6400 + iStep) = 6400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 18
        If Convert.ToString(sValuesSQL18).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL18).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(6800 + iStep)
                ReDim Preserve dtDate(6800 + iStep)
                ReDim Preserve dTime(6800 + iStep)

                dData(6800 + iStep) = Convert.ToDouble(Mid(sValuesSQL18, iFrom, 8))
                dtDate(6800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL18, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL18, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL18, iFrom + 6, 2)))
                dTime(6800 + iStep) = 6800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 19
        If Convert.ToString(sValuesSQL19).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL19).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(7200 + iStep)
                ReDim Preserve dtDate(7200 + iStep)
                ReDim Preserve dTime(7200 + iStep)

                dData(7200 + iStep) = Convert.ToDouble(Mid(sValuesSQL19, iFrom, 8))
                dtDate(7200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL19, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL19, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL19, iFrom + 6, 2)))
                dTime(7200 + iStep) = 7200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 20
        If Convert.ToString(sValuesSQL20).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL20).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(7600 + iStep)
                ReDim Preserve dtDate(7600 + iStep)
                ReDim Preserve dTime(7600 + iStep)

                dData(7600 + iStep) = Convert.ToDouble(Mid(sValuesSQL20, iFrom, 8))
                dtDate(7600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL20, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL20, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL20, iFrom + 6, 2)))
                dTime(7600 + iStep) = 7600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 21
        If Convert.ToString(sValuesSQL21).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL21).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(8000 + iStep)
                ReDim Preserve dtDate(8000 + iStep)
                ReDim Preserve dTime(8000 + iStep)

                dData(8000 + iStep) = Convert.ToDouble(Mid(sValuesSQL21, iFrom, 8))
                dtDate(8000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL21, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL21, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL21, iFrom + 6, 2)))
                dTime(8000 + iStep) = 8000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 22
        If Convert.ToString(sValuesSQL22).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL22).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(8400 + iStep)
                ReDim Preserve dtDate(8400 + iStep)
                ReDim Preserve dTime(8400 + iStep)

                dData(8400 + iStep) = Convert.ToDouble(Mid(sValuesSQL22, iFrom, 8))
                dtDate(8400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL22, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL22, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL22, iFrom + 6, 2)))
                dTime(8400 + iStep) = 8400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 23
        If Convert.ToString(sValuesSQL23).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL23).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(8800 + iStep)
                ReDim Preserve dtDate(8800 + iStep)
                ReDim Preserve dTime(8800 + iStep)

                dData(8800 + iStep) = Convert.ToDouble(Mid(sValuesSQL23, iFrom, 8))
                dtDate(8800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL23, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL23, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL23, iFrom + 6, 2)))
                dTime(8800 + iStep) = 8800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 24
        If Convert.ToString(sValuesSQL24).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL24).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(9200 + iStep)
                ReDim Preserve dtDate(9200 + iStep)
                ReDim Preserve dTime(9200 + iStep)

                dData(9200 + iStep) = Convert.ToDouble(Mid(sValuesSQL24, iFrom, 8))
                dtDate(9200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL24, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL24, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL24, iFrom + 6, 2)))
                dTime(9200 + iStep) = 9200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 25
        If Convert.ToString(sValuesSQL25).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL25).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(9600 + iStep)
                ReDim Preserve dtDate(9600 + iStep)
                ReDim Preserve dTime(9600 + iStep)

                dData(9600 + iStep) = Convert.ToDouble(Mid(sValuesSQL25, iFrom, 8))
                dtDate(9600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL25, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL25, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL25, iFrom + 6, 2)))
                dTime(9600 + iStep) = 9600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'rest variables
        Dim iSeasonality As Integer
        iSeasonality = iSeasonalitySQL
        Dim iSeasonalPattern(iSeasonality) As Integer
        Dim j As Integer
        For j = 1 To iSeasonality
            iSeasonalPattern(j) = Convert.ToInt32(Mid(sSeasonalityPatternSQL, j, 1))
        Next j

        Dim iSeasonalityForCalcNextDate As Integer
        iSeasonalityForCalcNextDate = iSeasonalitySQLForCalcNextDate
        Dim iSeasonalPatternForCalcNextDate(iSeasonalityForCalcNextDate) As Integer
        For j = 1 To iSeasonalityForCalcNextDate
            iSeasonalPatternForCalcNextDate(j) = Convert.ToInt32(Mid(sSeasonalityPatternSQLForCalcNextDate, j, 1))
        Next j


        Dim iHorizon As Integer
        iHorizon = iHorizonSQL

        'find the methods
        Dim iMethodA As Integer
        Dim iMethodB As Integer
        iMethodA = iMethodSQLA
        iMethodB = iMethodSQLB

        'find the extra calls
        Dim iMethodA_SQ_LU As Integer
        Dim iMethodB_SQ_LU As Integer
        iMethodA_SQ_LU = iMethodSQLA_SQ_LU
        iMethodB_SQ_LU = iMethodSQLB_SQ_LU

        'find the weights
        Dim iWeightA As Integer
        Dim iWeightB As Integer
        iWeightA = iWeightSQLA
        iWeightB = iWeightSQLB

        'Correction for HOURLY data, since we are not passing the hour of the dtDates
        If iSeasonality = 24 Then
            For k = 1 To UBound(dtDate)
                dtDate(k) = dtDate(k).AddHours(k)
            Next k
        End If


        'Now you can call the forecast method, as before
        Dim dForecasts() As Double
        MathNLIBSQL.clsForecast.ForecastAverageTwo(iMethodA, iMethodB, iMethodA_SQ_LU, iMethodB_SQ_LU, iWeightA, iWeightB, dData, dtDate, dTime, iSeasonality, iSeasonalityForCalcNextDate, iSeasonalPattern, iSeasonalPatternForCalcNextDate, iHorizon, dForecasts)

        'OK. 
        'now return the results as a string
        Dim sEmpty As String = "        "
        sReturnForecasts = ""
        For j = 1 To UBound(dForecasts)
            If Convert.ToString(dForecasts(j)).Length <= 8 Then
                sReturnForecasts = sReturnForecasts + Convert.ToString(dForecasts(j)) + Left(sEmpty, 8 - Convert.ToString(dForecasts(j)).Length) + "@#"
            Else
                sReturnForecasts = sReturnForecasts + Left(Convert.ToString(dForecasts(j)), 8) + "@#"
            End If
        Next j

        Return sReturnForecasts

    End Function

    <Microsoft.SqlServer.Server.SqlFunction(IsDeterministic:=True, IsPrecise:=False)>
    Public Shared Function SQL_ForecastAverageThree(sValuesSQL As SqlString, sDatesSQL As SqlString, sValuesSQL2 As SqlString, sDatesSQL2 As SqlString, sValuesSQL3 As SqlString, sDatesSQL3 As SqlString, sValuesSQL4 As SqlString, sDatesSQL4 As SqlString,
                                                                        sValuesSQL5 As SqlString, sDatesSQL5 As SqlString, sValuesSQL6 As SqlString, sDatesSQL6 As SqlString, sValuesSQL7 As SqlString, sDatesSQL7 As SqlString, sValuesSQL8 As SqlString, sDatesSQL8 As SqlString,
                                                                        sValuesSQL9 As SqlString, sDatesSQL9 As SqlString, sValuesSQL10 As SqlString, sDatesSQL10 As SqlString, sValuesSQL11 As SqlString, sDatesSQL11 As SqlString, sValuesSQL12 As SqlString, sDatesSQL12 As SqlString,
                                                                        sValuesSQL13 As SqlString, sDatesSQL13 As SqlString, sValuesSQL14 As SqlString, sDatesSQL14 As SqlString, sValuesSQL15 As SqlString, sDatesSQL15 As SqlString, sValuesSQL16 As SqlString, sDatesSQL16 As SqlString,
                                                                        sValuesSQL17 As SqlString, sDatesSQL17 As SqlString, sValuesSQL18 As SqlString, sDatesSQL18 As SqlString, sValuesSQL19 As SqlString, sDatesSQL19 As SqlString, sValuesSQL20 As SqlString, sDatesSQL20 As SqlString,
                                                                        sValuesSQL21 As SqlString, sDatesSQL21 As SqlString, sValuesSQL22 As SqlString, sDatesSQL22 As SqlString, sValuesSQL23 As SqlString, sDatesSQL23 As SqlString, sValuesSQL24 As SqlString, sDatesSQL24 As SqlString,
                                                                        sValuesSQL25 As SqlString, sDatesSQL25 As SqlString,
                                                                                            iSeasonalitySQL As SqlInt32,
                                                                                            iSeasonalitySQLForCalcNextDate As SqlInt32,
                                                                                            sSeasonalityPatternSQL As SqlString,
                                                                                            sSeasonalityPatternSQLForCalcNextDate As SqlString,
                                                                                            iHorizonSQL As SqlInt32,
                                                                                            iMethodSQLA As SqlInt32, iMethodSQLB As SqlInt32, iMethodSQLC As SqlInt32,
                                                                                            iWeightSQLA As SqlInt32, iWeightSQLB As SqlInt32, iWeightSQLC As SqlInt32,
                                                                                            iMethodSQLA_SQ_LU As SqlInt32, iMethodSQLB_SQ_LU As SqlInt32, iMethodSQLC_SQ_LU As SqlInt32) As SqlString

        'Values are sent in a string (separator is @# --> every value up to 10  charts
        'Dates are in yyyymmdd format, in a string (separator is @#) --> thus every date needs 10 chars --> We can send up to 400 points
        'Time we can create ourselfes
        Dim sReturnForecasts As SqlString
        Dim sSeparator As String = "@#"

        'Build the INITIAL ARRAYS
        Dim bFlag As Boolean
        Dim iStep As Integer
        Dim iFrom As Integer
        Dim iTotal As Integer

        'split them
        Dim dData() As Double
        Dim dtDate() As Date
        Dim dTime() As Double

        'READ THE PACKAGE --> 1
        iTotal = Convert.ToString(sValuesSQL).Length / 10
        bFlag = False
        iStep = 0
        iFrom = 0
        Do Until bFlag = True
            iStep = iStep + 1
            iFrom = ((iStep - 1) * 10) + 1
            ReDim Preserve dData(iStep)
            ReDim Preserve dtDate(iStep)
            ReDim Preserve dTime(iStep)

            dData(iStep) = Convert.ToDouble(Mid(sValuesSQL, iFrom, 8))
            dtDate(iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL, iFrom + 6, 2)))
            dTime(iStep) = iStep

            If iStep >= iTotal Then
                bFlag = True
            Else
                bFlag = False
            End If
        Loop

        'READ THE PACKAGE --> 2
        If Convert.ToString(sValuesSQL2).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL2).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(400 + iStep)
                ReDim Preserve dtDate(400 + iStep)
                ReDim Preserve dTime(400 + iStep)

                dData(400 + iStep) = Convert.ToDouble(Mid(sValuesSQL2, iFrom, 8))
                dtDate(400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL2, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL2, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL2, iFrom + 6, 2)))
                dTime(400 + iStep) = 400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 3
        If Convert.ToString(sValuesSQL3).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL3).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(800 + iStep)
                ReDim Preserve dtDate(800 + iStep)
                ReDim Preserve dTime(800 + iStep)

                dData(800 + iStep) = Convert.ToDouble(Mid(sValuesSQL3, iFrom, 8))
                dtDate(800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL3, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL3, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL3, iFrom + 6, 2)))
                dTime(800 + iStep) = 800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 4
        If Convert.ToString(sValuesSQL4).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL4).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(1200 + iStep)
                ReDim Preserve dtDate(1200 + iStep)
                ReDim Preserve dTime(1200 + iStep)

                dData(1200 + iStep) = Convert.ToDouble(Mid(sValuesSQL4, iFrom, 8))
                dtDate(1200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL4, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL4, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL4, iFrom + 6, 2)))
                dTime(1200 + iStep) = 1200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 5
        If Convert.ToString(sValuesSQL5).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL5).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(1600 + iStep)
                ReDim Preserve dtDate(1600 + iStep)
                ReDim Preserve dTime(1600 + iStep)

                dData(1600 + iStep) = Convert.ToDouble(Mid(sValuesSQL5, iFrom, 8))
                dtDate(1600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL5, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL5, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL5, iFrom + 6, 2)))
                dTime(1600 + iStep) = 1600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 6
        If Convert.ToString(sValuesSQL6).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL6).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(2000 + iStep)
                ReDim Preserve dtDate(2000 + iStep)
                ReDim Preserve dTime(2000 + iStep)

                dData(2000 + iStep) = Convert.ToDouble(Mid(sValuesSQL6, iFrom, 8))
                dtDate(2000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL6, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL6, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL6, iFrom + 6, 2)))
                dTime(2000 + iStep) = 2000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 7
        If Convert.ToString(sValuesSQL7).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL7).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(2400 + iStep)
                ReDim Preserve dtDate(2400 + iStep)
                ReDim Preserve dTime(2400 + iStep)

                dData(2400 + iStep) = Convert.ToDouble(Mid(sValuesSQL7, iFrom, 8))
                dtDate(2400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL7, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL7, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL7, iFrom + 6, 2)))
                dTime(2400 + iStep) = 2400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 8
        If Convert.ToString(sValuesSQL8).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL8).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(2800 + iStep)
                ReDim Preserve dtDate(2800 + iStep)
                ReDim Preserve dTime(2800 + iStep)

                dData(2800 + iStep) = Convert.ToDouble(Mid(sValuesSQL8, iFrom, 8))
                dtDate(2800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL8, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL8, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL8, iFrom + 6, 2)))
                dTime(2800 + iStep) = 2800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 9
        If Convert.ToString(sValuesSQL9).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL9).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(3200 + iStep)
                ReDim Preserve dtDate(3200 + iStep)
                ReDim Preserve dTime(3200 + iStep)

                dData(3200 + iStep) = Convert.ToDouble(Mid(sValuesSQL9, iFrom, 8))
                dtDate(3200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL9, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL9, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL9, iFrom + 6, 2)))
                dTime(3200 + iStep) = 3200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 10
        If Convert.ToString(sValuesSQL10).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL10).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(3600 + iStep)
                ReDim Preserve dtDate(3600 + iStep)
                ReDim Preserve dTime(3600 + iStep)

                dData(3600 + iStep) = Convert.ToDouble(Mid(sValuesSQL10, iFrom, 8))
                dtDate(3600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL10, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL10, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL10, iFrom + 6, 2)))
                dTime(3600 + iStep) = 3600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 11
        If Convert.ToString(sValuesSQL11).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL11).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(4000 + iStep)
                ReDim Preserve dtDate(4000 + iStep)
                ReDim Preserve dTime(4000 + iStep)

                dData(4000 + iStep) = Convert.ToDouble(Mid(sValuesSQL11, iFrom, 8))
                dtDate(4000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL11, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL11, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL11, iFrom + 6, 2)))
                dTime(4000 + iStep) = 4000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 12
        If Convert.ToString(sValuesSQL12).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL12).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(4400 + iStep)
                ReDim Preserve dtDate(4400 + iStep)
                ReDim Preserve dTime(4400 + iStep)

                dData(4400 + iStep) = Convert.ToDouble(Mid(sValuesSQL12, iFrom, 8))
                dtDate(4400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL12, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL12, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL12, iFrom + 6, 2)))
                dTime(4400 + iStep) = 4400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 13
        If Convert.ToString(sValuesSQL13).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL13).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(4800 + iStep)
                ReDim Preserve dtDate(4800 + iStep)
                ReDim Preserve dTime(4800 + iStep)

                dData(4800 + iStep) = Convert.ToDouble(Mid(sValuesSQL13, iFrom, 8))
                dtDate(4800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL13, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL13, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL13, iFrom + 6, 2)))
                dTime(4800 + iStep) = 4800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 14
        If Convert.ToString(sValuesSQL14).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL14).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(5200 + iStep)
                ReDim Preserve dtDate(5200 + iStep)
                ReDim Preserve dTime(5200 + iStep)

                dData(5200 + iStep) = Convert.ToDouble(Mid(sValuesSQL14, iFrom, 8))
                dtDate(5200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL14, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL14, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL14, iFrom + 6, 2)))
                dTime(5200 + iStep) = 5200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 15
        If Convert.ToString(sValuesSQL15).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL15).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(5600 + iStep)
                ReDim Preserve dtDate(5600 + iStep)
                ReDim Preserve dTime(5600 + iStep)

                dData(5600 + iStep) = Convert.ToDouble(Mid(sValuesSQL15, iFrom, 8))
                dtDate(5600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL15, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL15, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL15, iFrom + 6, 2)))
                dTime(5600 + iStep) = 5600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 16
        If Convert.ToString(sValuesSQL16).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL16).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(6000 + iStep)
                ReDim Preserve dtDate(6000 + iStep)
                ReDim Preserve dTime(6000 + iStep)

                dData(6000 + iStep) = Convert.ToDouble(Mid(sValuesSQL16, iFrom, 8))
                dtDate(6000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL16, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL16, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL16, iFrom + 6, 2)))
                dTime(6000 + iStep) = 6000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 17
        If Convert.ToString(sValuesSQL17).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL17).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(6400 + iStep)
                ReDim Preserve dtDate(6400 + iStep)
                ReDim Preserve dTime(6400 + iStep)

                dData(6400 + iStep) = Convert.ToDouble(Mid(sValuesSQL17, iFrom, 8))
                dtDate(6400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL17, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL17, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL17, iFrom + 6, 2)))
                dTime(6400 + iStep) = 6400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 18
        If Convert.ToString(sValuesSQL18).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL18).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(6800 + iStep)
                ReDim Preserve dtDate(6800 + iStep)
                ReDim Preserve dTime(6800 + iStep)

                dData(6800 + iStep) = Convert.ToDouble(Mid(sValuesSQL18, iFrom, 8))
                dtDate(6800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL18, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL18, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL18, iFrom + 6, 2)))
                dTime(6800 + iStep) = 6800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 19
        If Convert.ToString(sValuesSQL19).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL19).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(7200 + iStep)
                ReDim Preserve dtDate(7200 + iStep)
                ReDim Preserve dTime(7200 + iStep)

                dData(7200 + iStep) = Convert.ToDouble(Mid(sValuesSQL19, iFrom, 8))
                dtDate(7200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL19, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL19, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL19, iFrom + 6, 2)))
                dTime(7200 + iStep) = 7200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 20
        If Convert.ToString(sValuesSQL20).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL20).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(7600 + iStep)
                ReDim Preserve dtDate(7600 + iStep)
                ReDim Preserve dTime(7600 + iStep)

                dData(7600 + iStep) = Convert.ToDouble(Mid(sValuesSQL20, iFrom, 8))
                dtDate(7600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL20, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL20, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL20, iFrom + 6, 2)))
                dTime(7600 + iStep) = 7600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 21
        If Convert.ToString(sValuesSQL21).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL21).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(8000 + iStep)
                ReDim Preserve dtDate(8000 + iStep)
                ReDim Preserve dTime(8000 + iStep)

                dData(8000 + iStep) = Convert.ToDouble(Mid(sValuesSQL21, iFrom, 8))
                dtDate(8000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL21, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL21, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL21, iFrom + 6, 2)))
                dTime(8000 + iStep) = 8000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 22
        If Convert.ToString(sValuesSQL22).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL22).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(8400 + iStep)
                ReDim Preserve dtDate(8400 + iStep)
                ReDim Preserve dTime(8400 + iStep)

                dData(8400 + iStep) = Convert.ToDouble(Mid(sValuesSQL22, iFrom, 8))
                dtDate(8400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL22, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL22, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL22, iFrom + 6, 2)))
                dTime(8400 + iStep) = 8400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 23
        If Convert.ToString(sValuesSQL23).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL23).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(8800 + iStep)
                ReDim Preserve dtDate(8800 + iStep)
                ReDim Preserve dTime(8800 + iStep)

                dData(8800 + iStep) = Convert.ToDouble(Mid(sValuesSQL23, iFrom, 8))
                dtDate(8800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL23, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL23, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL23, iFrom + 6, 2)))
                dTime(8800 + iStep) = 8800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 24
        If Convert.ToString(sValuesSQL24).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL24).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(9200 + iStep)
                ReDim Preserve dtDate(9200 + iStep)
                ReDim Preserve dTime(9200 + iStep)

                dData(9200 + iStep) = Convert.ToDouble(Mid(sValuesSQL24, iFrom, 8))
                dtDate(9200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL24, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL24, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL24, iFrom + 6, 2)))
                dTime(9200 + iStep) = 9200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 25
        If Convert.ToString(sValuesSQL25).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL25).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(9600 + iStep)
                ReDim Preserve dtDate(9600 + iStep)
                ReDim Preserve dTime(9600 + iStep)

                dData(9600 + iStep) = Convert.ToDouble(Mid(sValuesSQL25, iFrom, 8))
                dtDate(9600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL25, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL25, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL25, iFrom + 6, 2)))
                dTime(9600 + iStep) = 9600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'rest variables
        Dim iSeasonality As Integer
        iSeasonality = iSeasonalitySQL
        Dim iSeasonalPattern(iSeasonality) As Integer
        Dim j As Integer
        For j = 1 To iSeasonality
            iSeasonalPattern(j) = Convert.ToInt32(Mid(sSeasonalityPatternSQL, j, 1))
        Next j

        Dim iSeasonalityForCalcNextDate As Integer
        iSeasonalityForCalcNextDate = iSeasonalitySQLForCalcNextDate
        Dim iSeasonalPatternForCalcNextDate(iSeasonalityForCalcNextDate) As Integer
        For j = 1 To iSeasonalityForCalcNextDate
            iSeasonalPatternForCalcNextDate(j) = Convert.ToInt32(Mid(sSeasonalityPatternSQLForCalcNextDate, j, 1))
        Next j

        Dim iHorizon As Integer
        iHorizon = iHorizonSQL

        'find the methods
        Dim iMethodA As Integer
        Dim iMethodB As Integer
        Dim iMethodC As Integer
        iMethodA = iMethodSQLA
        iMethodB = iMethodSQLB
        iMethodC = iMethodSQLC

        'find the extra calls
        Dim iMethodA_SQ_LU As Integer
        Dim iMethodB_SQ_LU As Integer
        Dim iMethodC_SQ_LU As Integer
        iMethodA_SQ_LU = iMethodSQLA_SQ_LU
        iMethodB_SQ_LU = iMethodSQLB_SQ_LU
        iMethodC_SQ_LU = iMethodSQLC_SQ_LU

        'find the weights
        Dim iWeightA As Integer
        Dim iWeightB As Integer
        Dim iWeightC As Integer
        iWeightA = iWeightSQLA
        iWeightB = iWeightSQLB
        iWeightC = iWeightSQLC

        'Correction for HOURLY data, since we are not passing the hour of the dtDates
        If iSeasonality = 24 Then
            For k = 1 To UBound(dtDate)
                dtDate(k) = dtDate(k).AddHours(k)
            Next k
        End If

        'Now you can call the forecast method, as before
        Dim dForecasts() As Double
        MathNLIBSQL.clsForecast.ForecastAverageThree(iMethodA, iMethodB, iMethodC, iMethodA_SQ_LU, iMethodB_SQ_LU, iMethodC_SQ_LU, iWeightA, iWeightB, iWeightC, dData, dtDate, dTime, iSeasonality, iSeasonalityForCalcNextDate, iSeasonalPattern, iSeasonalPatternForCalcNextDate, iHorizon, dForecasts)

        'OK. 
        'now return the results as a string
        Dim sEmpty As String = "        "
        sReturnForecasts = ""
        For j = 1 To UBound(dForecasts)
            If Convert.ToString(dForecasts(j)).Length <= 8 Then
                sReturnForecasts = sReturnForecasts + Convert.ToString(dForecasts(j)) + Left(sEmpty, 8 - Convert.ToString(dForecasts(j)).Length) + "@#"
            Else
                sReturnForecasts = sReturnForecasts + Left(Convert.ToString(dForecasts(j)), 8) + "@#"
            End If
        Next j

        Return sReturnForecasts

    End Function

    <Microsoft.SqlServer.Server.SqlFunction(IsDeterministic:=True, IsPrecise:=False)>
    Public Shared Function SQL_Calculate_NextDate(ByVal dtDateSQL As SqlString,
                                                                                                    ByVal iSeasonalitySQL As SqlInt32) As SqlString

        Dim dtDate As Date
        Dim iSeasonality As Integer
        Dim NewDate As Date
        Dim NewDateString As String

        dtDate = DateSerial(Mid(dtDateSQL, 1, 4), Mid(dtDateSQL, 5, 2), Mid(dtDateSQL, 7, 2))
        iSeasonality = iSeasonalitySQL

        NewDate = clsForecast.TimeSerie_Calculate_NextDate(dtDate, iSeasonality)

        NewDateString = NewDate.ToString("yyyyMMdd")

        Return NewDateString

    End Function

    Public Shared Function SQL_Calculate_NextHour(ByVal dtDateSQL As SqlString,
                                                                                               ByVal iHourSQL As SqlInt32) As SqlString

        Dim dtDate As Date
        Dim iHour As Integer
        Dim iSeasonality As Integer
        Dim NewDate As Date
        Dim NewDateString As String

        iHour = iHourSQL
        iSeasonality = 24
        dtDate = DateSerial(Mid(dtDateSQL, 1, 4), Mid(dtDateSQL, 5, 2), Mid(dtDateSQL, 7, 2))
        dtDate = dtDate.AddHours(iHour)

        NewDate = clsForecast.TimeSerie_Calculate_NextDate(dtDate, iSeasonality)

        NewDateString = NewDate.ToString("yyyyMMdd HH:mm:ss")

        Return NewDateString

    End Function

    <Microsoft.SqlServer.Server.SqlFunction(IsDeterministic:=True, IsPrecise:=False)>
    Public Shared Function SQL_Test(S1 As SqlString, S2 As SqlString) As SqlString

        Dim sResult As SqlString

        If S1.IsNull Then
            sResult = "a"
        Else
            sResult = "bc"
        End If

        Return sResult

    End Function

    <Microsoft.SqlServer.Server.SqlFunction(IsDeterministic:=True, IsPrecise:=False)>
    Public Shared Function SQL_Forecast(sValuesSQL As SqlString, sDatesSQL As SqlString, sValuesSQL2 As SqlString, sDatesSQL2 As SqlString, sValuesSQL3 As SqlString, sDatesSQL3 As SqlString, sValuesSQL4 As SqlString, sDatesSQL4 As SqlString,
                                                                        sValuesSQL5 As SqlString, sDatesSQL5 As SqlString, sValuesSQL6 As SqlString, sDatesSQL6 As SqlString, sValuesSQL7 As SqlString, sDatesSQL7 As SqlString, sValuesSQL8 As SqlString, sDatesSQL8 As SqlString,
                                                                        sValuesSQL9 As SqlString, sDatesSQL9 As SqlString, sValuesSQL10 As SqlString, sDatesSQL10 As SqlString, sValuesSQL11 As SqlString, sDatesSQL11 As SqlString, sValuesSQL12 As SqlString, sDatesSQL12 As SqlString,
                                                                        sValuesSQL13 As SqlString, sDatesSQL13 As SqlString, sValuesSQL14 As SqlString, sDatesSQL14 As SqlString, sValuesSQL15 As SqlString, sDatesSQL15 As SqlString, sValuesSQL16 As SqlString, sDatesSQL16 As SqlString,
                                                                        sValuesSQL17 As SqlString, sDatesSQL17 As SqlString, sValuesSQL18 As SqlString, sDatesSQL18 As SqlString, sValuesSQL19 As SqlString, sDatesSQL19 As SqlString, sValuesSQL20 As SqlString, sDatesSQL20 As SqlString,
                                                                        sValuesSQL21 As SqlString, sDatesSQL21 As SqlString, sValuesSQL22 As SqlString, sDatesSQL22 As SqlString, sValuesSQL23 As SqlString, sDatesSQL23 As SqlString, sValuesSQL24 As SqlString, sDatesSQL24 As SqlString,
                                                                        sValuesSQL25 As SqlString, sDatesSQL25 As SqlString,
                                                                        iSeasonalitySQL As SqlInt32,
                                                                        sSeasonalityPatternSQL As SqlString,
                                                                        iHorizonSQL As SqlInt32,
                                                                        iMethodSQL As SqlInt32) As SqlString

        'Values are sent in a string (separator is @# --> every value up to 10  charts
        'Dates are in yyyymmdd format, in a string (separator is @#) --> thus every date needs 10 chars --> We can send up to 400 points
        'Time we can create ourselfes
        Dim sReturnForecasts As SqlString
        Dim sSeparator As String = "@#"

        'Build the INITIAL ARRAYS
        Dim bFlag As Boolean
        Dim iStep As Integer
        Dim iFrom As Integer
        Dim iTotal As Integer

        'split them
        Dim dData() As Double
        Dim dtDate() As Date
        Dim dTime() As Double

        'READ THE PACKAGE --> 1
        iTotal = Convert.ToString(sValuesSQL).Length / 10
        bFlag = False
        iStep = 0
        iFrom = 0
        Do Until bFlag = True
            iStep = iStep + 1
            iFrom = ((iStep - 1) * 10) + 1
            ReDim Preserve dData(iStep)
            ReDim Preserve dtDate(iStep)
            ReDim Preserve dTime(iStep)

            dData(iStep) = Convert.ToDouble(Mid(sValuesSQL, iFrom, 8))
            dtDate(iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL, iFrom + 6, 2)))
            dTime(iStep) = iStep

            If iStep >= iTotal Then
                bFlag = True
            Else
                bFlag = False
            End If
        Loop

        'READ THE PACKAGE --> 2
        If Convert.ToString(sValuesSQL2).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL2).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(400 + iStep)
                ReDim Preserve dtDate(400 + iStep)
                ReDim Preserve dTime(400 + iStep)

                dData(400 + iStep) = Convert.ToDouble(Mid(sValuesSQL2, iFrom, 8))
                dtDate(400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL2, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL2, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL2, iFrom + 6, 2)))
                dTime(400 + iStep) = 400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 3
        If Convert.ToString(sValuesSQL3).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL3).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(800 + iStep)
                ReDim Preserve dtDate(800 + iStep)
                ReDim Preserve dTime(800 + iStep)

                dData(800 + iStep) = Convert.ToDouble(Mid(sValuesSQL3, iFrom, 8))
                dtDate(800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL3, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL3, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL3, iFrom + 6, 2)))
                dTime(800 + iStep) = 800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 4
        If Convert.ToString(sValuesSQL4).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL4).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(1200 + iStep)
                ReDim Preserve dtDate(1200 + iStep)
                ReDim Preserve dTime(1200 + iStep)

                dData(1200 + iStep) = Convert.ToDouble(Mid(sValuesSQL4, iFrom, 8))
                dtDate(1200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL4, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL4, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL4, iFrom + 6, 2)))
                dTime(1200 + iStep) = 1200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 5
        If Convert.ToString(sValuesSQL5).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL5).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(1600 + iStep)
                ReDim Preserve dtDate(1600 + iStep)
                ReDim Preserve dTime(1600 + iStep)

                dData(1600 + iStep) = Convert.ToDouble(Mid(sValuesSQL5, iFrom, 8))
                dtDate(1600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL5, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL5, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL5, iFrom + 6, 2)))
                dTime(1600 + iStep) = 1600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 6
        If Convert.ToString(sValuesSQL6).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL6).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(2000 + iStep)
                ReDim Preserve dtDate(2000 + iStep)
                ReDim Preserve dTime(2000 + iStep)

                dData(2000 + iStep) = Convert.ToDouble(Mid(sValuesSQL6, iFrom, 8))
                dtDate(2000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL6, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL6, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL6, iFrom + 6, 2)))
                dTime(2000 + iStep) = 2000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 7
        If Convert.ToString(sValuesSQL7).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL7).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(2400 + iStep)
                ReDim Preserve dtDate(2400 + iStep)
                ReDim Preserve dTime(2400 + iStep)

                dData(2400 + iStep) = Convert.ToDouble(Mid(sValuesSQL7, iFrom, 8))
                dtDate(2400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL7, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL7, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL7, iFrom + 6, 2)))
                dTime(2400 + iStep) = 2400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 8
        If Convert.ToString(sValuesSQL8).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL8).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(2800 + iStep)
                ReDim Preserve dtDate(2800 + iStep)
                ReDim Preserve dTime(2800 + iStep)

                dData(2800 + iStep) = Convert.ToDouble(Mid(sValuesSQL8, iFrom, 8))
                dtDate(2800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL8, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL8, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL8, iFrom + 6, 2)))
                dTime(2800 + iStep) = 2800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 9
        If Convert.ToString(sValuesSQL9).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL9).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(3200 + iStep)
                ReDim Preserve dtDate(3200 + iStep)
                ReDim Preserve dTime(3200 + iStep)

                dData(3200 + iStep) = Convert.ToDouble(Mid(sValuesSQL9, iFrom, 8))
                dtDate(3200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL9, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL9, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL9, iFrom + 6, 2)))
                dTime(3200 + iStep) = 3200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 10
        If Convert.ToString(sValuesSQL10).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL10).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(3600 + iStep)
                ReDim Preserve dtDate(3600 + iStep)
                ReDim Preserve dTime(3600 + iStep)

                dData(3600 + iStep) = Convert.ToDouble(Mid(sValuesSQL10, iFrom, 8))
                dtDate(3600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL10, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL10, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL10, iFrom + 6, 2)))
                dTime(3600 + iStep) = 3600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 11
        If Convert.ToString(sValuesSQL11).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL11).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(4000 + iStep)
                ReDim Preserve dtDate(4000 + iStep)
                ReDim Preserve dTime(4000 + iStep)

                dData(4000 + iStep) = Convert.ToDouble(Mid(sValuesSQL11, iFrom, 8))
                dtDate(4000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL11, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL11, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL11, iFrom + 6, 2)))
                dTime(4000 + iStep) = 4000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 12
        If Convert.ToString(sValuesSQL12).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL12).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(4400 + iStep)
                ReDim Preserve dtDate(4400 + iStep)
                ReDim Preserve dTime(4400 + iStep)

                dData(4400 + iStep) = Convert.ToDouble(Mid(sValuesSQL12, iFrom, 8))
                dtDate(4400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL12, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL12, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL12, iFrom + 6, 2)))
                dTime(4400 + iStep) = 4400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 13
        If Convert.ToString(sValuesSQL13).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL13).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(4800 + iStep)
                ReDim Preserve dtDate(4800 + iStep)
                ReDim Preserve dTime(4800 + iStep)

                dData(4800 + iStep) = Convert.ToDouble(Mid(sValuesSQL13, iFrom, 8))
                dtDate(4800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL13, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL13, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL13, iFrom + 6, 2)))
                dTime(4800 + iStep) = 4800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 14
        If Convert.ToString(sValuesSQL14).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL14).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(5200 + iStep)
                ReDim Preserve dtDate(5200 + iStep)
                ReDim Preserve dTime(5200 + iStep)

                dData(5200 + iStep) = Convert.ToDouble(Mid(sValuesSQL14, iFrom, 8))
                dtDate(5200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL14, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL14, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL14, iFrom + 6, 2)))
                dTime(5200 + iStep) = 5200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 15
        If Convert.ToString(sValuesSQL15).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL15).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(5600 + iStep)
                ReDim Preserve dtDate(5600 + iStep)
                ReDim Preserve dTime(5600 + iStep)

                dData(5600 + iStep) = Convert.ToDouble(Mid(sValuesSQL15, iFrom, 8))
                dtDate(5600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL15, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL15, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL15, iFrom + 6, 2)))
                dTime(5600 + iStep) = 5600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 16
        If Convert.ToString(sValuesSQL16).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL16).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(6000 + iStep)
                ReDim Preserve dtDate(6000 + iStep)
                ReDim Preserve dTime(6000 + iStep)

                dData(6000 + iStep) = Convert.ToDouble(Mid(sValuesSQL16, iFrom, 8))
                dtDate(6000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL16, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL16, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL16, iFrom + 6, 2)))
                dTime(6000 + iStep) = 6000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 17
        If Convert.ToString(sValuesSQL17).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL17).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(6400 + iStep)
                ReDim Preserve dtDate(6400 + iStep)
                ReDim Preserve dTime(6400 + iStep)

                dData(6400 + iStep) = Convert.ToDouble(Mid(sValuesSQL17, iFrom, 8))
                dtDate(6400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL17, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL17, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL17, iFrom + 6, 2)))
                dTime(6400 + iStep) = 6400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 18
        If Convert.ToString(sValuesSQL18).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL18).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(6800 + iStep)
                ReDim Preserve dtDate(6800 + iStep)
                ReDim Preserve dTime(6800 + iStep)

                dData(6800 + iStep) = Convert.ToDouble(Mid(sValuesSQL18, iFrom, 8))
                dtDate(6800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL18, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL18, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL18, iFrom + 6, 2)))
                dTime(6800 + iStep) = 6800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 19
        If Convert.ToString(sValuesSQL19).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL19).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(7200 + iStep)
                ReDim Preserve dtDate(7200 + iStep)
                ReDim Preserve dTime(7200 + iStep)

                dData(7200 + iStep) = Convert.ToDouble(Mid(sValuesSQL19, iFrom, 8))
                dtDate(7200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL19, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL19, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL19, iFrom + 6, 2)))
                dTime(7200 + iStep) = 7200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 20
        If Convert.ToString(sValuesSQL20).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL20).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(7600 + iStep)
                ReDim Preserve dtDate(7600 + iStep)
                ReDim Preserve dTime(7600 + iStep)

                dData(7600 + iStep) = Convert.ToDouble(Mid(sValuesSQL20, iFrom, 8))
                dtDate(7600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL20, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL20, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL20, iFrom + 6, 2)))
                dTime(7600 + iStep) = 7600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 21
        If Convert.ToString(sValuesSQL21).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL21).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(8000 + iStep)
                ReDim Preserve dtDate(8000 + iStep)
                ReDim Preserve dTime(8000 + iStep)

                dData(8000 + iStep) = Convert.ToDouble(Mid(sValuesSQL21, iFrom, 8))
                dtDate(8000 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL21, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL21, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL21, iFrom + 6, 2)))
                dTime(8000 + iStep) = 8000 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 22
        If Convert.ToString(sValuesSQL22).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL22).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(8400 + iStep)
                ReDim Preserve dtDate(8400 + iStep)
                ReDim Preserve dTime(8400 + iStep)

                dData(8400 + iStep) = Convert.ToDouble(Mid(sValuesSQL22, iFrom, 8))
                dtDate(8400 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL22, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL22, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL22, iFrom + 6, 2)))
                dTime(8400 + iStep) = 8400 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 23
        If Convert.ToString(sValuesSQL23).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL23).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(8800 + iStep)
                ReDim Preserve dtDate(8800 + iStep)
                ReDim Preserve dTime(8800 + iStep)

                dData(8800 + iStep) = Convert.ToDouble(Mid(sValuesSQL23, iFrom, 8))
                dtDate(8800 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL23, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL23, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL23, iFrom + 6, 2)))
                dTime(8800 + iStep) = 8800 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 24
        If Convert.ToString(sValuesSQL24).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL24).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(9200 + iStep)
                ReDim Preserve dtDate(9200 + iStep)
                ReDim Preserve dTime(9200 + iStep)

                dData(9200 + iStep) = Convert.ToDouble(Mid(sValuesSQL24, iFrom, 8))
                dtDate(9200 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL24, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL24, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL24, iFrom + 6, 2)))
                dTime(9200 + iStep) = 9200 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'READ THE PACKAGE --> 25
        If Convert.ToString(sValuesSQL25).Length >= 10 Then
            iTotal = Convert.ToString(sValuesSQL25).Length / 10
            bFlag = False
            iStep = 0
            iFrom = 0
            Do Until bFlag = True
                iStep = iStep + 1
                iFrom = ((iStep - 1) * 10) + 1
                ReDim Preserve dData(9600 + iStep)
                ReDim Preserve dtDate(9600 + iStep)
                ReDim Preserve dTime(9600 + iStep)

                dData(9600 + iStep) = Convert.ToDouble(Mid(sValuesSQL25, iFrom, 8))
                dtDate(9600 + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL25, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL25, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL25, iFrom + 6, 2)))
                dTime(9600 + iStep) = 9600 + iStep

                If iStep >= iTotal Then
                    bFlag = True
                Else
                    bFlag = False
                End If
            Loop
        End If

        'rest variables
        Dim iSeasonality As Integer
        iSeasonality = iSeasonalitySQL
        Dim iSeasonalPattern(iSeasonality) As Integer
        Dim j As Integer
        For j = 1 To iSeasonality
            iSeasonalPattern(j) = Convert.ToInt32(Mid(sSeasonalityPatternSQL, j, 1))
        Next j
        Dim iHorizon As Integer
        iHorizon = iHorizonSQL
        Dim iMethod As Integer
        iMethod = iMethodSQL

        'Correction for HOURLY data, since we are not passing the hour of the dtDates
        If iSeasonality = 24 Then
            For k = 1 To UBound(dtDate)
                dtDate(k) = dtDate(k).AddHours(k)
            Next k
        End If

        'Now you can call the forecast method, as before
        Dim dForecasts() As Double
        clsForecast.Forecast(iMethod, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecasts)

        'OK. 
        'now return the results as a string
        Dim sEmpty As String = "        "
        sReturnForecasts = ""
        For j = 1 To UBound(dForecasts)
            If Convert.ToString(dForecasts(j)).Length <= 8 Then
                sReturnForecasts = sReturnForecasts + Convert.ToString(dForecasts(j)) + Left(sEmpty, 8 - Convert.ToString(dForecasts(j)).Length) + "@#"
            Else
                sReturnForecasts = sReturnForecasts + Left(Convert.ToString(dForecasts(j)), 8) + "@#"
            End If
        Next j

        Return sReturnForecasts

    End Function

    'Public Shared Sub ReadThePackage(ByVal iPackage As Integer, ByVal sValuesSQL As SqlString, ByVal sDatesSQL As SqlString, ByVal iCount As Integer,
    '                                                        ByRef dData() As Double, ByRef dtDate() As Date, ByRef dTime() As Double)

    '    Dim bFlag As Boolean
    '    Dim iStep As Integer
    '    Dim iFrom As Integer
    '    Dim iTotal As Integer

    '    'READ THE PACKAGE 
    '    If Convert.ToString(sValuesSQL).Length >= 10 Then
    '        iTotal = Convert.ToString(sValuesSQL).Length / 10
    '        bFlag = False
    '        iStep = 0
    '        iFrom = 0
    '        Do Until bFlag = True
    '            iStep = iStep + 1
    '            iFrom = ((iStep - 1) * 10) + 1
    '            ReDim Preserve dData(iCount + iStep)
    '            ReDim Preserve dtDate(iCount + iStep)
    '            ReDim Preserve dTime(iCount + iStep)

    '            dData(iCount + iStep) = Convert.ToDouble(Mid(sValuesSQL, iFrom, 8))
    '            dtDate(iCount + iStep) = DateSerial(Convert.ToInt32(Mid(sDatesSQL, iFrom, 4)), Convert.ToInt32(Mid(sDatesSQL, iFrom + 4, 2)), Convert.ToInt32(Mid(sDatesSQL, iFrom + 6, 2)))
    '            dTime(iCount + iStep) = iCount + iStep

    '            If iStep >= iTotal Then
    '                bFlag = True
    '            Else
    '                bFlag = False
    '            End If
    '        Loop
    '    End If

    'End Sub

End Class
