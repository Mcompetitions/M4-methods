﻿Option Strict Off
Option Explicit On

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports Microsoft.SqlServer.Server

Public Class clsForecast

    Public Enum enmForecastMethod
        'Naive Group
        SFM_Naive_NonSeasonal = 101
        SFM_Naive_Seasonal = 102
        SFM_Naive_Trend_NonSeasonal = 103
        SFM_Naive_Trend_Seasonal = 104
        SFM_Mean_NonSeasonal = 105
        SFM_Mean_Seasonal = 106
        SFM_Median_NonSeasonal = 107
        SFM_Median_Seasonal = 108
        SFM_Naive_Repeat_NonSeasonal = 109
        SFM_Naive_Repeat_Seasonal = 110

        'Linear Regression
        SFM_LinearRegression_Simple_NonSeasonal = 201
        SFM_LinearRegression_Simple_Seasonal = 202
        SFM_LinearRegression_Multiple_NonSeasonal = 203
        SFM_LinearRegression_Multiple_Seasonal = 204

        'Decomposition Additive
        SFM_Decomposition_Additive_Classical_NonSeasonal = 301
        SFM_Decomposition_Additive_Classical_Seasonal = 302
        SFM_Decomposition_Additive_MAS3B_NonSeasonal = 303
        SFM_Decomposition_Additive_MAS3B_Seasonal = 304
        SFM_Decomposition_Additive_MAS5B_NonSeasonal = 305
        SFM_Decomposition_Additive_MAS5B_Seasonal = 306
        SFM_Decomposition_Additive_MASNB_NonSeasonal = 307
        SFM_Decomposition_Additive_MASNB_Seasonal = 308
        SFM_Decomposition_Additive_MAW3B_NonSeasonal = 309
        SFM_Decomposition_Additive_MAW3B_Seasonal = 310
        SFM_Decomposition_Additive_MAW5B_NonSeasonal = 311
        SFM_Decomposition_Additive_MAW5B_Seasonal = 312
        SFM_Decomposition_Additive_MAWNB_NonSeasonal = 313
        SFM_Decomposition_Additive_MAWNB_Seasonal = 314
        SFM_Decomposition_Additive_MAD3B_NonSeasonal = 315
        SFM_Decomposition_Additive_MAD3B_Seasonal = 316
        SFM_Decomposition_Additive_MAD5B_NonSeasonal = 317
        SFM_Decomposition_Additive_MAD5B_Seasonal = 318
        SFM_Decomposition_Additive_MADNB_NonSeasonal = 319
        SFM_Decomposition_Additive_MADNB_Seasonal = 320
        'Decomposition Group - Multiplicative
        SFM_Decomposition_Multiplicative_Classical_NonSeasonal = 351
        SFM_Decomposition_Multiplicative_Classical_Seasonal = 352
        SFM_Decomposition_Multiplicative_MAS3B_NonSeasonal = 353
        SFM_Decomposition_Multiplicative_MAS3B_Seasonal = 354
        SFM_Decomposition_Multiplicative_MAS5B_NonSeasonal = 355
        SFM_Decomposition_Multiplicative_MAS5B_Seasonal = 356
        SFM_Decomposition_Multiplicative_MASNB_NonSeasonal = 357
        SFM_Decomposition_Multiplicative_MASNB_Seasonal = 358
        SFM_Decomposition_Multiplicative_MAW3B_NonSeasonal = 359
        SFM_Decomposition_Multiplicative_MAW3B_Seasonal = 360
        SFM_Decomposition_Multiplicative_MAW5B_NonSeasonal = 361
        SFM_Decomposition_Multiplicative_MAW5B_Seasonal = 362
        SFM_Decomposition_Multiplicative_MAWNB_NonSeasonal = 363
        SFM_Decomposition_Multiplicative_MAWNB_Seasonal = 364
        SFM_Decomposition_Multiplicative_MAD3B_NonSeasonal = 365
        SFM_Decomposition_Multiplicative_MAD3B_Seasonal = 366
        SFM_Decomposition_Multiplicative_MAD5B_NonSeasonal = 367
        SFM_Decomposition_Multiplicative_MAD5B_Seasonal = 368
        SFM_Decomposition_Multiplicative_MADNB_NonSeasonal = 369
        SFM_Decomposition_Multiplicative_MADNB_Seasonal = 370
        'Moving Average Group - Simple
        SFM_MovingAverage_Simple3_NonSeasonal = 401
        SFM_MovingAverage_Simple3_Seasonal = 402
        SFM_MovingAverage_Simple5_NonSeasonal = 403
        SFM_MovingAverage_Simple5_Seasonal = 404
        SFM_MovingAverage_SimpleN_NonSeasonal = 405
        SFM_MovingAverage_SimpleN_Seasonal = 406
        'Moving Average Group - Simple Backstage
        SFM_MovingAverage_Simple3b_NonSeasonal = 407
        SFM_MovingAverage_Simple3b_Seasonal = 408
        SFM_MovingAverage_Simple5b_NonSeasonal = 409
        SFM_MovingAverage_Simple5b_Seasonal = 410
        SFM_MovingAverage_SimpleNb_NonSeasonal = 411
        SFM_MovingAverage_SimpleNb_Seasonal = 412
        'Moving Average Group - Weighted
        SFM_MovingAverage_Weighted3_NonSeasonal = 413
        SFM_MovingAverage_Weighted3_Seasonal = 414
        SFM_MovingAverage_Weighted5_NonSeasonal = 415
        SFM_MovingAverage_Weighted5_Seasonal = 416
        SFM_MovingAverage_WeightedN_NonSeasonal = 417
        SFM_MovingAverage_WeightedN_Seasonal = 418
        'Moving Average Group - Weighted Backstage
        SFM_MovingAverage_Weighted3b_NonSeasonal = 419
        SFM_MovingAverage_Weighted3b_Seasonal = 420
        SFM_MovingAverage_Weighted5b_NonSeasonal = 421
        SFM_MovingAverage_Weighted5b_Seasonal = 422
        SFM_MovingAverage_WeightedNb_NonSeasonal = 423
        SFM_MovingAverage_WeightedNb_Seasonal = 424
        'Moving Average Group - Double
        SFM_MovingAverage_Double3_NonSeasonal = 425
        SFM_MovingAverage_Double3_Seasonal = 426
        SFM_MovingAverage_Double5_NonSeasonal = 427
        SFM_MovingAverage_Double5_Seasonal = 428
        SFM_MovingAverage_DoubleN_NonSeasonal = 429
        SFM_MovingAverage_DoubleN_Seasonal = 430
        'Moving Average Group - Double Backstage
        SFM_MovingAverage_Double3b_NonSeasonal = 431
        SFM_MovingAverage_Double3b_Seasonal = 432
        SFM_MovingAverage_Double5b_NonSeasonal = 433
        SFM_MovingAverage_Double5b_Seasonal = 434
        SFM_MovingAverage_DoubleNb_NonSeasonal = 435
        SFM_MovingAverage_DoubleNb_Seasonal = 436
        'Simple Exponential Smoothing
        SFM_ExponentialSmoothing_Simple_A2_NonSeasonal = 501
        SFM_ExponentialSmoothing_Simple_A2_Seasonal = 502
        SFM_ExponentialSmoothing_Simple_A4_NonSeasonal = 503
        SFM_ExponentialSmoothing_Simple_A4_Seasonal = 504
        SFM_ExponentialSmoothing_Simple_A5_NonSeasonal = 505
        SFM_ExponentialSmoothing_Simple_A5_Seasonal = 506
        SFM_ExponentialSmoothing_Simple_A6_NonSeasonal = 507
        SFM_ExponentialSmoothing_Simple_A6_Seasonal = 508
        SFM_ExponentialSmoothing_Simple_A8_NonSeasonal = 509
        SFM_ExponentialSmoothing_Simple_A8_Seasonal = 510
        SFM_ExponentialSmoothing_Simple_M2_NonSeasonal = 511
        SFM_ExponentialSmoothing_Simple_M2_Seasonal = 512
        SFM_ExponentialSmoothing_Simple_M4_NonSeasonal = 513
        SFM_ExponentialSmoothing_Simple_M4_Seasonal = 514
        SFM_ExponentialSmoothing_Simple_M5_NonSeasonal = 515
        SFM_ExponentialSmoothing_Simple_M5_Seasonal = 516
        SFM_ExponentialSmoothing_Simple_M6_NonSeasonal = 517
        SFM_ExponentialSmoothing_Simple_M6_Seasonal = 518
        SFM_ExponentialSmoothing_Simple_M8_NonSeasonal = 519
        SFM_ExponentialSmoothing_Simple_M8_Seasonal = 520
        SFM_ExponentialSmoothing_Simple_F2_NonSeasonal = 521
        SFM_ExponentialSmoothing_Simple_F2_Seasonal = 522
        SFM_ExponentialSmoothing_Simple_F4_NonSeasonal = 523
        SFM_ExponentialSmoothing_Simple_F4_Seasonal = 524
        SFM_ExponentialSmoothing_Simple_F5_NonSeasonal = 525
        SFM_ExponentialSmoothing_Simple_F5_Seasonal = 526
        SFM_ExponentialSmoothing_Simple_F6_NonSeasonal = 527
        SFM_ExponentialSmoothing_Simple_F6_Seasonal = 528
        SFM_ExponentialSmoothing_Simple_F8_NonSeasonal = 529
        SFM_ExponentialSmoothing_Simple_F8_Seasonal = 530
        SFM_ExponentialSmoothing_Simple_L2_NonSeasonal = 531
        SFM_ExponentialSmoothing_Simple_L2_Seasonal = 532
        SFM_ExponentialSmoothing_Simple_L4_NonSeasonal = 533
        SFM_ExponentialSmoothing_Simple_L4_Seasonal = 534
        SFM_ExponentialSmoothing_Simple_L5_NonSeasonal = 535
        SFM_ExponentialSmoothing_Simple_L5_Seasonal = 536
        SFM_ExponentialSmoothing_Simple_L6_NonSeasonal = 537
        SFM_ExponentialSmoothing_Simple_L6_Seasonal = 538
        SFM_ExponentialSmoothing_Simple_L8_NonSeasonal = 539
        SFM_ExponentialSmoothing_Simple_L8_Seasonal = 540
        'Simple Trend Exponential Smoothing
        SFM_ExponentialSmoothing_SimpleTrend_A2_NonSeasonal = 551
        SFM_ExponentialSmoothing_SimpleTrend_A2_Seasonal = 552
        SFM_ExponentialSmoothing_SimpleTrend_A4_NonSeasonal = 553
        SFM_ExponentialSmoothing_SimpleTrend_A4_Seasonal = 554
        SFM_ExponentialSmoothing_SimpleTrend_A5_NonSeasonal = 555
        SFM_ExponentialSmoothing_SimpleTrend_A5_Seasonal = 556
        SFM_ExponentialSmoothing_SimpleTrend_A6_NonSeasonal = 557
        SFM_ExponentialSmoothing_SimpleTrend_A6_Seasonal = 558
        SFM_ExponentialSmoothing_SimpleTrend_A8_NonSeasonal = 559
        SFM_ExponentialSmoothing_SimpleTrend_A8_Seasonal = 560
        SFM_ExponentialSmoothing_SimpleTrend_M2_NonSeasonal = 561
        SFM_ExponentialSmoothing_SimpleTrend_M2_Seasonal = 562
        SFM_ExponentialSmoothing_SimpleTrend_M4_NonSeasonal = 563
        SFM_ExponentialSmoothing_SimpleTrend_M4_Seasonal = 564
        SFM_ExponentialSmoothing_SimpleTrend_M5_NonSeasonal = 565
        SFM_ExponentialSmoothing_SimpleTrend_M5_Seasonal = 566
        SFM_ExponentialSmoothing_SimpleTrend_M6_NonSeasonal = 567
        SFM_ExponentialSmoothing_SimpleTrend_M6_Seasonal = 568
        SFM_ExponentialSmoothing_SimpleTrend_M8_NonSeasonal = 569
        SFM_ExponentialSmoothing_SimpleTrend_M8_Seasonal = 570
        SFM_ExponentialSmoothing_SimpleTrend_F2_NonSeasonal = 571
        SFM_ExponentialSmoothing_SimpleTrend_F2_Seasonal = 572
        SFM_ExponentialSmoothing_SimpleTrend_F4_NonSeasonal = 573
        SFM_ExponentialSmoothing_SimpleTrend_F4_Seasonal = 574
        SFM_ExponentialSmoothing_SimpleTrend_F5_NonSeasonal = 575
        SFM_ExponentialSmoothing_SimpleTrend_F5_Seasonal = 576
        SFM_ExponentialSmoothing_SimpleTrend_F6_NonSeasonal = 577
        SFM_ExponentialSmoothing_SimpleTrend_F6_Seasonal = 578
        SFM_ExponentialSmoothing_SimpleTrend_F8_NonSeasonal = 579
        SFM_ExponentialSmoothing_SimpleTrend_F8_Seasonal = 580
        SFM_ExponentialSmoothing_SimpleTrend_L2_NonSeasonal = 581
        SFM_ExponentialSmoothing_SimpleTrend_L2_Seasonal = 582
        SFM_ExponentialSmoothing_SimpleTrend_L4_NonSeasonal = 583
        SFM_ExponentialSmoothing_SimpleTrend_L4_Seasonal = 584
        SFM_ExponentialSmoothing_SimpleTrend_L5_NonSeasonal = 585
        SFM_ExponentialSmoothing_SimpleTrend_L5_Seasonal = 586
        SFM_ExponentialSmoothing_SimpleTrend_L6_NonSeasonal = 587
        SFM_ExponentialSmoothing_SimpleTrend_L6_Seasonal = 588
        SFM_ExponentialSmoothing_SimpleTrend_L8_NonSeasonal = 589
        SFM_ExponentialSmoothing_SimpleTrend_L8_Seasonal = 590
        'Holt Exponential Smoothing
        SFM_ExponentialSmoothing_Holt_A2_NonSeasonal = 601
        SFM_ExponentialSmoothing_Holt_A2_Seasonal = 602
        SFM_ExponentialSmoothing_Holt_A4_NonSeasonal = 603
        SFM_ExponentialSmoothing_Holt_A4_Seasonal = 604
        SFM_ExponentialSmoothing_Holt_A5_NonSeasonal = 605
        SFM_ExponentialSmoothing_Holt_A5_Seasonal = 606
        SFM_ExponentialSmoothing_Holt_A6_NonSeasonal = 607
        SFM_ExponentialSmoothing_Holt_A6_Seasonal = 608
        SFM_ExponentialSmoothing_Holt_A8_NonSeasonal = 609
        SFM_ExponentialSmoothing_Holt_A8_Seasonal = 610
        SFM_ExponentialSmoothing_Holt_M2_NonSeasonal = 611
        SFM_ExponentialSmoothing_Holt_M2_Seasonal = 612
        SFM_ExponentialSmoothing_Holt_M4_NonSeasonal = 613
        SFM_ExponentialSmoothing_Holt_M4_Seasonal = 614
        SFM_ExponentialSmoothing_Holt_M5_NonSeasonal = 615
        SFM_ExponentialSmoothing_Holt_M5_Seasonal = 616
        SFM_ExponentialSmoothing_Holt_M6_NonSeasonal = 617
        SFM_ExponentialSmoothing_Holt_M6_Seasonal = 618
        SFM_ExponentialSmoothing_Holt_M8_NonSeasonal = 619
        SFM_ExponentialSmoothing_Holt_M8_Seasonal = 620
        SFM_ExponentialSmoothing_Holt_F2_NonSeasonal = 621
        SFM_ExponentialSmoothing_Holt_F2_Seasonal = 622
        SFM_ExponentialSmoothing_Holt_F4_NonSeasonal = 623
        SFM_ExponentialSmoothing_Holt_F4_Seasonal = 624
        SFM_ExponentialSmoothing_Holt_F5_NonSeasonal = 625
        SFM_ExponentialSmoothing_Holt_F5_Seasonal = 626
        SFM_ExponentialSmoothing_Holt_F6_NonSeasonal = 627
        SFM_ExponentialSmoothing_Holt_F6_Seasonal = 628
        SFM_ExponentialSmoothing_Holt_F8_NonSeasonal = 629
        SFM_ExponentialSmoothing_Holt_F8_Seasonal = 630
        SFM_ExponentialSmoothing_Holt_L2_NonSeasonal = 631
        SFM_ExponentialSmoothing_Holt_L2_Seasonal = 632
        SFM_ExponentialSmoothing_Holt_L4_NonSeasonal = 633
        SFM_ExponentialSmoothing_Holt_L4_Seasonal = 634
        SFM_ExponentialSmoothing_Holt_L5_NonSeasonal = 635
        SFM_ExponentialSmoothing_Holt_L5_Seasonal = 636
        SFM_ExponentialSmoothing_Holt_L6_NonSeasonal = 637
        SFM_ExponentialSmoothing_Holt_L6_Seasonal = 638
        SFM_ExponentialSmoothing_Holt_L8_NonSeasonal = 639
        SFM_ExponentialSmoothing_Holt_L8_Seasonal = 640
        'Damped Exponential Smoothing
        SFM_ExponentialSmoothing_Damped_A2_NonSeasonal = 651
        SFM_ExponentialSmoothing_Damped_A2_Seasonal = 652
        SFM_ExponentialSmoothing_Damped_A4_NonSeasonal = 653
        SFM_ExponentialSmoothing_Damped_A4_Seasonal = 654
        SFM_ExponentialSmoothing_Damped_A5_NonSeasonal = 655
        SFM_ExponentialSmoothing_Damped_A5_Seasonal = 656
        SFM_ExponentialSmoothing_Damped_A6_NonSeasonal = 657
        SFM_ExponentialSmoothing_Damped_A6_Seasonal = 658
        SFM_ExponentialSmoothing_Damped_A8_NonSeasonal = 659
        SFM_ExponentialSmoothing_Damped_A8_Seasonal = 660
        SFM_ExponentialSmoothing_Damped_M2_NonSeasonal = 661
        SFM_ExponentialSmoothing_Damped_M2_Seasonal = 662
        SFM_ExponentialSmoothing_Damped_M4_NonSeasonal = 663
        SFM_ExponentialSmoothing_Damped_M4_Seasonal = 664
        SFM_ExponentialSmoothing_Damped_M5_NonSeasonal = 665
        SFM_ExponentialSmoothing_Damped_M5_Seasonal = 666
        SFM_ExponentialSmoothing_Damped_M6_NonSeasonal = 667
        SFM_ExponentialSmoothing_Damped_M6_Seasonal = 668
        SFM_ExponentialSmoothing_Damped_M8_NonSeasonal = 669
        SFM_ExponentialSmoothing_Damped_M8_Seasonal = 670
        SFM_ExponentialSmoothing_Damped_F2_NonSeasonal = 671
        SFM_ExponentialSmoothing_Damped_F2_Seasonal = 672
        SFM_ExponentialSmoothing_Damped_F4_NonSeasonal = 673
        SFM_ExponentialSmoothing_Damped_F4_Seasonal = 674
        SFM_ExponentialSmoothing_Damped_F5_NonSeasonal = 675
        SFM_ExponentialSmoothing_Damped_F5_Seasonal = 676
        SFM_ExponentialSmoothing_Damped_F6_NonSeasonal = 677
        SFM_ExponentialSmoothing_Damped_F6_Seasonal = 678
        SFM_ExponentialSmoothing_Damped_F8_NonSeasonal = 679
        SFM_ExponentialSmoothing_Damped_F8_Seasonal = 680
        SFM_ExponentialSmoothing_Damped_L2_NonSeasonal = 681
        SFM_ExponentialSmoothing_Damped_L2_Seasonal = 682
        SFM_ExponentialSmoothing_Damped_L4_NonSeasonal = 683
        SFM_ExponentialSmoothing_Damped_L4_Seasonal = 684
        SFM_ExponentialSmoothing_Damped_L5_NonSeasonal = 685
        SFM_ExponentialSmoothing_Damped_L5_Seasonal = 686
        SFM_ExponentialSmoothing_Damped_L6_NonSeasonal = 687
        SFM_ExponentialSmoothing_Damped_L6_Seasonal = 688
        SFM_ExponentialSmoothing_Damped_L8_NonSeasonal = 689
        SFM_ExponentialSmoothing_Damped_L8_Seasonal = 690
        'ARIMA Group
        SFM_Arima_001_NonSeasonal = 701
        SFM_Arima_001_Seasonal = 702
        SFM_Arima_100_NonSeasonal = 703
        SFM_Arima_100_Seasonal = 704
        SFM_Arima_010_NonSeasonal = 705
        SFM_Arima_010_Seasonal = 706
        SFM_Arima_011_NonSeasonal = 707
        SFM_Arima_011_Seasonal = 708
        SFM_Arima_110_NonSeasonal = 709
        SFM_Arima_110_Seasonal = 710
        SFM_Arima_111_NonSeasonal = 711
        SFM_Arima_111_Seasonal = 712
        'THETA Group with 2.00
        SFM_Theta_200_ExponentialSmoothing_Simple_A2_NonSeasonal = 801
        SFM_Theta_200_ExponentialSmoothing_Simple_A2_Seasonal = 802
        SFM_Theta_200_ExponentialSmoothing_Simple_A4_NonSeasonal = 803
        SFM_Theta_200_ExponentialSmoothing_Simple_A4_Seasonal = 804
        SFM_Theta_200_ExponentialSmoothing_Simple_A5_NonSeasonal = 805
        SFM_Theta_200_ExponentialSmoothing_Simple_A5_Seasonal = 806
        SFM_Theta_200_ExponentialSmoothing_Simple_A6_NonSeasonal = 807
        SFM_Theta_200_ExponentialSmoothing_Simple_A6_Seasonal = 808
        SFM_Theta_200_ExponentialSmoothing_Simple_A8_NonSeasonal = 809
        SFM_Theta_200_ExponentialSmoothing_Simple_A8_Seasonal = 810
        SFM_Theta_200_ExponentialSmoothing_Simple_M2_NonSeasonal = 811
        SFM_Theta_200_ExponentialSmoothing_Simple_M2_Seasonal = 812
        SFM_Theta_200_ExponentialSmoothing_Simple_M4_NonSeasonal = 813
        SFM_Theta_200_ExponentialSmoothing_Simple_M4_Seasonal = 814
        SFM_Theta_200_ExponentialSmoothing_Simple_M5_NonSeasonal = 815
        SFM_Theta_200_ExponentialSmoothing_Simple_M5_Seasonal = 816
        SFM_Theta_200_ExponentialSmoothing_Simple_M6_NonSeasonal = 817
        SFM_Theta_200_ExponentialSmoothing_Simple_M6_Seasonal = 818
        SFM_Theta_200_ExponentialSmoothing_Simple_M8_NonSeasonal = 819
        SFM_Theta_200_ExponentialSmoothing_Simple_M8_Seasonal = 820
        SFM_Theta_200_ExponentialSmoothing_Simple_F2_NonSeasonal = 821
        SFM_Theta_200_ExponentialSmoothing_Simple_F2_Seasonal = 822
        SFM_Theta_200_ExponentialSmoothing_Simple_F4_NonSeasonal = 823
        SFM_Theta_200_ExponentialSmoothing_Simple_F4_Seasonal = 824
        SFM_Theta_200_ExponentialSmoothing_Simple_F5_NonSeasonal = 825
        SFM_Theta_200_ExponentialSmoothing_Simple_F5_Seasonal = 826
        SFM_Theta_200_ExponentialSmoothing_Simple_F6_NonSeasonal = 827
        SFM_Theta_200_ExponentialSmoothing_Simple_F6_Seasonal = 828
        SFM_Theta_200_ExponentialSmoothing_Simple_F8_NonSeasonal = 829
        SFM_Theta_200_ExponentialSmoothing_Simple_F8_Seasonal = 830
        SFM_Theta_200_ExponentialSmoothing_Simple_L2_NonSeasonal = 831
        SFM_Theta_200_ExponentialSmoothing_Simple_L2_Seasonal = 832
        SFM_Theta_200_ExponentialSmoothing_Simple_L4_NonSeasonal = 833
        SFM_Theta_200_ExponentialSmoothing_Simple_L4_Seasonal = 834
        SFM_Theta_200_ExponentialSmoothing_Simple_L5_NonSeasonal = 835
        SFM_Theta_200_ExponentialSmoothing_Simple_L5_Seasonal = 836
        SFM_Theta_200_ExponentialSmoothing_Simple_L6_NonSeasonal = 837
        SFM_Theta_200_ExponentialSmoothing_Simple_L6_Seasonal = 838
        SFM_Theta_200_ExponentialSmoothing_Simple_L8_NonSeasonal = 839
        SFM_Theta_200_ExponentialSmoothing_Simple_L8_Seasonal = 840
        'THETA Group with 1.50
        SFM_Theta_150_ExponentialSmoothing_Simple_A2_NonSeasonal = 851
        SFM_Theta_150_ExponentialSmoothing_Simple_A2_Seasonal = 852
        SFM_Theta_150_ExponentialSmoothing_Simple_A4_NonSeasonal = 853
        SFM_Theta_150_ExponentialSmoothing_Simple_A4_Seasonal = 854
        SFM_Theta_150_ExponentialSmoothing_Simple_A5_NonSeasonal = 855
        SFM_Theta_150_ExponentialSmoothing_Simple_A5_Seasonal = 856
        SFM_Theta_150_ExponentialSmoothing_Simple_A6_NonSeasonal = 857
        SFM_Theta_150_ExponentialSmoothing_Simple_A6_Seasonal = 858
        SFM_Theta_150_ExponentialSmoothing_Simple_A8_NonSeasonal = 859
        SFM_Theta_150_ExponentialSmoothing_Simple_A8_Seasonal = 860
        SFM_Theta_150_ExponentialSmoothing_Simple_M2_NonSeasonal = 861
        SFM_Theta_150_ExponentialSmoothing_Simple_M2_Seasonal = 862
        SFM_Theta_150_ExponentialSmoothing_Simple_M4_NonSeasonal = 863
        SFM_Theta_150_ExponentialSmoothing_Simple_M4_Seasonal = 864
        SFM_Theta_150_ExponentialSmoothing_Simple_M5_NonSeasonal = 865
        SFM_Theta_150_ExponentialSmoothing_Simple_M5_Seasonal = 866
        SFM_Theta_150_ExponentialSmoothing_Simple_M6_NonSeasonal = 867
        SFM_Theta_150_ExponentialSmoothing_Simple_M6_Seasonal = 868
        SFM_Theta_150_ExponentialSmoothing_Simple_M8_NonSeasonal = 869
        SFM_Theta_150_ExponentialSmoothing_Simple_M8_Seasonal = 870
        SFM_Theta_150_ExponentialSmoothing_Simple_F2_NonSeasonal = 871
        SFM_Theta_150_ExponentialSmoothing_Simple_F2_Seasonal = 872
        SFM_Theta_150_ExponentialSmoothing_Simple_F4_NonSeasonal = 873
        SFM_Theta_150_ExponentialSmoothing_Simple_F4_Seasonal = 874
        SFM_Theta_150_ExponentialSmoothing_Simple_F5_NonSeasonal = 875
        SFM_Theta_150_ExponentialSmoothing_Simple_F5_Seasonal = 876
        SFM_Theta_150_ExponentialSmoothing_Simple_F6_NonSeasonal = 877
        SFM_Theta_150_ExponentialSmoothing_Simple_F6_Seasonal = 878
        SFM_Theta_150_ExponentialSmoothing_Simple_F8_NonSeasonal = 879
        SFM_Theta_150_ExponentialSmoothing_Simple_F8_Seasonal = 880
        SFM_Theta_150_ExponentialSmoothing_Simple_L2_NonSeasonal = 881
        SFM_Theta_150_ExponentialSmoothing_Simple_L2_Seasonal = 882
        SFM_Theta_150_ExponentialSmoothing_Simple_L4_NonSeasonal = 883
        SFM_Theta_150_ExponentialSmoothing_Simple_L4_Seasonal = 884
        SFM_Theta_150_ExponentialSmoothing_Simple_L5_NonSeasonal = 885
        SFM_Theta_150_ExponentialSmoothing_Simple_L5_Seasonal = 886
        SFM_Theta_150_ExponentialSmoothing_Simple_L6_NonSeasonal = 887
        SFM_Theta_150_ExponentialSmoothing_Simple_L6_Seasonal = 888
        SFM_Theta_150_ExponentialSmoothing_Simple_L8_NonSeasonal = 889
        SFM_Theta_150_ExponentialSmoothing_Simple_L8_Seasonal = 890
        'THETA Group with 0.75
        SFM_Theta_075_ExponentialSmoothing_Simple_A2_NonSeasonal = 901
        SFM_Theta_075_ExponentialSmoothing_Simple_A2_Seasonal = 902
        SFM_Theta_075_ExponentialSmoothing_Simple_A4_NonSeasonal = 903
        SFM_Theta_075_ExponentialSmoothing_Simple_A4_Seasonal = 904
        SFM_Theta_075_ExponentialSmoothing_Simple_A5_NonSeasonal = 905
        SFM_Theta_075_ExponentialSmoothing_Simple_A5_Seasonal = 906
        SFM_Theta_075_ExponentialSmoothing_Simple_A6_NonSeasonal = 907
        SFM_Theta_075_ExponentialSmoothing_Simple_A6_Seasonal = 908
        SFM_Theta_075_ExponentialSmoothing_Simple_A8_NonSeasonal = 909
        SFM_Theta_075_ExponentialSmoothing_Simple_A8_Seasonal = 910
        SFM_Theta_075_ExponentialSmoothing_Simple_M2_NonSeasonal = 911
        SFM_Theta_075_ExponentialSmoothing_Simple_M2_Seasonal = 912
        SFM_Theta_075_ExponentialSmoothing_Simple_M4_NonSeasonal = 913
        SFM_Theta_075_ExponentialSmoothing_Simple_M4_Seasonal = 914
        SFM_Theta_075_ExponentialSmoothing_Simple_M5_NonSeasonal = 915
        SFM_Theta_075_ExponentialSmoothing_Simple_M5_Seasonal = 916
        SFM_Theta_075_ExponentialSmoothing_Simple_M6_NonSeasonal = 917
        SFM_Theta_075_ExponentialSmoothing_Simple_M6_Seasonal = 918
        SFM_Theta_075_ExponentialSmoothing_Simple_M8_NonSeasonal = 919
        SFM_Theta_075_ExponentialSmoothing_Simple_M8_Seasonal = 920
        SFM_Theta_075_ExponentialSmoothing_Simple_F2_NonSeasonal = 921
        SFM_Theta_075_ExponentialSmoothing_Simple_F2_Seasonal = 922
        SFM_Theta_075_ExponentialSmoothing_Simple_F4_NonSeasonal = 923
        SFM_Theta_075_ExponentialSmoothing_Simple_F4_Seasonal = 924
        SFM_Theta_075_ExponentialSmoothing_Simple_F5_NonSeasonal = 925
        SFM_Theta_075_ExponentialSmoothing_Simple_F5_Seasonal = 926
        SFM_Theta_075_ExponentialSmoothing_Simple_F6_NonSeasonal = 927
        SFM_Theta_075_ExponentialSmoothing_Simple_F6_Seasonal = 928
        SFM_Theta_075_ExponentialSmoothing_Simple_F8_NonSeasonal = 929
        SFM_Theta_075_ExponentialSmoothing_Simple_F8_Seasonal = 930
        SFM_Theta_075_ExponentialSmoothing_Simple_L2_NonSeasonal = 931
        SFM_Theta_075_ExponentialSmoothing_Simple_L2_Seasonal = 932
        SFM_Theta_075_ExponentialSmoothing_Simple_L4_NonSeasonal = 933
        SFM_Theta_075_ExponentialSmoothing_Simple_L4_Seasonal = 934
        SFM_Theta_075_ExponentialSmoothing_Simple_L5_NonSeasonal = 935
        SFM_Theta_075_ExponentialSmoothing_Simple_L5_Seasonal = 936
        SFM_Theta_075_ExponentialSmoothing_Simple_L6_NonSeasonal = 937
        SFM_Theta_075_ExponentialSmoothing_Simple_L6_Seasonal = 938
        SFM_Theta_075_ExponentialSmoothing_Simple_L8_NonSeasonal = 939
        SFM_Theta_075_ExponentialSmoothing_Simple_L8_Seasonal = 940
        'THETA Group with 0.50
        SFM_Theta_050_ExponentialSmoothing_Simple_A2_NonSeasonal = 951
        SFM_Theta_050_ExponentialSmoothing_Simple_A2_Seasonal = 952
        SFM_Theta_050_ExponentialSmoothing_Simple_A4_NonSeasonal = 953
        SFM_Theta_050_ExponentialSmoothing_Simple_A4_Seasonal = 954
        SFM_Theta_050_ExponentialSmoothing_Simple_A5_NonSeasonal = 955
        SFM_Theta_050_ExponentialSmoothing_Simple_A5_Seasonal = 956
        SFM_Theta_050_ExponentialSmoothing_Simple_A6_NonSeasonal = 957
        SFM_Theta_050_ExponentialSmoothing_Simple_A6_Seasonal = 958
        SFM_Theta_050_ExponentialSmoothing_Simple_A8_NonSeasonal = 959
        SFM_Theta_050_ExponentialSmoothing_Simple_A8_Seasonal = 960
        SFM_Theta_050_ExponentialSmoothing_Simple_M2_NonSeasonal = 961
        SFM_Theta_050_ExponentialSmoothing_Simple_M2_Seasonal = 962
        SFM_Theta_050_ExponentialSmoothing_Simple_M4_NonSeasonal = 963
        SFM_Theta_050_ExponentialSmoothing_Simple_M4_Seasonal = 964
        SFM_Theta_050_ExponentialSmoothing_Simple_M5_NonSeasonal = 965
        SFM_Theta_050_ExponentialSmoothing_Simple_M5_Seasonal = 966
        SFM_Theta_050_ExponentialSmoothing_Simple_M6_NonSeasonal = 967
        SFM_Theta_050_ExponentialSmoothing_Simple_M6_Seasonal = 968
        SFM_Theta_050_ExponentialSmoothing_Simple_M8_NonSeasonal = 969
        SFM_Theta_050_ExponentialSmoothing_Simple_M8_Seasonal = 970
        SFM_Theta_050_ExponentialSmoothing_Simple_F2_NonSeasonal = 971
        SFM_Theta_050_ExponentialSmoothing_Simple_F2_Seasonal = 972
        SFM_Theta_050_ExponentialSmoothing_Simple_F4_NonSeasonal = 973
        SFM_Theta_050_ExponentialSmoothing_Simple_F4_Seasonal = 974
        SFM_Theta_050_ExponentialSmoothing_Simple_F5_NonSeasonal = 975
        SFM_Theta_050_ExponentialSmoothing_Simple_F5_Seasonal = 976
        SFM_Theta_050_ExponentialSmoothing_Simple_F6_NonSeasonal = 977
        SFM_Theta_050_ExponentialSmoothing_Simple_F6_Seasonal = 978
        SFM_Theta_050_ExponentialSmoothing_Simple_F8_NonSeasonal = 979
        SFM_Theta_050_ExponentialSmoothing_Simple_F8_Seasonal = 980
        SFM_Theta_050_ExponentialSmoothing_Simple_L2_NonSeasonal = 981
        SFM_Theta_050_ExponentialSmoothing_Simple_L2_Seasonal = 982
        SFM_Theta_050_ExponentialSmoothing_Simple_L4_NonSeasonal = 983
        SFM_Theta_050_ExponentialSmoothing_Simple_L4_Seasonal = 984
        SFM_Theta_050_ExponentialSmoothing_Simple_L5_NonSeasonal = 985
        SFM_Theta_050_ExponentialSmoothing_Simple_L5_Seasonal = 986
        SFM_Theta_050_ExponentialSmoothing_Simple_L6_NonSeasonal = 987
        SFM_Theta_050_ExponentialSmoothing_Simple_L6_Seasonal = 988
        SFM_Theta_050_ExponentialSmoothing_Simple_L8_NonSeasonal = 989
        SFM_Theta_050_ExponentialSmoothing_Simple_L8_Seasonal = 990
    End Enum

    '***************************************************************************************************************************************************************************
    Public Shared Function Forecast(ByVal iMethod As Integer,
                                                                ByRef dData() As Double,
                                                                ByRef dtDate() As Date,
                                                                ByRef dTime() As Double,
                                                                ByVal iSeasonality As Integer,
                                                                ByRef iSeasonalPattern() As Integer,
                                                                ByVal iHorizon As Integer,
                                                                ByRef dForecasts() As Double) As Boolean
        'TimeSerie
        Dim dDataDezero() As Double
        Dim dtDateDezero() As Date
        Dim dTimeDezero() As Double
        Dim iSeasonalityDezero As Integer
        Dim iHorizonDezero As Integer

        Dim dDataDeseason() As Double
        Dim dtDateDeseason() As Date
        Dim dTimeDeseason() As Double

        Dim dIndexes() As Double
        Dim iFirstPointPeriod As Integer
        Dim iTimeSerieLength As Integer
        Dim dConstant As Double
        Dim dSlope As Double

        'Forecasts
        Dim dFData_Deseason() As Double
        Dim dtFDate_Deseason() As Date
        Dim dFData_Dezero() As Double
        Dim dtFDate_Dezero() As Date
        Dim dFData() As Double
        Dim dtFDate() As Date

        Dim i As Integer
        Dim k As Integer
        Dim n As Integer
        Dim DoDeseasonFlag As Boolean

        Dim sErrorMessage As String = String.Empty

        'init
        iFirstPointPeriod = TimeSerie_CalculatePointPeriod(dtDate(1), iSeasonality)
        iTimeSerieLength = UBound(dData)

        'Φτιαξε την χρονοσειρά χωρίς τα μηδενικά και υπολόγισε το ihorizonDezero
        Timeserie_Dezero(dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, iFirstPointPeriod, dDataDezero, dtDateDezero, dTimeDezero, iHorizonDezero, iSeasonalityDezero)

        'Φτιαξε την χρονοσειρά χωρίς εποχιακότητα
        DoDeseasonFlag = False
        If clsCommonMath.IsOdd(iMethod) = True Then
            'ODD - Monos
            DoDeseasonFlag = False      'μην κάνεις εποχιακότητα
        Else
            'EVEN - zigos
            If iSeasonalityDezero = 1 Then
                DoDeseasonFlag = False      'μην κάνεις εποχιακότητα, there is no point to look for seasonality into YEARLY timeseries
            Else
                DoDeseasonFlag = True    'κάνε εποχιακότητα 
            End If

        End If

        'If clsForecast_Tools.Seasonality_Check(dDataDezero, iSeasonalityDezero) = True And DoDeseasonFlag = True Then
        '--> Do not check for seasonality. Do it anyway if requested
        If DoDeseasonFlag = True Then
            'Υπολόγισε χρονοσειρά χωρίς εποχιακότητα
            Timeserie_Deseasonalize(dDataDezero, dTimeDezero, dtDateDezero, iSeasonalityDezero, iMethod, dDataDeseason, dIndexes)
            ReDim dtDateDeseason(UBound(dtDateDezero))
            Array.Copy(dtDateDezero, dtDateDeseason, UBound(dtDateDezero) + 1)
            ReDim dTimeDeseason(UBound(dTimeDezero))
            Array.Copy(dTimeDezero, dTimeDeseason, UBound(dTimeDezero) + 1)
        Else
            'Δεν έχει εποχιακότητα
            ReDim dDataDeseason(UBound(dDataDezero))
            Array.Copy(dDataDezero, dDataDeseason, UBound(dDataDezero) + 1)
            ReDim dtDateDeseason(UBound(dtDateDezero))
            Array.Copy(dtDateDezero, dtDateDeseason, UBound(dtDateDezero) + 1)
            ReDim dTimeDeseason(UBound(dTimeDezero))
            Array.Copy(dTimeDezero, dTimeDeseason, UBound(dTimeDezero) + 1)
            iSeasonalityDezero = iSeasonality
            ReDim dIndexes(iSeasonalityDezero)
            For i = 1 To UBound(dIndexes) 'for i = LBound(dIndexes) To UBound(dIndexes)
                Select Case iMethod
                    Case 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320
                        dIndexes(i) = 0
                    Case Else
                        dIndexes(i) = 1
                End Select
            Next i
        End If

        'Detect & Remove Outliers --> Do not keep the impact of the outliers...
        Timeserie_DetectOutliers(dDataDeseason, sErrorMessage)


        'Forecasts Tables
        ReDim dFData_Deseason(iHorizonDezero)
        ReDim dtFDate_Deseason(iHorizonDezero)
        ReDim dFData_Dezero(iHorizonDezero)
        ReDim dtFDate_Dezero(iHorizonDezero)
        ReDim dFData(iHorizon)
        ReDim dtFDate(iHorizon)
        ReDim dForecasts(iHorizon)

        'Βάλε τιμές στους πίνακες ημερομηνιών
        For i = 1 To iHorizon
            If i = 1 Then
                dtFDate(i) = TimeSerie_Calculate_NextDate(dtDate(iTimeSerieLength), iSeasonality)
            Else
                dtFDate(i) = TimeSerie_Calculate_NextDate(dtFDate(i - 1), iSeasonality)
            End If
        Next i

        'Προβλέψεις χωρίς εποχιακότητα
        Select Case iMethod
            'Naive Group
            Case enmForecastMethod.SFM_Naive_NonSeasonal '101
                clsForecast_Methods.Naive(dDataDeseason, iHorizonDezero, dFData_Deseason)
            Case enmForecastMethod.SFM_Naive_Seasonal       '102
                clsForecast_Methods.Naive(dDataDeseason, iHorizonDezero, dFData_Deseason)
            Case enmForecastMethod.SFM_Naive_Trend_NonSeasonal '103
                clsForecast_Methods.Naive_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, dFData_Deseason)
            Case enmForecastMethod.SFM_Naive_Trend_Seasonal     '104
                clsForecast_Methods.Naive_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, dFData_Deseason)
            Case enmForecastMethod.SFM_Mean_NonSeasonal '105
                clsForecast_Methods.Mean(dDataDeseason, iHorizonDezero, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Mean_Seasonal '106
                clsForecast_Methods.Mean(dDataDeseason, iHorizonDezero, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Median_NonSeasonal '107
                clsForecast_Methods.Median(dDataDeseason, iHorizonDezero, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Median_Seasonal '108
                clsForecast_Methods.Median(dDataDeseason, iHorizonDezero, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Naive_Repeat_NonSeasonal '109
                clsForecast_Methods.NaiveRepeat(dDataDeseason, iHorizonDezero, iSeasonalityDezero, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Naive_Repeat_Seasonal '110
                clsForecast_Methods.NaiveRepeat(dDataDeseason, iHorizonDezero, iSeasonalityDezero, dFData_Deseason, sErrorMessage)

            'Linear Regression Group
            Case enmForecastMethod.SFM_LinearRegression_Simple_NonSeasonal ' 201
                clsForecast_Methods.LinearRegression_Simple(dDataDeseason, dTimeDeseason, iHorizonDezero, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_LinearRegression_Simple_Seasonal ' 202
                clsForecast_Methods.LinearRegression_Simple(dDataDeseason, dTimeDeseason, iHorizonDezero, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_LinearRegression_Multiple_NonSeasonal ' 203
                'clsForecast_Methods.LinearRegression_Multiple(dDataDeseason, dTimeDeseason, iHorizonDezero, dFData_Deseason, sErrorMessage) 'NOT USED
                'clsForecast_Methods.MultipleRegression(dDataDeseason, dtDateDeseason, CShort(iHorizonDezero), dFData_Deseason)
            Case enmForecastMethod.SFM_LinearRegression_Multiple_Seasonal ' 204
                'clsForecast_Methods.LinearRegression_Multiple(dDataDeseason, dTimeDeseason, iHorizonDezero, dFData_Deseason, sErrorMessage) 'NOT USED

            'Decomposition Group - Additive
            Case enmForecastMethod.SFM_Decomposition_Additive_Classical_NonSeasonal '301
                clsForecast_Methods.Decomposition_Additive_Classical(dDataDeseason, dTimeDeseason, iHorizonDezero, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_Classical_Seasonal '302
                clsForecast_Methods.Decomposition_Additive_Classical(dDataDeseason, dTimeDeseason, iHorizonDezero, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MAS3B_NonSeasonal ' 303
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "S", 3, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MAS3B_Seasonal ' 304
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "S", 3, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MAS5B_NonSeasonal ' 305
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "S", 5, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MAS5B_Seasonal ' 306
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "S", 5, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MASNB_NonSeasonal ' 307
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "S", iSeasonalityDezero, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MASNB_Seasonal ' 308
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "S", iSeasonalityDezero, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MAW3B_NonSeasonal ' 309
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "W", 3, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MAW3B_Seasonal ' 310
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "W", 3, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MAW5B_NonSeasonal ' 311
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "W", 5, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MAW5B_Seasonal ' 312
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "W", 5, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MAWNB_NonSeasonal ' 313
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "W", iSeasonalityDezero, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MAWNB_Seasonal ' 314
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "W", iSeasonalityDezero, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MAD3B_NonSeasonal ' 315
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "D", 3, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MAD3B_Seasonal ' 316
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "D", 3, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MAD5B_NonSeasonal ' 317
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "D", 5, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MAD5B_Seasonal ' 318
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "D", 5, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MADNB_NonSeasonal ' 319
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "D", iSeasonalityDezero, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Additive_MADNB_Seasonal ' 320
                clsForecast_Methods.Decomposition_Additive_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "D", iSeasonalityDezero, dFData_Deseason, False)
            'Decomposition Group - Multiplicative
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_Classical_NonSeasonal '351
                clsForecast_Methods.Decomposition_Mutliplicative_Classical(dDataDeseason, dTimeDeseason, iHorizonDezero, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_Classical_Seasonal '352
                clsForecast_Methods.Decomposition_Mutliplicative_Classical(dDataDeseason, dTimeDeseason, iHorizonDezero, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MAS3B_NonSeasonal ' 353
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "S", 3, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MAS3B_Seasonal ' 354
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "S", 3, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MAS5B_NonSeasonal ' 355
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "S", 5, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MAS5B_Seasonal ' 356
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "S", 5, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MASNB_NonSeasonal ' 357
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "S", iSeasonalityDezero, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MASNB_Seasonal ' 358
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "S", iSeasonalityDezero, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MAW3B_NonSeasonal ' 359
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "W", 3, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MAW3B_Seasonal ' 360
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "W", 3, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MAW5B_NonSeasonal ' 361
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "W", 5, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MAW5B_Seasonal ' 362
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "W", 5, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MAWNB_NonSeasonal ' 363
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "W", iSeasonalityDezero, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MAWNB_Seasonal ' 364
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "W", iSeasonalityDezero, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MAD3B_NonSeasonal ' 365
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "D", 3, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MAD3B_Seasonal ' 366
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "D", 3, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MAD5B_NonSeasonal ' 367
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "D", 5, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MAD5B_Seasonal ' 368
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "D", 5, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MADNB_NonSeasonal ' 369
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "D", iSeasonalityDezero, dFData_Deseason, False)
            Case enmForecastMethod.SFM_Decomposition_Multiplicative_MADNB_Seasonal ' 370
                clsForecast_Methods.Decomposition_Mutliplicative_SpecialMovingAverage(dDataDeseason, dTimeDeseason, iHorizonDezero, "D", iSeasonalityDezero, dFData_Deseason, False)

            'Moving Average Group - Simple
            Case enmForecastMethod.SFM_MovingAverage_Simple3_NonSeasonal '401
                clsForecast_Methods.MovingAverage_SimpleN(dDataDeseason, iHorizonDezero, 3, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Simple3_Seasonal '402
                clsForecast_Methods.MovingAverage_SimpleN(dDataDeseason, iHorizonDezero, 3, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Simple5_NonSeasonal '403
                clsForecast_Methods.MovingAverage_SimpleN(dDataDeseason, iHorizonDezero, 5, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Simple5_Seasonal '404
                clsForecast_Methods.MovingAverage_SimpleN(dDataDeseason, iHorizonDezero, 5, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_SimpleN_NonSeasonal '405
                clsForecast_Methods.MovingAverage_SimpleN(dDataDeseason, iHorizonDezero, iSeasonalityDezero, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_SimpleN_Seasonal '406
                clsForecast_Methods.MovingAverage_SimpleN(dDataDeseason, iHorizonDezero, iSeasonalityDezero, dFData_Deseason, sErrorMessage)
            'Moving Average Group - Simple with Backcasting
            Case enmForecastMethod.SFM_MovingAverage_Simple3b_NonSeasonal '407
                clsForecast_Methods.MovingAverage_SimpleN_Backstaging(dDataDeseason, iHorizonDezero, 3, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Simple3b_Seasonal '408
                clsForecast_Methods.MovingAverage_SimpleN_Backstaging(dDataDeseason, iHorizonDezero, 3, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Simple5b_NonSeasonal '409
                clsForecast_Methods.MovingAverage_SimpleN_Backstaging(dDataDeseason, iHorizonDezero, 5, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Simple5b_Seasonal '410
                clsForecast_Methods.MovingAverage_SimpleN_Backstaging(dDataDeseason, iHorizonDezero, 5, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_SimpleNb_NonSeasonal '411
                clsForecast_Methods.MovingAverage_SimpleN_Backstaging(dDataDeseason, iHorizonDezero, iSeasonalityDezero, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_SimpleNb_Seasonal '412
                clsForecast_Methods.MovingAverage_SimpleN_Backstaging(dDataDeseason, iHorizonDezero, iSeasonalityDezero, dFData_Deseason, sErrorMessage)
            'Moving Average Group - Weighted
            Case enmForecastMethod.SFM_MovingAverage_Weighted3_NonSeasonal ' 413
                clsForecast_Methods.MovingAverage_WeightedN(dDataDeseason, iHorizonDezero, 3, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Weighted3_Seasonal ' 414
                clsForecast_Methods.MovingAverage_WeightedN(dDataDeseason, iHorizonDezero, 3, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Weighted5_NonSeasonal ' 415
                clsForecast_Methods.MovingAverage_WeightedN(dDataDeseason, iHorizonDezero, 5, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Weighted5_Seasonal ' 416
                clsForecast_Methods.MovingAverage_WeightedN(dDataDeseason, iHorizonDezero, 5, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_WeightedN_NonSeasonal ' 417
                clsForecast_Methods.MovingAverage_WeightedN(dDataDeseason, iHorizonDezero, iSeasonalityDezero, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_WeightedN_Seasonal ' 418
                clsForecast_Methods.MovingAverage_WeightedN(dDataDeseason, iHorizonDezero, iSeasonalityDezero, dFData_Deseason, sErrorMessage)
            'Moving Average Group - Weighted with Backstage
            Case enmForecastMethod.SFM_MovingAverage_Weighted3b_NonSeasonal ' 419
                clsForecast_Methods.MovingAverage_WeightedN_Backstaging(dDataDeseason, iHorizonDezero, 3, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Weighted3b_Seasonal ' 420
                clsForecast_Methods.MovingAverage_WeightedN_Backstaging(dDataDeseason, iHorizonDezero, 3, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Weighted5b_NonSeasonal ' 421
                clsForecast_Methods.MovingAverage_WeightedN_Backstaging(dDataDeseason, iHorizonDezero, 5, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Weighted5b_Seasonal ' 422
                clsForecast_Methods.MovingAverage_WeightedN_Backstaging(dDataDeseason, iHorizonDezero, 5, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_WeightedNb_NonSeasonal ' 423
                clsForecast_Methods.MovingAverage_WeightedN_Backstaging(dDataDeseason, iHorizonDezero, iSeasonalityDezero, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_WeightedNb_Seasonal ' 424
                clsForecast_Methods.MovingAverage_WeightedN_Backstaging(dDataDeseason, iHorizonDezero, iSeasonalityDezero, dFData_Deseason, sErrorMessage)
            'Moving Average Group - Double
            Case enmForecastMethod.SFM_MovingAverage_Double3_NonSeasonal '425
                clsForecast_Methods.MovingAverage_DoubleN(dDataDeseason, iHorizonDezero, 3, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Double3_Seasonal '426
                clsForecast_Methods.MovingAverage_DoubleN(dDataDeseason, iHorizonDezero, 3, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Double5_NonSeasonal '427
                clsForecast_Methods.MovingAverage_DoubleN(dDataDeseason, iHorizonDezero, 5, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Double5_Seasonal '428
                clsForecast_Methods.MovingAverage_DoubleN(dDataDeseason, iHorizonDezero, 5, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_DoubleN_NonSeasonal '429
                clsForecast_Methods.MovingAverage_DoubleN(dDataDeseason, iHorizonDezero, iSeasonalityDezero, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_DoubleN_Seasonal '430
                clsForecast_Methods.MovingAverage_DoubleN(dDataDeseason, iHorizonDezero, iSeasonalityDezero, dFData_Deseason, sErrorMessage)
            'Moving Average Group - Double with Backstage
            Case enmForecastMethod.SFM_MovingAverage_Double3b_NonSeasonal '431
                clsForecast_Methods.MovingAverage_DoubleN_Backstaging(dDataDeseason, iHorizonDezero, 3, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Double3b_Seasonal '432
                clsForecast_Methods.MovingAverage_DoubleN_Backstaging(dDataDeseason, iHorizonDezero, 3, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Double5b_NonSeasonal '433
                clsForecast_Methods.MovingAverage_DoubleN_Backstaging(dDataDeseason, iHorizonDezero, 5, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_Double5b_Seasonal '434
                clsForecast_Methods.MovingAverage_DoubleN_Backstaging(dDataDeseason, iHorizonDezero, 5, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_DoubleNb_NonSeasonal '435
                clsForecast_Methods.MovingAverage_DoubleN_Backstaging(dDataDeseason, iHorizonDezero, iSeasonalityDezero, dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_MovingAverage_DoubleNb_Seasonal '436
                clsForecast_Methods.MovingAverage_DoubleN_Backstaging(dDataDeseason, iHorizonDezero, iSeasonalityDezero, dFData_Deseason, sErrorMessage)

            'Simple Exponential Smoothing Group
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_A2_NonSeasonal '501
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.2, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_A2_Seasonal '502
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.2, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_A4_NonSeasonal ' 503
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.4, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_A4_Seasonal ' 504
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.4, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_A5_NonSeasonal ' 505
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.5, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_A5_Seasonal ' 506
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.5, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_A6_NonSeasonal ' 507
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.6, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_A6_Seasonal ' 508
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.6, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_A8_NonSeasonal ' 509
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_A8_Seasonal ' 510
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_M2_NonSeasonal ' 511
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.2, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_M2_Seasonal ' 512
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.2, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_M4_NonSeasonal ' 513
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.4, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_M4_Seasonal ' 514
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.4, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_M5_NonSeasonal ' 515
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.5, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_M5_Seasonal ' 516
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.5, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_M6_NonSeasonal ' 517
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.6, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_M6_Seasonal ' 518
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.6, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_M8_NonSeasonal ' 519
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_M8_Seasonal ' 520
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_F2_NonSeasonal ' 521
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.2, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_F2_Seasonal ' 522
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.2, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_F4_NonSeasonal ' 523
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.4, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_F4_Seasonal ' 524
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.4, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_F5_NonSeasonal ' 525
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.5, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_F5_Seasonal ' 526
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.5, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_F6_NonSeasonal ' 527
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.6, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_F6_Seasonal ' 528
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.6, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_F8_NonSeasonal ' 529
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_F8_Seasonal ' 530
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_L2_NonSeasonal ' 531
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.2, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_L2_Seasonal ' 532
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.2, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_L4_NonSeasonal ' 533
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.4, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_L4_Seasonal ' 534
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.4, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_L5_NonSeasonal ' 535
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.5, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_L5_Seasonal ' 536
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.5, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_L6_NonSeasonal ' 537
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.6, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_L6_Seasonal ' 538
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.6, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_L8_NonSeasonal ' 539
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.8, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Simple_L8_Seasonal ' 540
                clsForecast_Methods.ExponentialSmoothing_Simple(dDataDeseason, iHorizonDezero, 0.8, "L", dFData_Deseason, sErrorMessage)

            'Simple Trend Exponential Smoothing
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_A2_NonSeasonal ' 551
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_A2_Seasonal ' 552
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_A4_NonSeasonal ' 553
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_A4_Seasonal ' 554
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_A5_NonSeasonal ' 555
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_A5_Seasonal ' 556
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_A6_NonSeasonal ' 557
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_A6_Seasonal ' 558
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_A8_NonSeasonal ' 559
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_A8_Seasonal ' 560
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_M2_NonSeasonal ' 561
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_M2_Seasonal ' 562
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_M4_NonSeasonal ' 563
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_M4_Seasonal ' 564
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_M5_NonSeasonal ' 565
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_M5_Seasonal ' 566
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_M6_NonSeasonal ' 567
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_M6_Seasonal ' 568
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_M8_NonSeasonal ' 569
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_M8_Seasonal ' 570
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_F2_NonSeasonal ' 571
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_F2_Seasonal ' 572
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_F4_NonSeasonal ' 573
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_F4_Seasonal ' 574
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_F5_NonSeasonal ' 575
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_F5_Seasonal ' 576
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_F6_NonSeasonal ' 577
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_F6_Seasonal ' 578
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_F8_NonSeasonal ' 579
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_F8_Seasonal ' 580
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_L2_NonSeasonal ' 581
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_L2_Seasonal ' 582
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_L4_NonSeasonal ' 583
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_L4_Seasonal ' 584
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_L5_NonSeasonal ' 585
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_L5_Seasonal ' 586
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_L6_NonSeasonal ' 587
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_L6_Seasonal ' 588
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_L8_NonSeasonal ' 589
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_SimpleTrend_L8_Seasonal ' 590
                clsForecast_Methods.ExponentialSmoothing_Simple_Trend(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, "L", dFData_Deseason, sErrorMessage)

            'Holt Exponential Smoothing
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_A2_NonSeasonal ' 601
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_A2_Seasonal ' 602
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_A4_NonSeasonal ' 603
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_A4_Seasonal ' 604
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_A5_NonSeasonal ' 605
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_A5_Seasonal ' 606
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_A6_NonSeasonal ' 607
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_A6_Seasonal ' 608
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_A8_NonSeasonal ' 609
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_A8_Seasonal ' 610
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_M2_NonSeasonal ' 611
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_M2_Seasonal ' 612
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_M4_NonSeasonal ' 613
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_M4_Seasonal ' 614
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_M5_NonSeasonal ' 615
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_M5_Seasonal ' 616
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_M6_NonSeasonal ' 617
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_M6_Seasonal ' 618
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_M8_NonSeasonal ' 619
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_M8_Seasonal ' 620
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_F2_NonSeasonal ' 621
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_F2_Seasonal ' 622
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_F4_NonSeasonal ' 623
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_F4_Seasonal ' 624
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_F5_NonSeasonal ' 625
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_F5_Seasonal ' 626
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_F6_NonSeasonal ' 627
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_F6_Seasonal ' 628
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_F8_NonSeasonal ' 629
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_F8_Seasonal ' 630
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_L2_NonSeasonal ' 631
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_L2_Seasonal ' 632
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_L4_NonSeasonal ' 633
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_L4_Seasonal ' 634
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_L5_NonSeasonal ' 635
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_L5_Seasonal ' 636
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_L6_NonSeasonal ' 637
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_L6_Seasonal ' 638
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_L8_NonSeasonal ' 639
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Holt_L8_Seasonal ' 640
                clsForecast_Methods.ExponentialSmoothing_Holt(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, "L", dFData_Deseason, sErrorMessage)

            'Damped Exponential Smoothing
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_A2_NonSeasonal ' 651
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_A2_Seasonal ' 652
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_A4_NonSeasonal ' 653
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_A4_Seasonal ' 654
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_A5_NonSeasonal ' 655
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_A5_Seasonal ' 656
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_A6_NonSeasonal ' 657
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_A6_Seasonal ' 658
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_A8_NonSeasonal ' 659
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_A8_Seasonal ' 660
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_M2_NonSeasonal ' 661
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_M2_Seasonal ' 662
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_M4_NonSeasonal ' 663
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_M4_Seasonal ' 664
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_M5_NonSeasonal ' 665
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_M5_Seasonal ' 666
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_M6_NonSeasonal ' 667
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_M6_Seasonal ' 668
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_M8_NonSeasonal ' 669
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_M8_Seasonal ' 670
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_F2_NonSeasonal ' 671
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_F2_Seasonal ' 672
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_F4_NonSeasonal ' 673
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_F4_Seasonal ' 674
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_F5_NonSeasonal ' 675
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_F5_Seasonal ' 676
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_F6_NonSeasonal ' 677
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_F6_Seasonal ' 678
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_F8_NonSeasonal ' 679
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_F8_Seasonal ' 680
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_L2_NonSeasonal ' 681
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, 0.8, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_L2_Seasonal ' 682
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.2, 0.1, 0.8, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_L4_NonSeasonal ' 683
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, 0.8, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_L4_Seasonal ' 684
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.4, 0.13, 0.8, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_L5_NonSeasonal ' 685
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, 0.8, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_L5_Seasonal ' 686
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.15, 0.8, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_L6_NonSeasonal ' 687
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, 0.8, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_L6_Seasonal ' 688
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.6, 0.17, 0.8, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_L8_NonSeasonal ' 689
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, 0.8, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_ExponentialSmoothing_Damped_L8_Seasonal ' 690
                clsForecast_Methods.ExponentialSmoothing_Damped(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.8, 0.2, 0.8, "L", dFData_Deseason, sErrorMessage)

            'ARIMA Group (NOT WORKING CURRENTLY)
            Case enmForecastMethod.SFM_Arima_001_NonSeasonal '701
                clsForecast_Methods.ARIMA(dDataDeseason, dFData_Deseason, iHorizonDezero, 0, 0, 1)
            Case enmForecastMethod.SFM_Arima_001_Seasonal '702
                clsForecast_Methods.ARIMA(dDataDeseason, dFData_Deseason, iHorizonDezero, 0, 0, 1)
            Case enmForecastMethod.SFM_Arima_100_NonSeasonal '703
                clsForecast_Methods.ARIMA(dDataDeseason, dFData_Deseason, iHorizonDezero, 1, 0, 0)
            Case enmForecastMethod.SFM_Arima_100_Seasonal '704
                clsForecast_Methods.ARIMA(dDataDeseason, dFData_Deseason, iHorizonDezero, 1, 0, 0)
            Case enmForecastMethod.SFM_Arima_010_NonSeasonal '705
                clsForecast_Methods.ARIMA(dDataDeseason, dFData_Deseason, iHorizonDezero, 0, 1, 0)
            Case enmForecastMethod.SFM_Arima_010_Seasonal '706
                clsForecast_Methods.ARIMA(dDataDeseason, dFData_Deseason, iHorizonDezero, 0, 1, 0)
            Case enmForecastMethod.SFM_Arima_011_NonSeasonal '707
                clsForecast_Methods.ARIMA(dDataDeseason, dFData_Deseason, iHorizonDezero, 0, 1, 1)
            Case enmForecastMethod.SFM_Arima_011_Seasonal '708
                clsForecast_Methods.ARIMA(dDataDeseason, dFData_Deseason, iHorizonDezero, 0, 1, 1)
            Case enmForecastMethod.SFM_Arima_110_NonSeasonal '709
                clsForecast_Methods.ARIMA(dDataDeseason, dFData_Deseason, iHorizonDezero, 1, 1, 0)
            Case enmForecastMethod.SFM_Arima_110_Seasonal '710
                clsForecast_Methods.ARIMA(dDataDeseason, dFData_Deseason, iHorizonDezero, 1, 1, 0)
            Case enmForecastMethod.SFM_Arima_111_NonSeasonal '711
                clsForecast_Methods.ARIMA(dDataDeseason, dFData_Deseason, iHorizonDezero, 1, 1, 1)
            Case enmForecastMethod.SFM_Arima_111_Seasonal '712
                clsForecast_Methods.ARIMA(dDataDeseason, dFData_Deseason, iHorizonDezero, 1, 1, 1)

            'THETA Group with 2.00
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_A2_NonSeasonal ' 801
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.2, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_A2_Seasonal ' 802
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.2, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_A4_NonSeasonal ' 803
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.4, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_A4_Seasonal ' 804
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.4, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_A5_NonSeasonal ' 805
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.5, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_A5_Seasonal ' 806
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.5, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_A6_NonSeasonal ' 807
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.6, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_A6_Seasonal ' 808
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.6, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_A8_NonSeasonal ' 809
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_A8_Seasonal ' 810
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_M2_NonSeasonal ' 811
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.2, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_M2_Seasonal ' 812
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.2, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_M4_NonSeasonal ' 813
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.4, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_M4_Seasonal ' 814
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.4, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_M5_NonSeasonal ' 815
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.5, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_M5_Seasonal ' 816
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.5, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_M6_NonSeasonal ' 817
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.6, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_M6_Seasonal ' 818
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.6, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_M8_NonSeasonal ' 819
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_M8_Seasonal ' 820
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_F2_NonSeasonal ' 821
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.2, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_F2_Seasonal ' 822
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.2, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_F4_NonSeasonal ' 823
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.4, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_F4_Seasonal ' 824
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.4, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_F5_NonSeasonal ' 825
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.5, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_F5_Seasonal ' 826
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.5, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_F6_NonSeasonal ' 827
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.6, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_F6_Seasonal ' 828
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.6, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_F8_NonSeasonal ' 829
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_F8_Seasonal ' 830
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_L2_NonSeasonal ' 831
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.2, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_L2_Seasonal ' 832
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.2, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_L4_NonSeasonal ' 833
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.4, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_L4_Seasonal ' 834
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.4, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_L5_NonSeasonal ' 835
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.5, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_L5_Seasonal ' 836
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.5, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_L6_NonSeasonal ' 837
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.6, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_L6_Seasonal ' 838
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.6, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_L8_NonSeasonal ' 839
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.8, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_200_ExponentialSmoothing_Simple_L8_Seasonal ' 840
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 2.0, 0.8, "L", dFData_Deseason, sErrorMessage)

            'THETA Group with 1.50
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_A2_NonSeasonal ' 851
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.2, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_A2_Seasonal ' 852
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.2, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_A4_NonSeasonal ' 853
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.4, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_A4_Seasonal ' 854
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.4, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_A5_NonSeasonal ' 855
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.5, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_A5_Seasonal ' 856
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.5, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_A6_NonSeasonal ' 857
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.6, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_A6_Seasonal ' 858
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.6, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_A8_NonSeasonal ' 859
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_A8_Seasonal ' 860
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_M2_NonSeasonal ' 861
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.2, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_M2_Seasonal ' 862
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.2, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_M4_NonSeasonal ' 863
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.4, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_M4_Seasonal ' 864
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.4, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_M5_NonSeasonal ' 865
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.5, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_M5_Seasonal ' 866
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.5, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_M6_NonSeasonal ' 867
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.6, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_M6_Seasonal ' 868
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.6, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_M8_NonSeasonal ' 869
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_M8_Seasonal ' 870
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_F2_NonSeasonal ' 871
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.2, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_F2_Seasonal ' 872
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.2, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_F4_NonSeasonal ' 873
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.4, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_F4_Seasonal ' 874
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.4, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_F5_NonSeasonal ' 875
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.5, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_F5_Seasonal ' 876
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.5, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_F6_NonSeasonal ' 877
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.6, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_F6_Seasonal ' 878
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.6, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_F8_NonSeasonal ' 879
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_F8_Seasonal ' 880
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_L2_NonSeasonal ' 881
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.2, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_L2_Seasonal ' 882
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.2, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_L4_NonSeasonal ' 883
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.4, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_L4_Seasonal ' 884
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.4, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_L5_NonSeasonal ' 885
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.5, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_L5_Seasonal ' 886
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.5, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_L6_NonSeasonal ' 887
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.6, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_L6_Seasonal ' 888
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.6, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_L8_NonSeasonal ' 889
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.8, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_150_ExponentialSmoothing_Simple_L8_Seasonal ' 890
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 1.5, 0.8, "L", dFData_Deseason, sErrorMessage)

            'THETA Group with 0.75
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_A2_NonSeasonal ' 901
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.2, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_A2_Seasonal ' 902
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.2, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_A4_NonSeasonal ' 903
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.4, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_A4_Seasonal ' 904
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.4, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_A5_NonSeasonal ' 905
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.5, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_A5_Seasonal ' 906
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.5, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_A6_NonSeasonal ' 907
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.6, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_A6_Seasonal ' 908
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.6, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_A8_NonSeasonal ' 909
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_A8_Seasonal ' 910
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_M2_NonSeasonal ' 911
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.2, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_M2_Seasonal ' 912
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.2, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_M4_NonSeasonal ' 913
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.4, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_M4_Seasonal ' 914
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.4, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_M5_NonSeasonal ' 915
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.5, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_M5_Seasonal ' 916
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.5, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_M6_NonSeasonal ' 917
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.6, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_M6_Seasonal ' 918
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.6, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_M8_NonSeasonal ' 919
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_M8_Seasonal ' 920
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_F2_NonSeasonal ' 921
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.2, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_F2_Seasonal ' 922
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.2, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_F4_NonSeasonal ' 923
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.4, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_F4_Seasonal ' 924
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.4, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_F5_NonSeasonal ' 925
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.5, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_F5_Seasonal ' 926
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.5, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_F6_NonSeasonal ' 927
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.6, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_F6_Seasonal ' 928
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.6, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_F8_NonSeasonal ' 929
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_F8_Seasonal ' 930
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_L2_NonSeasonal ' 931
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.2, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_L2_Seasonal ' 932
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.2, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_L4_NonSeasonal ' 933
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.4, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_L4_Seasonal ' 934
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.4, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_L5_NonSeasonal ' 935
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.5, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_L5_Seasonal ' 936
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.5, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_L6_NonSeasonal ' 937
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.6, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_L6_Seasonal ' 938
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.6, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_L8_NonSeasonal ' 939
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.8, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_075_ExponentialSmoothing_Simple_L8_Seasonal ' 940
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.75, 0.8, "L", dFData_Deseason, sErrorMessage)

            'THETA Group with 0.50
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_A2_NonSeasonal ' 951
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.2, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_A2_Seasonal ' 952
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.2, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_A4_NonSeasonal ' 953
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.4, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_A4_Seasonal ' 954
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.4, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_A5_NonSeasonal ' 955
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.5, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_A5_Seasonal ' 956
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.5, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_A6_NonSeasonal ' 957
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.6, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_A6_Seasonal ' 958
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.6, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_A8_NonSeasonal ' 959
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_A8_Seasonal ' 960
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.8, "A", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_M2_NonSeasonal ' 961
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.2, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_M2_Seasonal ' 962
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.2, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_M4_NonSeasonal ' 963
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.4, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_M4_Seasonal ' 964
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.4, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_M5_NonSeasonal ' 965
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.5, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_M5_Seasonal ' 966
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.5, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_M6_NonSeasonal ' 967
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.6, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_M6_Seasonal ' 968
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.6, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_M8_NonSeasonal ' 969
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_M8_Seasonal ' 970
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.8, "M", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_F2_NonSeasonal ' 971
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.2, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_F2_Seasonal ' 972
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.2, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_F4_NonSeasonal ' 973
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.4, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_F4_Seasonal ' 974
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.4, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_F5_NonSeasonal ' 975
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.5, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_F5_Seasonal ' 976
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.5, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_F6_NonSeasonal ' 977
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.6, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_F6_Seasonal ' 978
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.6, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_F8_NonSeasonal ' 979
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_F8_Seasonal ' 980
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.8, "F", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_L2_NonSeasonal ' 981
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.2, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_L2_Seasonal ' 982
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.2, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_L4_NonSeasonal ' 983
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.4, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_L4_Seasonal ' 984
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.4, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_L5_NonSeasonal ' 985
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.5, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_L5_Seasonal ' 986
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.5, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_L6_NonSeasonal ' 987
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.6, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_L6_Seasonal ' 988
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.6, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_L8_NonSeasonal ' 989
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.8, "L", dFData_Deseason, sErrorMessage)
            Case enmForecastMethod.SFM_Theta_050_ExponentialSmoothing_Simple_L8_Seasonal ' 990
                clsForecast_Methods.THETA(dDataDeseason, dTimeDeseason, iHorizonDezero, 0.5, 0.8, "L", dFData_Deseason, sErrorMessage)

        End Select

        'Προβλέψεις με εποχιακότητα αλλά χωρίς τα μηδενικά
        'Προβλέψεις με μηδενικά -τελικές
        k = 0
        For i = 1 To iHorizon
            n = TimeSerie_CalculatePointPeriod(dtFDate(i), iSeasonality)
            If iSeasonalPattern(n) = 1 Then
                k = k + 1
                Select Case iMethod
                    Case 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320
                        dFData_Dezero(k) = dFData_Deseason(k) + dIndexes(n)
                    Case Else
                        dFData_Dezero(k) = dFData_Deseason(k) * dIndexes(n)
                End Select
                dFData(i) = dFData_Dezero(k)
                dForecasts(i) = dFData_Dezero(k)
            Else
                dFData(i) = 0
                dForecasts(i) = 0
            End If
        Next i

    End Function

    '***************************************************************************************************************************************************************************
    Public Shared Function Forecast_SQ_LevelUp(ByVal iMethod As Integer,
                                                                                                ByRef dData() As Double,
                                                                                                ByRef dtDate() As Date,
                                                                                                ByRef dTime() As Double,
                                                                                                ByVal iSeasonality As Integer,
                                                                                                ByRef iSeasonalPattern() As Integer,
                                                                                                ByVal iHorizon As Integer,
                                                                                                ByRef dForecasts() As Double) As Boolean

        If iSeasonality = 4 Then
            'Quarterly --> Yearly
            Forecast_SQ_LevelUp_Quarterly(iMethod, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecasts)
        ElseIf iSeasonality = 12 Then
            'Monthly --> Yearly
            Forecast_SQ_LevelUp_Quarterly(iMethod, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecasts)
            'Forecast_SQ_LevelUp_Monthly(iMethod, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecasts)
        ElseIf iSeasonality = 52 Then
            'Weekly --> Yearly
            Forecast_SQ_LevelUp_Weekly(iMethod, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecasts)
        ElseIf iSeasonality = 7 Then
            'Daily --> Monthly 
            Forecast_SQ_LevelUp_Daily(iMethod, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecasts)
        ElseIf iSeasonality = 24 Then
            'Hourly --> Daily
            Forecast_SQ_LevelUp_Hourly(iMethod, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecasts)
        End If

        Forecast_SQ_LevelUp = True

    End Function

    Public Shared Function Forecast_SQ_LevelUp_Quarterly(ByVal iMethod As Integer,
                                                                                                ByRef dData() As Double,
                                                                                                ByRef dtDate() As Date,
                                                                                                ByRef dTime() As Double,
                                                                                                ByVal iSeasonality As Integer,
                                                                                                ByRef iSeasonalPattern() As Integer,
                                                                                                ByVal iHorizon As Integer,
                                                                                                ByRef dForecasts() As Double) As Boolean
        'TimeSerie dims
        Dim dDataDeseason() As Double
        Dim dIndexes() As Double
        Dim iPointPeriod As Integer
        Dim N As Integer
        Dim N_Drop As Integer
        Dim Z As Integer

        'Yearly timeserie dims
        Dim dDataYEAR() As Double
        Dim dTimeYEAR() As Double
        Dim dtDateYEAR() As Date
        Dim dForecastsYEAR() As Double
        Dim iSeasonalityYEAR As Integer
        Dim iHorizonYEAR As Integer
        Dim iSeasonalPatternYEAR() As Integer

        Dim sErrorMessage As String = String.Empty
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer

        Try
            'initialize
            'iFirstPointPeriod = TimeSerie_CalculatePointPeriod(dtDate(1), iSeasonality)
            N = UBound(dData)

            'Υπολόγισε εποχιακους δεικτες
            ReDim dIndexes(iSeasonality)
            ReDim dDataDeseason(N)
            Timeserie_Deseasonalize(dData, dTime, dtDate, iSeasonality, iMethod, dDataDeseason, dIndexes)

            'Make the Aggregation
            iSeasonalityYEAR = 1
            iHorizonYEAR = iHorizon / iSeasonality
            ReDim iSeasonalPatternYEAR(1)
            iSeasonalPatternYEAR(1) = 1
            Z = (N \ iSeasonality)
            N_Drop = N - (Z * iSeasonality)

            ReDim dDataYEAR(Z)
            ReDim dTimeYEAR(Z)
            ReDim dtDateYEAR(Z)

            For j = 1 To Z
                dTimeYEAR(j) = j
                dtDateYEAR(j) = DateSerial(1910, 1, 1).AddYears(j - 1)
            Next

            For i = N_Drop + 1 To N
                j = i \ iSeasonality
                If j > 0 Then
                    dDataYEAR(j) = dDataYEAR(j) + dData(i)
                End If
            Next i

            'Forecasts Tables
            ReDim dForecastsYEAR(iHorizonYEAR)
            ReDim dForecasts(iHorizon)

            'Προβλέψεις χωρίς εποχιακότητα για τπ LevelUp
            clsForecast.Forecast(iMethod, dDataYEAR, dtDateYEAR, dTimeYEAR, iSeasonalityYEAR, iSeasonalPatternYEAR, iHorizonYEAR, dForecastsYEAR)


            'Προβλέψεις με εποχιακότητα αλλά χωρίς τα μηδενικά
            'Προβλέψεις με μηδενικά -τελικές
            k = 0
            For i = 1 To iHorizon
                iPointPeriod = TimeSerie_CalculatePointPeriod(dtDate(N).AddMonths(3 * i), iSeasonality)
                If iSeasonalPattern(iPointPeriod) = 1 Then
                    k = k + 1
                    j = 1 + ((k - 1) \ iSeasonality)
                    Select Case iMethod
                        Case 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320
                            dForecasts(k) = (dForecastsYEAR(j) / iSeasonality) + dIndexes(iPointPeriod)
                        Case Else
                            dForecasts(k) = (dForecastsYEAR(j) / iSeasonality) * dIndexes(iPointPeriod)
                    End Select
                Else
                    dForecasts(k) = 0
                End If

            Next i
            'ok
            Forecast_SQ_LevelUp_Quarterly = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            Forecast_SQ_LevelUp_Quarterly = False

        End Try

    End Function

    Public Shared Function Forecast_SQ_LevelUp_Monthly(ByVal iMethod As Integer,
                                                                                                ByRef dData() As Double,
                                                                                                ByRef dtDate() As Date,
                                                                                                ByRef dTime() As Double,
                                                                                                ByVal iSeasonality As Integer,
                                                                                                ByRef iSeasonalPattern() As Integer,
                                                                                                ByVal iHorizon As Integer,
                                                                                                ByRef dForecasts() As Double) As Boolean
        'TimeSerie dims
        Dim dDataDeseason() As Double
        Dim dIndexes() As Double
        Dim iPointPeriod As Integer
        Dim N As Integer
        Dim N_Drop As Integer
        Dim Z As Integer

        'Yearly timeserie dims
        Dim dDataYEAR() As Double
        Dim dTimeYEAR() As Double
        Dim dtDateYEAR() As Date
        Dim dForecastsYEAR() As Double
        Dim iSeasonalityYEAR As Integer
        Dim iHorizonYEAR As Integer
        Dim iSeasonalPatternYEAR() As Integer

        Dim sErrorMessage As String = String.Empty
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer

        Try
            'initialize
            'iFirstPointPeriod = TimeSerie_CalculatePointPeriod(dtDate(1), iSeasonality)
            N = UBound(dData)

            'Υπολόγισε εποχιακους δεικτες
            ReDim dIndexes(iSeasonality)
            ReDim dDataDeseason(N)
            Timeserie_Deseasonalize(dData, dTime, dtDate, iSeasonality, iMethod, dDataDeseason, dIndexes)

            'Make the Aggregation
            iSeasonalityYEAR = 1
            iHorizonYEAR = 2 'iHorizon / iSeasonality
            ReDim iSeasonalPatternYEAR(1)
            iSeasonalPatternYEAR(1) = 1
            Z = (N \ iSeasonality)
            N_Drop = N - (Z * iSeasonality)

            ReDim dDataYEAR(Z)
            ReDim dTimeYEAR(Z)
            ReDim dtDateYEAR(Z)

            For j = 1 To Z
                dTimeYEAR(j) = j
                dtDateYEAR(j) = DateSerial(1910, 1, 1).AddYears(j - 1)
            Next

            For i = N_Drop + 1 To N
                j = i \ iSeasonality
                If j > 0 Then
                    dDataYEAR(j) = dDataYEAR(j) + dData(i)
                End If
            Next i

            'Forecasts Tables
            ReDim dForecastsYEAR(iHorizonYEAR)
            ReDim dForecasts(iHorizon)

            'Προβλέψεις χωρίς εποχιακότητα για τπ LevelUp
            clsForecast.Forecast(iMethod, dDataYEAR, dtDateYEAR, dTimeYEAR, iSeasonalityYEAR, iSeasonalPatternYEAR, iHorizonYEAR, dForecastsYEAR)


            'Προβλέψεις με εποχιακότητα αλλά χωρίς τα μηδενικά
            'Προβλέψεις με μηδενικά -τελικές
            k = 0
            For i = 1 To iHorizon
                iPointPeriod = TimeSerie_CalculatePointPeriod(dtDate(N).AddMonths(i), iSeasonality)
                If iSeasonalPattern(iPointPeriod) = 1 Then
                    k = k + 1
                    j = 1 + ((k - 1) \ iSeasonality)
                    Select Case iMethod
                        Case 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320
                            dForecasts(k) = (dForecastsYEAR(j) / iSeasonality) + dIndexes(iPointPeriod)
                        Case Else
                            dForecasts(k) = (dForecastsYEAR(j) / iSeasonality) * dIndexes(iPointPeriod)
                    End Select
                Else
                    dForecasts(k) = 0
                End If

            Next i
            'ok
            Forecast_SQ_LevelUp_Monthly = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            Forecast_SQ_LevelUp_Monthly = False

        End Try

    End Function

    Public Shared Function Forecast_SQ_LevelUp_Weekly(ByVal iMethod As Integer,
                                                                                                ByRef dData() As Double,
                                                                                                ByRef dtDate() As Date,
                                                                                                ByRef dTime() As Double,
                                                                                                ByVal iSeasonality As Integer,
                                                                                                ByRef iSeasonalPattern() As Integer,
                                                                                                ByVal iHorizon As Integer,
                                                                                                ByRef dForecasts() As Double) As Boolean
        'TimeSerie dims
        Dim dDataDeseason() As Double
        Dim dIndexes() As Double
        Dim iPointPeriod As Integer
        Dim N As Integer
        Dim N_Drop As Integer
        Dim Z As Integer

        'Yearly timeserie dims
        Dim dDataYEAR() As Double
        Dim dTimeYEAR() As Double
        Dim dtDateYEAR() As Date
        Dim dForecastsYEAR() As Double
        Dim iSeasonalityYEAR As Integer
        Dim iHorizonYEAR As Integer
        Dim iSeasonalPatternYEAR() As Integer

        Dim sErrorMessage As String = String.Empty
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer

        Try
            'initialize
            'iFirstPointPeriod = TimeSerie_CalculatePointPeriod(dtDate(1), iSeasonality)
            N = UBound(dData)

            'Υπολόγισε εποχιακους δεικτες
            ReDim dIndexes(iSeasonality)
            ReDim dDataDeseason(N)
            Timeserie_Deseasonalize(dData, dTime, dtDate, iSeasonality, iMethod, dDataDeseason, dIndexes)

            'Make the Aggregation
            iSeasonalityYEAR = 1
            iHorizonYEAR = 1 'iHorizon / iSeasonality **************************************************************************************************
            ReDim iSeasonalPatternYEAR(1)
            iSeasonalPatternYEAR(1) = 1
            Z = (N \ iSeasonality)
            N_Drop = N - (Z * iSeasonality)

            ReDim dDataYEAR(Z)
            ReDim dTimeYEAR(Z)
            ReDim dtDateYEAR(Z)

            For j = 1 To Z
                dTimeYEAR(j) = j
                dtDateYEAR(j) = DateSerial(1910, 1, 1).AddYears(j - 1)
            Next

            For i = N_Drop + 1 To N
                j = i \ iSeasonality
                If j > 0 Then
                    dDataYEAR(j) = dDataYEAR(j) + dData(i)
                End If
            Next i

            'Forecasts Tables
            ReDim dForecastsYEAR(iHorizonYEAR)
            ReDim dForecasts(iHorizon)

            'Προβλέψεις χωρίς εποχιακότητα για τπ LevelUp
            clsForecast.Forecast(iMethod, dDataYEAR, dtDateYEAR, dTimeYEAR, iSeasonalityYEAR, iSeasonalPatternYEAR, iHorizonYEAR, dForecastsYEAR)


            'Προβλέψεις με εποχιακότητα αλλά χωρίς τα μηδενικά
            'Προβλέψεις με μηδενικά -τελικές
            k = 0
            For i = 1 To iHorizon
                iPointPeriod = TimeSerie_CalculatePointPeriod(dtDate(N).AddDays(7 * i), iSeasonality)
                If iPointPeriod = 53 Then iPointPeriod = 52
                If iSeasonalPattern(iPointPeriod) = 1 Then
                    k = k + 1
                    j = 1 + ((k - 1) \ iSeasonality)
                    Select Case iMethod
                        Case 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320
                            dForecasts(k) = (dForecastsYEAR(j) / iSeasonality) + dIndexes(iPointPeriod)
                        Case Else
                            dForecasts(k) = (dForecastsYEAR(j) / iSeasonality) * dIndexes(iPointPeriod)
                    End Select
                Else
                    dForecasts(k) = 0
                End If

            Next i
            'ok
            Forecast_SQ_LevelUp_Weekly = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            Forecast_SQ_LevelUp_Weekly = False

        End Try

    End Function

    Public Shared Function Forecast_SQ_LevelUp_Daily(ByVal iMethod As Integer,
                                                                                                ByRef dData() As Double,
                                                                                                ByRef dtDate() As Date,
                                                                                                ByRef dTime() As Double,
                                                                                                ByVal iSeasonality As Integer,
                                                                                                ByRef iSeasonalPattern() As Integer,
                                                                                                ByVal iHorizon As Integer,
                                                                                                ByRef dForecasts() As Double) As Boolean
        'TimeSerie dims
        Dim dDataDeseason() As Double
        Dim dIndexes() As Double
        Dim iPointPeriod As Integer
        Dim N As Integer
        Dim N_Drop As Integer
        Dim Z As Integer

        'Yearly timeserie dims
        Dim dDataYEAR() As Double
        Dim dTimeYEAR() As Double
        Dim dtDateYEAR() As Date
        Dim dForecastsYEAR() As Double
        Dim iSeasonalityYEAR As Integer
        Dim iHorizonYEAR As Integer
        Dim iSeasonalPatternYEAR() As Integer

        Dim sErrorMessage As String = String.Empty
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer

        Try
            'initialize
            'iFirstPointPeriod = TimeSerie_CalculatePointPeriod(dtDate(1), iSeasonality)
            N = UBound(dData)

            'Υπολόγισε εποχιακους δεικτες
            ReDim dIndexes(iSeasonality)
            ReDim dDataDeseason(N)
            Timeserie_Deseasonalize(dData, dTime, dtDate, iSeasonality, iMethod, dDataDeseason, dIndexes)

            'Make the Aggregation
            iSeasonalityYEAR = 1
            iHorizonYEAR = 2 ' iHorizon / iSeasonality  14/7
            ReDim iSeasonalPatternYEAR(1)
            iSeasonalPatternYEAR(1) = 1
            Z = (N \ iSeasonality)
            N_Drop = N - (Z * iSeasonality)

            ReDim dDataYEAR(Z)
            ReDim dTimeYEAR(Z)
            ReDim dtDateYEAR(Z)

            For j = 1 To Z
                dTimeYEAR(j) = j
                'dtDateYEAR(j) = DateSerial(1910, 1, 1).AddYears(j - 1)
                dtDateYEAR(j) = DateSerial(1910, 1, 1).AddDays(7 * (j - 1))
            Next

            For i = N_Drop + 1 To N
                j = 1 + ((i - N_Drop - 1) \ iSeasonality)
                If j > 0 Then
                    dDataYEAR(j) = dDataYEAR(j) + dData(i)
                End If
            Next i

            'Forecasts Tables
            ReDim dForecastsYEAR(iHorizonYEAR)
            ReDim dForecasts(iHorizon)

            'Προβλέψεις χωρίς εποχιακότητα για τπ LevelUp
            clsForecast.Forecast(iMethod, dDataYEAR, dtDateYEAR, dTimeYEAR, iSeasonalityYEAR, iSeasonalPatternYEAR, iHorizonYEAR, dForecastsYEAR)


            'Προβλέψεις με εποχιακότητα αλλά χωρίς τα μηδενικά
            'Προβλέψεις με μηδενικά -τελικές
            k = 0
            For i = 1 To iHorizon
                iPointPeriod = TimeSerie_CalculatePointPeriod(dtDate(N).AddDays(i), iSeasonality)
                If iSeasonalPattern(iPointPeriod) = 1 Then
                    k = k + 1
                    j = 1 + ((k - 1) \ iSeasonality)
                    Select Case iMethod
                        Case 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320
                            dForecasts(k) = (dForecastsYEAR(j) / iSeasonality) + dIndexes(iPointPeriod)
                        Case Else
                            dForecasts(k) = (dForecastsYEAR(j) / iSeasonality) * dIndexes(iPointPeriod)
                    End Select
                Else
                    dForecasts(k) = 0
                End If

            Next i
            'ok
            Forecast_SQ_LevelUp_Daily = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            Forecast_SQ_LevelUp_Daily = False

        End Try

    End Function

    Public Shared Function Forecast_SQ_LevelUp_Hourly(ByVal iMethod As Integer,
                                                                                                ByRef dData() As Double,
                                                                                                ByRef dtDate() As Date,
                                                                                                ByRef dTime() As Double,
                                                                                                ByVal iSeasonality As Integer,
                                                                                                ByRef iSeasonalPattern() As Integer,
                                                                                                ByVal iHorizon As Integer,
                                                                                                ByRef dForecasts() As Double) As Boolean
        'TimeSerie dims
        Dim dDataDeseason() As Double
        Dim dIndexes() As Double
        Dim iPointPeriod As Integer
        Dim N As Integer
        Dim N_Drop As Integer
        Dim Z As Integer

        'Yearly timeserie dims
        Dim dDataYEAR() As Double
        Dim dTimeYEAR() As Double
        Dim dtDateYEAR() As Date
        Dim dForecastsYEAR() As Double
        Dim iSeasonalityYEAR As Integer
        Dim iHorizonYEAR As Integer
        Dim iSeasonalPatternYEAR() As Integer

        Dim sErrorMessage As String = String.Empty
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer

        Try
            '1st level--> from Hourly to Daily
            'initialize
            N = UBound(dData)

            'Υπολόγισε εποχιακους δεικτες
            ReDim dIndexes(iSeasonality)
            ReDim dDataDeseason(N)
            Timeserie_Deseasonalize(dData, dTime, dtDate, iSeasonality, iMethod, dDataDeseason, dIndexes)

            'Make the Aggregation
            iSeasonalityYEAR = 7 '1
            iHorizonYEAR = 2 ' iHorizon / iSeasonality  48/24
            ReDim iSeasonalPatternYEAR(7) '(1)
            Dim m As Integer
            For m = 1 To 7
                iSeasonalPatternYEAR(m) = 1
            Next m
            Z = (N \ iSeasonality)
            N_Drop = N - (Z * iSeasonality)

            ReDim dDataYEAR(Z)
            ReDim dTimeYEAR(Z)
            ReDim dtDateYEAR(Z)

            For j = 1 To Z
                dTimeYEAR(j) = j
                'dtDateYEAR(j) = DateSerial(1910, 1, 1).AddYears(j - 1)
                'dtDateYEAR(j) = DateSerial(1910, 1, 1).AddDays(7 * (j - 1))
                dtDateYEAR(j) = DateSerial(1910, 1, 1).AddDays(j - 1)
            Next

            For i = N_Drop + 1 To N
                j = 1 + ((i - N_Drop - 1) \ iSeasonality)
                If j > 0 Then
                    dDataYEAR(j) = dDataYEAR(j) + dData(i)
                End If
            Next i

            'Forecasts Tables
            ReDim dForecastsYEAR(iHorizonYEAR)
            ReDim dForecasts(iHorizon)

            'Προβλέψεις χωρίς εποχιακότητα για τπ LevelUp
            clsForecast.Forecast(iMethod, dDataYEAR, dtDateYEAR, dTimeYEAR, iSeasonalityYEAR, iSeasonalPatternYEAR, iHorizonYEAR, dForecastsYEAR)


            'Προβλέψεις με εποχιακότητα αλλά χωρίς τα μηδενικά
            'Προβλέψεις με μηδενικά -τελικές
            k = 0
            For i = 1 To iHorizon
                iPointPeriod = TimeSerie_CalculatePointPeriod(dtDate(N).AddHours(i), iSeasonality)
                If iSeasonalPattern(iPointPeriod) = 1 Then
                    k = k + 1
                    j = 1 + ((k - 1) \ iSeasonality)
                    Select Case iMethod
                        Case 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320
                            dForecasts(k) = (dForecastsYEAR(j) / iSeasonality) + dIndexes(iPointPeriod)
                        Case Else
                            dForecasts(k) = (dForecastsYEAR(j) / iSeasonality) * dIndexes(iPointPeriod)
                    End Select
                Else
                    dForecasts(k) = 0
                End If

            Next i
            'ok
            Forecast_SQ_LevelUp_Hourly = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            Forecast_SQ_LevelUp_Hourly = False

        End Try

    End Function


    Public Shared Function TimeSerie_CalculatePointPeriod(ByVal dDate As Date, _
                                                                                                            ByVal iSeasonality As Integer) As Short
        'Βρες σε ποια περίοδο αντιστοιχεί η τιμή
        Dim lTimeserieFirstPointPeriod As Integer

        TimeSerie_CalculatePointPeriod = 0

        Select Case iSeasonality
            Case 1
                'Ετήσια
                TimeSerie_CalculatePointPeriod = 1
            Case 2
                'Εξαμηνιαία
                Select Case Month(dDate)
                    Case 1, 2, 3, 4, 5, 6
                        TimeSerie_CalculatePointPeriod = 1
                    Case 7, 8, 9, 10, 11, 12
                        TimeSerie_CalculatePointPeriod = 2
                End Select
            Case 3
                'Τετραμηνιαία
                Select Case Month(dDate)
                    Case 1, 2, 3, 4
                        TimeSerie_CalculatePointPeriod = 1
                    Case 5, 6, 7, 8
                        TimeSerie_CalculatePointPeriod = 2
                    Case 9, 10, 11, 12
                        TimeSerie_CalculatePointPeriod = 3
                End Select
            Case 4
                'Τριμηνιαία
                Select Case Month(dDate)
                    Case 1, 2, 3
                        TimeSerie_CalculatePointPeriod = 1
                    Case 4, 5, 6
                        TimeSerie_CalculatePointPeriod = 2
                    Case 7, 8, 9
                        TimeSerie_CalculatePointPeriod = 3
                    Case 10, 11, 12
                        TimeSerie_CalculatePointPeriod = 4
                End Select
            Case 6
                'Διμηνιαία
                Select Case Month(dDate)
                    Case 1, 2
                        TimeSerie_CalculatePointPeriod = 1
                    Case 3, 4
                        TimeSerie_CalculatePointPeriod = 2
                    Case 5, 6
                        TimeSerie_CalculatePointPeriod = 3
                    Case 7, 8
                        TimeSerie_CalculatePointPeriod = 4
                    Case 9, 10
                        TimeSerie_CalculatePointPeriod = 5
                    Case 11, 12
                        TimeSerie_CalculatePointPeriod = 6
                End Select
            Case 12
                'Μηνιαία
                TimeSerie_CalculatePointPeriod = Month(dDate)
            Case 52
                'Εβδομαδιαία
                lTimeserieFirstPointPeriod = Int((dDate.ToOADate - DateSerial(Year(dDate), 1, 1).ToOADate + 1) / 7)
                If System.DateTime.FromOADate(dDate.ToOADate - DateSerial(Year(dDate), 1, 1).ToOADate + 1).ToOADate Mod 7 = 0 Then
                    TimeSerie_CalculatePointPeriod = lTimeserieFirstPointPeriod
                Else
                    TimeSerie_CalculatePointPeriod = lTimeserieFirstPointPeriod + 1
                End If
               ' If TimeSerie_CalculatePointPeriod > 52 Then TimeSerie_CalculatePointPeriod = 52
            Case 365
                'Ημερήσια
                TimeSerie_CalculatePointPeriod = dDate.DayOfYear
            Case 7
                'Ημερήσια to weekly
                TimeSerie_CalculatePointPeriod = dDate.DayOfWeek + 1
            Case 24
                'Hourly
                TimeSerie_CalculatePointPeriod = dDate.Hour + 1
        End Select

    End Function

    Public Shared Function Timeserie_Dezero(ByRef dData() As Double, _
                                                                                  ByRef dtDate() As Date, _
                                                                                  ByRef dTime() As Double, _
                                                                                  ByVal iSeasonality As Integer, _
                                                                                  ByRef iSeasonalPattern() As Integer, _
                                                                                  ByVal iHorizon As Integer, _
                                                                                  ByVal iFirstPointPeriod As Integer, _
                                                                                  ByRef dDataDezero() As Double, _
                                                                                  ByRef dtDateDezero() As Date, _
                                                                                  ByRef dTimeDezero() As Double, _
                                                                                  ByRef iHorizonDezero As Integer, _
                                                                                  ByRef iSeasonalityDezero As Integer) As Boolean
        'Φτιαξε την χρονοσειρά χωρίς τα μηδενικά
        'S0S: Η ΘΕΣΗ ΜΗΔΕΝ ΤΩΝ ΠΙΝΑΚΩΝ ΔΕΝ ΧΡΗΣΙΜΟΠΟΙΕΙΤΑΙ

        Dim i As Integer
        Dim j As Integer
        Dim iCurrentPeriod As Short

        iCurrentPeriod = iFirstPointPeriod - 1
        j = 0
        For i = 1 To UBound(dData)
            iCurrentPeriod = iCurrentPeriod + 1
            If iCurrentPeriod > iSeasonality Then iCurrentPeriod = 1
            If iSeasonalPattern(iCurrentPeriod) = 1 Then
                j = j + 1
                ReDim Preserve dDataDezero(j)
                ReDim Preserve dtDateDezero(j)
                ReDim Preserve dTimeDezero(j)
                dDataDezero(j) = dData(i)
                dtDateDezero(j) = dtDate(i)
                dTimeDezero(j) = j
            End If
        Next i

        'Υπολογισε το iSeasonalityDezero
        iSeasonalityDezero = 0
        'For i = LBound(iSeasonalPattern) To UBound(iSeasonalPattern)
        For i = 1 To UBound(iSeasonalPattern)
            If iSeasonalPattern(i) = 1 Then iSeasonalityDezero = iSeasonalityDezero + 1
        Next i

        'Υπολόγισε το iHorizonDezero
        iHorizonDezero = 0
        For i = 1 To iHorizon
            iCurrentPeriod = iCurrentPeriod + 1
            If iCurrentPeriod > iSeasonality Then iCurrentPeriod = 1
            If iSeasonalPattern(iCurrentPeriod) = 1 Then
                iHorizonDezero = iHorizonDezero + 1
            End If
        Next i

    End Function

    Public Shared Function Timeserie_Deseasonalize(ByRef dData() As Double,
                                                                                                ByRef dTime() As Double,
                                                                                                ByRef dtDate() As Date,
                                                                                                ByVal iSeasonality As Integer,
                                                                                                ByVal iMethod As Integer,
                                                                                                ByRef dDataDeseason() As Double,
                                                                                                ByRef dIndexes() As Double) As Boolean
        'Υπολογισμός της αποεποχικοποιημένης χρονοσειράς
        'SOS--> Οι θέσεις ΜΗΔΕΝ των πινάκων ΔΕΝ ΧΡΗΣΙΜΟΠΟΙΟΥΝΤΑΙ!!!!

        'Dim MinAcceptedNumber As Double
        Dim k, i, n, hs, j As Short
        Dim sum As Double
        Dim t() As Double
        Dim s() As Double
        Dim Means_nums() As Double
        Dim MinYTC() As Double
        Dim MaxYTC() As Double
        Dim Means_YminusT() As Double
        Dim YminusT_Component() As Double

        Dim sPeriod As Short

        'Αρχικοποίηση
        n = UBound(dData)
        ReDim dIndexes(iSeasonality)
        ReDim dDataDeseason(n)

        'Συνέχισε
        ReDim t(n)
        ReDim s(iSeasonality)
        ReDim YminusT_Component(n)
        ReDim Means_YminusT(iSeasonality)
        ReDim MinYTC(iSeasonality)
        ReDim MaxYTC(iSeasonality)
        ReDim Means_nums(iSeasonality)
        hs = iSeasonality / 2

        'T component
        For i = hs + 1 To n - hs
            t(i) = (1 / (2 * iSeasonality)) * dData(i - hs)
            For j = 1 To iSeasonality - 1
                t(i) = t(i) + (1 / iSeasonality) * dData(i - hs + j)
            Next j
            t(i) = t(i) + (1 / (2 * iSeasonality)) * dData(i + hs)
        Next i

        'S component
        'y-t
        For i = hs + 1 To n - hs
            Select Case iMethod
                Case 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320
                    YminusT_Component(i) = dData(i) - t(i)
                Case Else
                    YminusT_Component(i) = dData(i) / t(i)
            End Select
        Next
        'initialisation
        For i = 1 To iSeasonality
            Means_YminusT(i) = 0
            Means_nums(i) = 0
            MinYTC(i) = 1.7 * 10 ^ 308
            MaxYTC(i) = 2.2 * 10 ^ (-308)
        Next i

        For i = hs + 1 To n - hs
            k = i Mod iSeasonality
            If k = 0 Then k = iSeasonality
            Means_nums(k) = Means_nums(k) + 1
            Means_YminusT(k) = Means_YminusT(k) + YminusT_Component(i)
            If YminusT_Component(i) > MaxYTC(k) Then MaxYTC(k) = YminusT_Component(i)
            If YminusT_Component(i) < MinYTC(k) Then MinYTC(k) = YminusT_Component(i)
        Next i

        For i = 1 To iSeasonality
            If Means_nums(i) >= 3 Then
                Means_YminusT(i) = Means_YminusT(i) - MaxYTC(i) - MinYTC(i)
                Means_YminusT(i) = Means_YminusT(i) / (Means_nums(i) - 2)
            Else
                Means_YminusT(i) = Means_YminusT(i) / Means_nums(i)
            End If
        Next i

        sum = 0
        For i = 1 To iSeasonality
            sum = sum + Means_YminusT(i)
        Next i

        Dim iCorrectionFactor As Integer
        iCorrectionFactor = 0

        For i = 1 To iSeasonality
            Select Case iMethod
                Case 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320
                    s(i) = Means_YminusT(i) - (sum / iSeasonality)
                Case Else
                    s(i) = Means_YminusT(i) / (sum / iSeasonality)
            End Select
            'If s(i) < MinAcceptedNumber Then MsgBox "Προσοχή! Υπάρχει εποχιακός δείκτης ίσος με μηδέν!"
            sPeriod = TimeSerie_CalculatePointPeriod(dtDate(i), iSeasonality)
            If iSeasonality = 52 And sPeriod = 53 Then
                sPeriod = 0
                iCorrectionFactor = 1
            End If
            If iSeasonality <> 52 Then
                dIndexes(sPeriod) = s(i)
            Else
                dIndexes(sPeriod + iCorrectionFactor) = s(i)
            End If

        Next i

        For i = 1 To n
            'k = i Mod iSeasonality
            sPeriod = TimeSerie_CalculatePointPeriod(dtDate(i), iSeasonality)
            If sPeriod > 52 Then sPeriod = 52
            'If k = 0 Then k = iSeasonality
            Select Case iMethod
                Case 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320
                    dDataDeseason(i) = dData(i) - dIndexes(sPeriod) 's(k)
                Case Else
                    If dIndexes(sPeriod) <> 0 Then
                        dDataDeseason(i) = dData(i) / dIndexes(sPeriod) 's(k)
                    Else
                        dDataDeseason(i) = 0
                    End If
            End Select
        Next i

    End Function

    Public Shared Function TimeSerie_Calculate_NextDate(ByVal dtDate As Date, _
                                                                                                        ByVal iSeasonality As Integer) As Date
        'Υπολόγισε την επόμενη ημερομηνία
        Dim dtNewDate As Date
        Dim lFirstPointPeriod As Integer

        Select Case iSeasonality
            Case 1
                'yearly
                'dtNewDate = DateSerial(Year(dtDate) + 1, Month(dtDate), Day(dtDate))
                dtNewDate = dtDate.AddYears(1)
            Case 2
                'biyearly
                'dtNewDate = DateSerial(Year(dtDate), Month(dtDate) + 6, Microsoft.VisualBasic.DateAndTime.Day(dtDate))
                dtNewDate = dtDate.AddMonths(6)
            Case 3
                'Tetraina
                'dtNewDate = DateSerial(Year(dtDate), Month(dtDate) + 4, Microsoft.VisualBasic.DateAndTime.Day(dtDate))
                dtNewDate = dtDate.AddMonths(4)
            Case 4
                'Quarterly
                'dtNewDate = DateSerial(Year(dtDate), Month(dtDate) + 3, Microsoft.VisualBasic.DateAndTime.Day(dtDate))
                dtNewDate = dtDate.AddMonths(3)
            Case 6
                'bimonthly
                'dtNewDate = DateSerial(Year(dtDate), Month(dtDate) + 2, Microsoft.VisualBasic.DateAndTime.Day(dtDate))
                dtNewDate = dtDate.AddMonths(2)
            Case 12
                'monthly
                'dtNewDate = DateSerial(Year(dtDate), Month(dtDate) + 1, Microsoft.VisualBasic.DateAndTime.Day(dtDate))
                dtNewDate = dtDate.AddMonths(1)
            Case 52
                dtNewDate = DateSerial(Year(dtDate), Month(dtDate), Microsoft.VisualBasic.DateAndTime.Day(dtDate) + 7)
                'Εβδομαδιαία
                lFirstPointPeriod = Int((DateDiff("d", DateSerial(Year(dtNewDate), 1, 1), dtNewDate.Date) + 1) / 7)
                If (DateDiff("d", DateSerial(Year(dtNewDate), 1, 1), dtNewDate.Date) + 1) Mod 7 = 0 Then
                    lFirstPointPeriod = lFirstPointPeriod
                Else
                    lFirstPointPeriod = lFirstPointPeriod + 1
                End If
                'Αν έχεις μπει στην 53η εβδομάδα, τότε προχώρα στην πρώτη
                If lFirstPointPeriod > 52 Then
                    '  dtNewDate = DateSerial(Year(dtNewDate), Month(dtNewDate), Microsoft.VisualBasic.DateAndTime.Day(dtNewDate) + 7)
                End If
            Case 365
                'daily
                dtNewDate = dtDate.AddDays(1)
            Case 7
                'daily, because we aggregate to weekly
                dtNewDate = dtDate.AddDays(1)
            Case 24
                'hourly
                dtNewDate = dtDate.AddHours(1)
        End Select

        TimeSerie_Calculate_NextDate = dtNewDate

    End Function

    Public Shared Function TimeSerie_Calculate_PreviousDate(ByVal dtDate As Date, _
                                                                                                                ByVal iSeasonality As Integer) As Date
        Dim dtNewDate As Date
        Dim iFirstPointPeriod As Integer

        Select Case iSeasonality
            Case 1
                'dtNewDate = DateSerial(Year(dtDate) - 1, Month(dtDate), Microsoft.VisualBasic.DateAndTime.Day(dtDate))
                dtNewDate = dtDate.AddYears(-1)
            Case 2
                'dtNewDate = DateSerial(Year(dtDate), Month(dtDate) - 6, Microsoft.VisualBasic.DateAndTime.Day(dtDate))
                dtNewDate = dtDate.AddMonths(-6)
            Case 3
                'dtNewDate = DateSerial(Year(dtDate), Month(dtDate) - 4, Microsoft.VisualBasic.DateAndTime.Day(dtDate))
                dtNewDate = dtDate.AddMonths(-4)
            Case 4
                'dtNewDate = DateSerial(Year(dtDate), Month(dtDate) - 3, Microsoft.VisualBasic.DateAndTime.Day(dtDate))
                dtNewDate = dtDate.AddMonths(-3)
            Case 6
                'dtNewDate = DateSerial(Year(dtDate), Month(dtDate) - 2, Microsoft.VisualBasic.DateAndTime.Day(dtDate))
                dtNewDate = dtDate.AddMonths(-2)
            Case 12
                'dtNewDate = DateSerial(Year(dtDate), Month(dtDate) - 1, Microsoft.VisualBasic.DateAndTime.Day(dtDate))
                dtNewDate = dtDate.AddMonths(-1)
            Case 52
                dtNewDate = DateSerial(Year(dtDate), Month(dtDate), Microsoft.VisualBasic.DateAndTime.Day(dtDate) - 7)
                'Εβδομαδιαία
                iFirstPointPeriod = Int((dtNewDate.ToOADate - DateSerial(Year(dtNewDate), 1, 1).ToOADate + 1) / 7)
                If System.DateTime.FromOADate(dtNewDate.ToOADate - DateSerial(Year(dtNewDate), 1, 1).ToOADate + 1).ToOADate Mod 7 = 0 Then
                    iFirstPointPeriod = iFirstPointPeriod
                Else
                    iFirstPointPeriod = iFirstPointPeriod + 1
                End If
                'Αν έχεις μπει στην 53η εβδομάδα, τότε προχώρα στην προηγούμενη
                If iFirstPointPeriod > 52 Then
                    dtNewDate = DateSerial(Year(dtNewDate), Month(dtNewDate), Microsoft.VisualBasic.DateAndTime.Day(dtNewDate) - 7)
                End If
            Case 365
                'daily
                dtNewDate = dtDate.AddDays(-1)
            Case 7
                'daily, because we aggregate to weekly
                dtNewDate = dtDate.AddDays(-1)
            Case 24
                'hourly,
                dtNewDate = dtDate.AddHours(-1)

        End Select

        TimeSerie_Calculate_PreviousDate = dtNewDate

    End Function

    Public Shared Function ForecastsEdit_AddPercentage(ByRef dForecasts() As Double, ByVal dPercentage As Double) As Boolean
        'Τροποποίηση προβλέψεων με % αλλαγή (from -50 to +50)
        Dim i As Short

        'Εφάρμοσε το ποσοστό
        For i = LBound(dForecasts) To UBound(dForecasts)
            dForecasts(i) = dForecasts(i) * ((100 + dPercentage) / 100)
        Next i

    End Function

    Public Shared Function ForecastsEdit_SetTarget(ByRef dForecasts() As Double, ByVal dNewTarget As Double) As Boolean
        ' Τροποποίηση προβλέψεων με στόχο
        Dim i As Integer
        Dim dStoxos As Double
        Dim iStoxosCount As Integer

        'Υπολόγισε τον τρέχοντα στόχο
        dStoxos = 0
        iStoxosCount = UBound(dForecasts)
        For i = 1 To UBound(dForecasts)
            dStoxos = dStoxos + dForecasts(i)
        Next i

        'Εφάρμοσε το στόχο
        For i = 1 To UBound(dForecasts)
            dForecasts(i) = dForecasts(i) * (dNewTarget / dStoxos)
        Next i

    End Function

    Public Shared Function TimeSerie_CalculateSafetyStock(ByRef a() As Double, _
                                                                                                        ByRef dSafetyStock As Double, _
                                                                                                        ByRef dReorderPoint As Double, _
                                                                                                        ByVal iLeadTime As Integer, _
                                                                                                        ByVal iServiceLevel As Integer) As Boolean
        'Υπολογισμός Αποθέματος Ασφαλείας και Reorder point
        'SOS: Η ΘΕΣΗ ΜΗΔΕΝ ΤΩΝ ΠΙΝΑΚΩΝ ΔΕΝ ΧΡΗΣΙΜΟΠΟΙΕΙΤΑΙ!!!

        Dim zvalue As Double
        Dim sdev As Double
        Dim bb() As Double
        Dim i As Short
        Dim smean As Double

        'Ελεγχος για ικανοποιητικό πλήθος προβλέψεων
        If UBound(a) < iLeadTime Or iLeadTime = 0 Then
            dSafetyStock = 0
            dReorderPoint = 0
            Exit Function
        End If

        'Υπολογισμός στοιχείων
        If iServiceLevel = 70 Then zvalue = 0.53
        If iServiceLevel = 80 Then zvalue = 0.85
        If iServiceLevel = 90 Then zvalue = 1.28
        If iServiceLevel = 95 Then zvalue = 1.65

        ReDim bb(iLeadTime)
        For i = 1 To iLeadTime
            bb(i) = a(i)
        Next i
        sdev = clsCommonMath.Diakimansi(bb)
        smean = clsCommonMath.MeanOfArray(bb)

        'Τελικός υπολογισμός
        dSafetyStock = zvalue * sdev * System.Math.Sqrt(iLeadTime)
        dReorderPoint = (smean * iLeadTime) + dSafetyStock

    End Function

    Public Shared Function ForecastAverageTwo(ByVal iMethodA As Integer, ByVal iMethodB As Integer,
                                                            ByVal bMethodA_SQ_LU As Integer, ByVal bMethodB_SQ_LU As Integer,
                                                            ByVal iWeightA As Integer, ByVal iWeightB As Integer,
                                                            ByRef dData() As Double,
                                                            ByRef dtDate() As Date,
                                                            ByRef dTime() As Double,
                                                            ByVal iSeasonality As Integer,
                                                            ByVal iSeasonalityForCalcNextDate As Integer,
                                                            ByRef iSeasonalPattern() As Integer,
                                                            ByRef iSeasonalPattern_ForCalcNextDate() As Integer,
                                                            ByVal iHorizon As Integer,
                                                            ByRef dForecasts() As Double) As Boolean

        Dim dForecastsA() As Double
        Dim dForecastsB() As Double
        Dim i As Integer
        Dim bAbnormalFlagA As Boolean
        Dim bAbnormalFlagB As Boolean
        Dim bMeanFlagA As Boolean
        Dim bMeanFlagB As Boolean
        Dim dDataMeanValue As Double
        Dim dForecastsAMeanValue As Double
        Dim dForecastsBMeanValue As Double

        Dim ValidA As Boolean
        Dim ValidB As Boolean

        Try

            'mean value
            dDataMeanValue = clsCommonMath.MeanOfArray(dData, False)

            ReDim dForecastsA(iHorizon)
            ReDim dForecastsB(iHorizon)
            ReDim dForecasts(iHorizon)

            'A
            If bMethodA_SQ_LU = 0 Then
                MathNLIBSQL.clsForecast.Forecast(iMethodA, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecastsA)
            Else
                MathNLIBSQL.clsForecast.Forecast_SQ_LevelUp(iMethodA, dData, dtDate, dTime, iSeasonalityForCalcNextDate, iSeasonalPattern_ForCalcNextDate, iHorizon, dForecastsA)
            End If

            'B
            If bMethodB_SQ_LU = 0 Then
                MathNLIBSQL.clsForecast.Forecast(iMethodB, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecastsB)
            Else
                MathNLIBSQL.clsForecast.Forecast_SQ_LevelUp(iMethodB, dData, dtDate, dTime, iSeasonalityForCalcNextDate, iSeasonalPattern_ForCalcNextDate, iHorizon, dForecastsB)
            End If

            bAbnormalFlagA = False
            bAbnormalFlagB = False
            bMeanFlagA = False
            bMeanFlagB = False

            'Check forecasts
            For i = 1 To iHorizon
                'A
                If dForecastsA(i) < 0 Then
                    bAbnormalFlagA = True
                End If
                'B
                If dForecastsB(i) < 0 Then
                    bAbnormalFlagB = True
                End If
            Next i
            'Average A
            dForecastsAMeanValue = clsCommonMath.MeanOfArray(dForecastsA, False)
            If (dDataMeanValue > 100 * dForecastsAMeanValue) Or (dForecastsAMeanValue > 100 * dDataMeanValue) Then
                bMeanFlagA = True
            End If
            'Average B
            dForecastsBMeanValue = clsCommonMath.MeanOfArray(dForecastsB, False)
            If (dDataMeanValue > 100 * dForecastsBMeanValue) Or (dForecastsBMeanValue > 100 * dDataMeanValue) Then
                bMeanFlagB = True
            End If

            'A
            If bAbnormalFlagA = False And bMeanFlagA = False Then
                ValidA = True
            Else
                ValidA = False
            End If

            'B
            If bAbnormalFlagB = False And bMeanFlagB = False Then
                ValidB = True
            Else
                ValidB = False
            End If

            'Combine
            If ValidA = True And ValidB = True Then
                'Both are valid
                For i = 1 To iHorizon
                    dForecasts(i) = ((iWeightA * dForecastsA(i)) + (iWeightB * dForecastsB(i))) / (iWeightA + iWeightB)
                Next i
            ElseIf ValidA = True And ValidB = False Then
                'Only A is valid
                For i = 1 To iHorizon
                    dForecasts(i) = dForecastsA(i)
                Next i
            ElseIf ValidA = False And ValidB = True Then
                'Only B is valid
                For i = 1 To iHorizon
                    dForecasts(i) = dForecastsB(i)
                Next i
            Else
                'all are not valid  --> Reestimate with 102
                MathNLIBSQL.clsForecast.Forecast(102, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecasts)
            End If

            ForecastAverageTwo = True

        Catch ex As Exception

            ForecastAverageTwo = False
        Finally

        End Try


    End Function

    Public Shared Function ForecastAverageThree(ByVal iMethodA As Integer, ByVal iMethodB As Integer, ByVal iMethodC As Integer,
                                                                                       ByVal bMethodA_SQ_LU As Integer, ByVal bMethodB_SQ_LU As Integer, ByVal bMethodC_SQ_LU As Integer,
                                                                                       ByVal iWeightA As Integer, ByVal iWeightB As Integer, ByVal iWeightC As Integer,
                                                                                       ByRef dData() As Double,
                                                                                       ByRef dtDate() As Date,
                                                                                       ByRef dTime() As Double,
                                                                                        ByVal iSeasonality As Integer,
                                                                                        ByVal iSeasonalityForCalcNextDate As Integer,
                                                                                        ByRef iSeasonalPattern() As Integer,
                                                                                        ByRef iSeasonalPattern_ForCalcNextDate() As Integer,
                                                                                       ByVal iHorizon As Integer,
                                                                                       ByRef dForecasts() As Double) As Boolean

        Dim dForecastsA() As Double
        Dim dForecastsB() As Double
        Dim dForecastsC() As Double
        Dim i As Integer

        Dim bAbnormalFlagA As Boolean
        Dim bAbnormalFlagB As Boolean
        Dim bAbnormalFlagC As Boolean

        Dim bMeanFlagA As Boolean
        Dim bMeanFlagB As Boolean
        Dim bMeanFlagC As Boolean

        Dim dDataMeanValue As Double
        Dim dForecastsAMeanValue As Double
        Dim dForecastsBMeanValue As Double
        Dim dForecastsCMeanValue As Double

        Dim ValidA As Boolean
        Dim ValidB As Boolean
        Dim ValidC As Boolean

        Try

            'mean value
            dDataMeanValue = clsCommonMath.MeanOfArray(dData, False)

            ReDim dForecastsA(iHorizon)
            ReDim dForecastsB(iHorizon)
            ReDim dForecastsC(iHorizon)
            ReDim dForecasts(iHorizon)

            'A
            If bMethodA_SQ_LU = 0 Then
                MathNLIBSQL.clsForecast.Forecast(iMethodA, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecastsA)
            Else
                MathNLIBSQL.clsForecast.Forecast_SQ_LevelUp(iMethodA, dData, dtDate, dTime, iSeasonalityForCalcNextDate, iSeasonalPattern_ForCalcNextDate, iHorizon, dForecastsA)
            End If

            'B
            If bMethodB_SQ_LU = 0 Then
                MathNLIBSQL.clsForecast.Forecast(iMethodB, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecastsB)
            Else
                MathNLIBSQL.clsForecast.Forecast_SQ_LevelUp(iMethodB, dData, dtDate, dTime, iSeasonalityForCalcNextDate, iSeasonalPattern_ForCalcNextDate, iHorizon, dForecastsB)
            End If

            'C
            If bMethodC_SQ_LU = 0 Then
                MathNLIBSQL.clsForecast.Forecast(iMethodC, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecastsC)
            Else
                MathNLIBSQL.clsForecast.Forecast_SQ_LevelUp(iMethodC, dData, dtDate, dTime, iSeasonalityForCalcNextDate, iSeasonalPattern_ForCalcNextDate, iHorizon, dForecastsC)
            End If

            bAbnormalFlagA = False
            bAbnormalFlagB = False
            bAbnormalFlagC = False
            bMeanFlagA = False
            bMeanFlagB = False
            bMeanFlagC = False

            'Check forecasts
            For i = 1 To iHorizon
                'A
                If dForecastsA(i) < 0 Then
                    bAbnormalFlagA = True
                End If
                'B
                If dForecastsB(i) < 0 Then
                    bAbnormalFlagB = True
                End If
                'C
                If dForecastsC(i) < 0 Then
                    bAbnormalFlagC = True
                End If
            Next i
            'Average A
            dForecastsAMeanValue = clsCommonMath.MeanOfArray(dForecastsA, False)
            If (dDataMeanValue > 100 * dForecastsAMeanValue) Or (dForecastsAMeanValue > 100 * dDataMeanValue) Then
                bMeanFlagA = True
            End If
            'Average B
            dForecastsBMeanValue = clsCommonMath.MeanOfArray(dForecastsB, False)
            If (dDataMeanValue > 100 * dForecastsBMeanValue) Or (dForecastsBMeanValue > 100 * dDataMeanValue) Then
                bMeanFlagB = True
            End If
            'Average C
            dForecastsCMeanValue = clsCommonMath.MeanOfArray(dForecastsC, False)
            If (dDataMeanValue > 100 * dForecastsCMeanValue) Or (dForecastsCMeanValue > 100 * dDataMeanValue) Then
                bMeanFlagC = True
            End If
            'A
            If bAbnormalFlagA = False And bMeanFlagA = False Then
                ValidA = True
            Else
                ValidA = False
            End If
            'B
            If bAbnormalFlagB = False And bMeanFlagB = False Then
                ValidB = True
            Else
                ValidB = False
            End If
            'C
            If bAbnormalFlagC = False And bMeanFlagC = False Then
                ValidC = True
            Else
                ValidC = False
            End If

            'Combine
            'Combine
            If ValidA = True And ValidB = True And ValidC = True Then
                'all are valid
                For i = 1 To iHorizon
                    dForecasts(i) = ((iWeightA * dForecastsA(i)) + (iWeightB * dForecastsB(i)) + (iWeightC * dForecastsC(i))) / (iWeightA + iWeightB + iWeightC)
                Next i
            ElseIf ValidA = True And ValidB = True And ValidC = False Then
                'a+b
                For i = 1 To iHorizon
                    dForecasts(i) = ((iWeightA * dForecastsA(i)) + (iWeightB * dForecastsB(i))) / (iWeightA + iWeightB)
                Next i
            ElseIf ValidA = True And ValidB = False And ValidC = True Then
                'a+c
                For i = 1 To iHorizon
                    dForecasts(i) = ((iWeightA * dForecastsA(i)) + (iWeightC * dForecastsC(i))) / (iWeightA + iWeightC)
                Next i
            ElseIf ValidA = True And ValidB = False And ValidC = False Then
                'a
                For i = 1 To iHorizon
                    dForecasts(i) = dForecastsA(i)
                Next i
            ElseIf ValidA = False And ValidB = True And ValidC = True Then
                'b+c
                For i = 1 To iHorizon
                    dForecasts(i) = ((iWeightB * dForecastsB(i)) + (iWeightC * dForecastsC(i))) / (iWeightB + iWeightC)
                Next i
            ElseIf ValidA = False And ValidB = True And ValidC = False Then
                'b
                For i = 1 To iHorizon
                    dForecasts(i) = dForecastsB(i)
                Next i
            ElseIf ValidA = False And ValidB = False And ValidC = True Then
                'c
                For i = 1 To iHorizon
                    dForecasts(i) = dForecastsC(i)
                Next i
            ElseIf ValidA = False And ValidB = False And ValidC = False Then
                ' 'all are not valid  --> Reestimate with 102
                MathNLIBSQL.clsForecast.Forecast(102, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecasts)
            Else
                'not possible
                MathNLIBSQL.clsForecast.Forecast(102, dData, dtDate, dTime, iSeasonality, iSeasonalPattern, iHorizon, dForecasts)
            End If

            ForecastAverageThree = True

        Catch ex As Exception
            ForecastAverageThree = False
        Finally

        End Try

    End Function

    Public Shared Function Timeserie_DetectOutliers(ByRef dData() As Double,
                                                                                                ByRef sErrorMessage As String) As Boolean

        Dim n As Integer

        Dim bOutliersTotal() As Boolean
        Dim bOutliersA() As Boolean
        Dim bOutliersB() As Boolean
        Dim bOutliersC() As Boolean

        Try

            'count the data
            n = UBound(dData)

            'Detect with method A
            ReDim bOutliersA(n)
            clsForecast_Tools.DetectOutliers_MethodA(dData, bOutliersA, sErrorMessage)

            'Detect with method B
            ReDim bOutliersB(n)
            clsForecast_Tools.DetectOutliers_MethodB(dData, bOutliersB, sErrorMessage)

            'Detect with method C
            ReDim bOutliersC(n)
            clsForecast_Tools.DetectOutliers_MethodC(dData, bOutliersC, sErrorMessage)


            'find where the methods agree on an Outlier and replace the value
            ReDim bOutliersTotal(n)
            For i = 1 To n
                bOutliersTotal(i) = bOutliersA(i) And bOutliersB(i) And bOutliersC(i)
            Next i

            'replace values
            clsForecast_Tools.DetectOutliers_ReplaceValues(dData, bOutliersTotal, sErrorMessage)

            Timeserie_DetectOutliers = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            Timeserie_DetectOutliers = False
        Finally

        End Try


    End Function

End Class
