﻿Option Strict Off
Option Explicit On

Public Class clsForecast_Tools

    '**************************************************************
    'Ελεγχος για την ύπαρξη εποχιακότητας
    '**************************************************************
    Public Shared Function Seasonality_Check(ByRef dData() As Double, _
                                                                                ByVal iSeasonality As Integer) As Boolean
        Dim l As Double
        Dim ac1 As Double

        On Error GoTo ErrTrap

        l = Seasonality_Limit(dData, iSeasonality)

        ac1 = clsForecast_Tools.ACF(dData, iSeasonality)

        If (System.Math.Abs(ac1) >= l) Then
            Seasonality_Check = True
        Else
            Seasonality_Check = False
        End If

        GoTo CleanExit


        Exit Function

ErrTrap:
        Seasonality_Check = False

CleanExit:

    End Function

    '*************************************************************************
    'Υπολογισμός του ορίου για ύπαρξη εποχιακότητας
    '*************************************************************************
    Public Shared Function Seasonality_Limit(ByRef dData() As Double, _
                                                                                ByVal iSeasonality As Integer) As Double
        Dim lsum As Double
        Dim lj As Short
        Dim n As Integer
        Dim FDistr_limit_90 As Double

        On Error GoTo ErrTrap

        FDistr_limit_90 = 1.645
        n = UBound(dData)

        lsum = 0
        For lj = 1 To iSeasonality - 1
            If lj = 1 Then
                lsum = lsum + clsForecast_Tools.ACF(dData, lj)
            Else
                lsum = lsum + (clsForecast_Tools.ACF(dData, lj)) ^ 2
            End If
        Next lj
        lsum = lsum * 2
        lsum = lsum + 1

        Seasonality_Limit = FDistr_limit_90 * System.Math.Sqrt(lsum / n)

        GoTo CleanExit

        Exit Function

ErrTrap:

CleanExit:

    End Function

    '***************************************************************************************
    'Auto Corellation Function
    '***************************************************************************************
    Public Shared Function ACF(ByRef a() As Double, _
                                                        ByVal lag As Integer) As Double
        Dim t As Integer
        'Dim i As Integer
        Dim n As Integer
        Dim dSum As Double
        Dim meanval As Double
        Dim nom As Double
        Dim denom As Double

        n = UBound(a)

        'Calculation of mean value
        meanval = clsCommonMath.MeanOfArray(a)

        'Calculation of nominator
        dSum = 0
        For t = (lag + 1) To n
            dSum = dSum + (a(t) - meanval) * (a(t - lag) - meanval)
        Next t
        nom = dSum

        'Calculation of nominator
        dSum = 0
        For t = 1 To n
            dSum = dSum + ((a(t) - meanval) ^ 2)
        Next t
        denom = dSum

        If denom <> 0 Then
            ACF = nom / denom
        Else
            ACF = 0
        End If

    End Function

    Public Shared Function SumsAndSquares(ByRef iArray() As Double, _
                                                                                ByRef s As Double, _
                                                                                ByRef s2 As Double) As Boolean
        Dim dSum As Double
        Dim dSum2 As Double
        Dim i As Integer
        Dim n As Integer

        On Error GoTo ErrTrap

        dSum = 0
        dSum2 = 0
        n = UBound(iArray)
        For i = 1 To n
            dSum = dSum + iArray(i)
            dSum2 = dSum2 + iArray(i) ^ 2
        Next i
        If dSum2 <> 0 Then
            s = dSum
            s2 = dSum2
        Else
            'MsgBox("Äåí õðÜñ÷ïõí äåäïìÝíá Þ Ý÷ïõí ìçäåíéêÝò ôéìÝò")
            Exit Function
        End If

        SumsAndSquares = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        SumsAndSquares = False

CleanExit:

    End Function


    Public Shared Function Calculate_MSE_Simple(ByRef h As Double, _
                                                                                        ByRef aInitialValue As Double, _
                                                                                        ByRef aDataArray() As Double, _
                                                                                        ByRef theForecast As Double) As Double

        Dim mse As Double
        Dim s() As Double
        Dim Err_Renamed() As Double
        Dim k, i As Short

        'Initialisations
        k = UBound(aDataArray)
        ReDim s(k + 1)
        ReDim Err_Renamed(k)

        mse = 0
        s(1) = aInitialValue
        'Main
        For i = 1 To k
            Err_Renamed(i) = aDataArray(i) - s(i)
            s(i + 1) = s(i) + h * Err_Renamed(i)
            mse = mse + Err_Renamed(i) * Err_Renamed(i)
        Next i
        theForecast = s(k)

        Calculate_MSE_Simple = mse

    End Function

    Public Shared Function Calculate_MSE_Holt(ByRef h1 As Double, _
                                                                                    ByRef h2 As Double, _
                                                                                    ByRef ahorizon As Short, _
                                                                                    ByRef aDataArray() As Double, _
                                                                                    ByRef theforecasts() As Double) As Double
        Dim s() As Double
        Dim t() As Double
        Dim Err_Renamed() As Double
        Dim X() As Double
        Dim k, i As Short
        Dim mse As Double

        'Αρχικοποίηση
        k = UBound(aDataArray)
        ReDim s(k + 1)
        ReDim t(k + 1)
        ReDim X(k + 1)
        ReDim Err_Renamed(k + 1)
        mse = 0
        s(1) = aDataArray(1)
        t(1) = aDataArray(2) - aDataArray(1)
        X(1) = s(1) + t(1)

        'Main
        For i = 2 To k
            Err_Renamed(i) = aDataArray(i) - X(i - 1)
            s(i) = s(i - 1) + t(i - 1) + h1 * Err_Renamed(i)
            t(i) = t(i - 1) + h2 * Err_Renamed(i)
            X(i) = s(i) + t(i)
            mse = mse + Err_Renamed(i) * Err_Renamed(i)
        Next i

        For i = 2 To ahorizon + 1
            theforecasts(i - 1) = s(k - 1) + i * t(k - 1)
        Next i

        Calculate_MSE_Holt = mse

    End Function

    Public Shared Function Calculate_MSE_Damped(ByRef h1 As Double, _
                                                                                        ByRef h2 As Double, _
                                                                                        ByRef fi As Double, _
                                                                                        ByRef ahorizon As Short, _
                                                                                        ByRef aDataArray() As Double, _
                                                                                        ByRef theforecasts() As Double) As Double
        Dim s() As Double
        Dim t() As Double
        Dim Err_Renamed() As Double
        Dim X() As Double
        Dim Sigmas() As Double
        Dim k As Integer
        Dim i As Integer
        Dim mse As Double

        'Αρχικοποίηση
        k = UBound(aDataArray)
        ReDim s(k + 1)
        ReDim t(k + 1)
        ReDim X(k + 1)
        ReDim Err_Renamed(k + 1)
        mse = 0
        s(1) = aDataArray(1)
        t(1) = aDataArray(2) - aDataArray(1)
        X(1) = s(1) + fi * t(1)

        'Main
        For i = 2 To k
            Err_Renamed(i) = aDataArray(i) - X(i - 1)
            s(i) = s(i - 1) + fi * t(i - 1) + h1 * Err_Renamed(i)
            t(i) = fi * t(i - 1) + h2 * Err_Renamed(i)
            X(i) = s(i) + fi * t(i)
            mse = mse + Err_Renamed(i) * Err_Renamed(i)
        Next i

        ReDim Sigmas(ahorizon + 1)
        Sigmas(1) = 0

        For i = 2 To ahorizon + 1
            Sigmas(i) = Sigmas(i - 1) + (fi ^ i) * t(k - 1)
        Next i

        For i = 2 To ahorizon + 1
            theforecasts(i - 1) = s(k - 1) + Sigmas(i)
        Next i

        Calculate_MSE_Damped = mse

    End Function

    Public Shared Function Method_ARIMA(ByRef xw() As Double, _
                                                                    ByRef xip As Short, _
                                                                    ByRef xd As Short, _
                                                                    ByRef xiq As Short, _
                                                                    ByRef xl As Short, _
                                                                    ByRef xphi() As Double, _
                                                                    ByRef xtheta() As Double, _
                                                                    ByRef xy() As Double) As Boolean
        'ARIMA METHOD
        Dim xn As Short
        Dim xird, xir, xnp, xirz As Short
        Dim xnrbar As Short
        Dim xdelta() As Double
        Dim xamse() As Double
        Dim xa() As Double
        Dim xp() As Double
        Dim xv() As Double
        Dim xresid() As Double
        Dim xe() As Double
        Dim xxnext() As Double
        Dim xxrow() As Double
        Dim xrbar() As Double
        Dim xthetab() As Double
        Dim xstore() As Double
        Dim xifault As Short

        On Error GoTo ErrTrap

        xn = UBound(xw)

        arxikesTimes(xw, xip, xiq, xphi, xtheta)

        xir = clsCommonMath.Max_FromTwo(CDbl(xip), CDbl(xiq + 1))
        xnp = xir * (xir + 1) / 2
        xird = xir + xd
        xirz = xird * (xird + 1) / 2
        xnrbar = xnp * (xnp - 1) / 2

        If xd <> 0 Then
            ReDim Preserve xdelta(xd)
            If xd = 1 Then
                xdelta(1) = xd
            ElseIf xd = 2 Then
                xdelta(1) = xd
                xdelta(2) = -1
            End If
        End If

        forkal(xip, xiq, xir, xnp, xird, xirz, xd, xl, xn, xnrbar, xphi, xtheta, xdelta, xw, xy, xamse, xa, xp, xv, xresid, xe, xxnext, xxrow, xrbar, xthetab, xstore, xifault)

        Method_ARIMA = True

        Exit Function

ErrTrap:
        Method_ARIMA = False

    End Function

    Public Shared Sub arxikesTimes(ByRef xxw() As Double, ByRef xxip As Short, ByRef xxiq As Short, ByRef xxphi() As Double, ByRef xxtheta() As Double)

        Dim r1, R2 As Double
        Dim b1theta, b0theta, b2theta As Double

        r1 = ACF_FIS(xxw, 1)
        R2 = ACF_FIS(xxw, 2)

        '(1,0)
        If xxip = 1 And xxiq = 0 Then
            ReDim Preserve xxphi(1)
            xxphi(1) = r1
        End If

        '(0,1)
        If xxiq = 1 And xxip = 0 Then
            ReDim Preserve xxtheta(1)
            xxtheta(1) = ThetaApoTrivnymo(r1, 1, r1)
        End If

        '(1,1)
        If xxip = 1 And xxiq = 1 Then
            ReDim Preserve xxphi(1)
            ReDim Preserve xxtheta(1)
            xxphi(1) = R2 / r1
            b2theta = r1 - xxphi(1)
            b1theta = xxphi(1) ^ 2 - 2 * r1 * xxphi(1) + 1
            b0theta = xxphi(1)
            xxtheta(1) = ThetaApoTrivnymo(b0theta, b1theta, b2theta)
        End If

    End Sub

    Public Shared Sub forkal(ByRef ip As Short, ByRef iq As Short, ByRef ir As Short, ByRef np As Short, ByRef ird As Short, ByRef irz As Short, ByRef id As Short, ByRef il As Short, _
                                        ByRef n As Short, ByRef nrbar As Short, ByRef phi() As Double, ByRef theta() As Double, ByRef delta() As Double, ByRef w() As Double, ByRef y() As Double, _
                                        ByRef amse() As Double, ByRef a() As Double, ByRef p() As Double, ByRef v() As Double, ByRef resid() As Double, ByRef e() As Double, ByRef xnext() As Double, _
                                        ByRef xrow() As Double, ByRef rbar() As Double, ByRef thetab() As Double, ByRef store() As Double, ByRef ifault As Short)

        'ip : input = the value of p
        'iq : input = the value of q
        'ir : input = the value of  r = Max(p, q + 1))
        'np : input = the value of r * (r + 1) / 2
        'ird : input = the value of s = r + d
        'irz : input = the value of s * (s + 1) / 2
        'id : input = the value of d
        'il : input = l, the number of forecasts to be generated
        'n : input = n, the number of observations
        'nrbar : input = the value of np * (np - 1)/2
        'phi(ir) : input = the value of ö in the first p locations
        '        : output = the values are overwritten
        'theta(ir) : input = the value of è in the first q locations
        'delta(id) : input = the value of äj
        'w(n) : input = the observations
        '     : output = the differenced observations
        'y(il) : output = predicted values if yt.
        'amse(il) : output = corresponding conditional mean square errors of the prdicted values
        'a(ird) : workspace
        'p(irz) : workspace
        'v(np) : workspace
        'resid() : workspace
        'e(ir) : workspace + used to store the lasr q standardized prediction errors
        'xnext(np) : workspace = used to calculate P
        'xrow(np) : workspace = used to calculate P
        'rbar(nrbar) : workspace = used to calculate P
        'thetab(np) : workspace = used to calculate P
        'store(ird) : workspace = used to calculate P
        'ifault : output = a fault indicator


        'invoking this routine will calculate the finite sample predictions and their conditional mean square errors
        'for any ARIMA process

        Dim zero As Integer
        Dim one As Integer
        Dim two As Integer
        Dim mesiTimi As Double

        zero = 0
        one = 1
        two = 2

        Dim id2r, ibc, i, i45, id1, id2r1 As Short
        Dim idrr1, idd2, id2r2, idd1, iddr, idk As Short
        Dim iq1, ind1, iid, ind, ind2, ir1 As Short
        Dim irj, iri, ir2, iri1, iupd As Short
        Dim jkl1, jj, j, j1, jkl, jklj As Short
        Dim jrj, jrk As Short
        Dim kk1, k1, k, kk, kkk As Short
        Dim ll, lk, l, lk1, lli As Short
        Dim nj, nit, nt As Short
        Dim phii, del, aa, a1, ams, dt, phij As Double
        Dim ssq, phijdt, sigma As Double
        'Dim sulog As Double

        ifault = 0
        If ip < 0 Then ifault = 1
        If iq < 0 Then ifault = ifault + 2
        If ip * ip + iq * iq = 0 Then ifault = 4
        k = iq + 1
        If k < ip Then k = ip
        If ir <> k Then ifault = 5
        If np <> ir * (ir + 1) / 2 Then ifault = 6
        If nrbar <> np * (np - 1) / 2 Then ifault = 7
        If id < 0 Then ifault = 8
        If ird <> ir + id Then ifault = 9
        If irz <> ird * (ird + 1) / 2 Then ifault = 10
        If il < 1 Then ifault = 11
        If ifault <> 0 Then Exit Sub

        'arxikes times
        mesiTimi = clsCommonMath.MeanOfArray(w)


        'calculate initial conditions for Kalman filter
        ReDim Preserve a(ird)
        ReDim Preserve v(np)
        a(1) = zero
        v(1) = one
        If np = 1 Then GoTo ekatontrianta
        For i = 2 To np
            v(i) = zero
        Next i
        If iq = 0 Then GoTo ekatontrianta
        iq1 = iq + 1
        For i = 2 To iq1
            v(i) = theta(i - 1)
        Next i
        For j = 1 To iq
            ll = j * (2 * ir + 1 - j) / 2
            For i = j To iq
                lli = ll + i
                v(lli) = theta(i) * theta(j)
            Next i
        Next j

        'find initial likelihood conditions
        'IFAULT not tested on exit from STARMA as all positive errors have been checked above
ekatontrianta:
        ReDim Preserve p(irz)
        If ir = 1 Then p(1) = one / (one - phi(1) * phi(1))
        If ir <> 1 Then
            starma(ip, iq, ir, np, phi, theta, a, p, v, thetab, xnext, xrow, rbar, nrbar, ifault)
        End If
        '   MsgBox phi(1)
        '   MsgBox phi(2)
        '   MsgBox theta(1)
        '   MsgBox a(1)
        'calculate data transformations
        nt = n - id
        If id = 0 Then GoTo ekatonevthomhnta
        ReDim Preserve store(ird)
        For j = 1 To id
            nj = n - j
            store(j) = w(nj)
        Next j
        For i = 1 To nt
            aa = zero
            For k = 1 To id
                idk = id + i - k
                aa = aa - delta(k) * w(idk)
            Next k
            iid = i + id
            w(i) = w(iid) + aa
        Next i

        'evaluate likelihood to obtain final KF conditions
ekatonevthomhnta:
        Dim sumlog, sigms As Double

        sumlog = zero
        ssq = zero
        iupd = 1
        del = -one
        nit = 0
        karma(ip, iq, ir, phi, theta, a, p, v, nt, w, resid, sumlog, ssq, iupd, del, e, nit)

        'calculate M.L.E. of sigma squared
        sigma = zero
        For j = 1 To nt
            sigma = sigma + resid(j) * resid(j)
        Next j
        sigms = sigms / nt

        'reset the initial A and P when diferencing occurs
        If id = 0 Then GoTo diakosiapenhnta
        ReDim Preserve xrow(np)
        For i = 1 To np
            xrow(i) = p(i)
        Next i
        For i = 1 To irz
            p(i) = zero
        Next i
        ind = 0
        For j = 1 To ir
            k = (j - 1) * (id + ir + 1) - (j - 1) * j / 2
            For i = j To ir
                ind = ind + 1
                k = k + 1
                p(k) = xrow(ind)
            Next i
        Next j
        For j = 1 To id
            irj = ir + j
            a(irj) = store(j)
        Next j

        'setup constants
diakosiapenhnta:
        ir2 = ir + 1
        ir1 = ir - 1
        id1 = id - 1
        id2r = 2 * ird
        id2r1 = id2r - 1
        idd1 = 2 * id + 1
        idd2 = idd1 + 1
        i45 = id2r + 1
        idrr1 = ird + 1
        iddr = 2 * id + ir
        jkl = ir * (iddr + 1) / 2
        jkl1 = jkl + 1
        id2r2 = id2r + 2
        ibc = ir * (i45 - ir) / 2
        For l = 1 To il
            'pedict A
            a1 = a(1)
            If ir = 1 Then GoTo triakosiadeka
            For i = 1 To ir1
                a(i) = a(i + 1)
            Next i
triakosiadeka:
            a(ir) = zero
            If ip = 0 Then GoTo triakosiatrianta
            For j = 1 To ip
                a(j) = a(j) + phi(j) * a1
            Next j
triakosiatrianta:
            If id = 0 Then GoTo triakosiaexhnta
            For j = 1 To id
                irj = ir + j
                a1 = a1 + delta(j) * a(irj)
            Next j
            If id < 2 Then GoTo triakosiaexhnta
            For i = 1 To id1
                iri1 = ird - i
                a(iri1 + 1) = a(iri1)
            Next i
triakosiaexhnta:
            'ReDim Preserve a(1 To ir2)
            If ir2 > ird Then ReDim Preserve a(ir2)
            a(ir2) = a1
            'predict P
            If id = 0 Then GoTo tetrakosiaogthonta
            For i = 1 To id
                store(i) = zero
                For j = 1 To id
                    ll = clsCommonMath.Max_FromTwo(CDbl(i), CDbl(j))
                    k = clsCommonMath.Min_FromTwo(CDbl(i), CDbl(j))
                    jj = jkl + (ll - k) + 1 + (k - 1) * (idd2 - k) / 2
                    store(i) = store(i) + delta(j) * p(jj)
                Next j
            Next i
            For j = 1 To id1
                jj = id - j
                lk = (jj - 1) * (idd2 - jj) / 2 + jkl
                lk1 = jj * (idd1 - jj) / 2 + jkl
                For i = 1 To j
                    lk = lk + 1
                    lk1 = lk1 + 1
                    p(lk1) = p(lk)
                Next i
            Next j
            For j = 1 To id1
                jklj = jkl1 + j
                irj = ir + j
                p(jklj) = store(j) + p(irj)
            Next j

            p(jkl1) = p(1)
            For i = 1 To id
                iri = ir + i
                p(jkl1) = p(jkl1) + delta(i) * (store(i) + two * p(iri))
            Next i
            For i = 1 To id
                iri = ir + i
                store(i) = p(iri)
            Next i
            For j = 1 To ir
                kk1 = j * (id2r1 - j) / 2 + ir
                k1 = (j - 1) * (id2r - j) / 2 + ir
                For i = 1 To id
                    kk = kk1 + i
                    k = k1 + i
                    p(k) = phi(j) * store(i)
                    If j <> ir Then p(k) = p(k) + p(kk)
                Next i
            Next j

            For j = 1 To ir
                store(j) = zero
                kkk = j * (i45 - j) / 2 - id
                For i = 1 To id
                    kkk = kkk + 1
                    store(j) = store(j) + delta(i) * p(kkk)
                Next i
            Next j
            If id = 1 Then GoTo tetrakosiaexhnta
            For j = 1 To ir
                k = j * idrr1 - j * (j + 1) / 2 + 1
                For i = 1 To id1
                    k = k - 1
                    p(k) = p(k - 1)
                Next i
            Next j
tetrakosiaexhnta:
            For j = 1 To ir
                k = (j - 1) * (id2r - j) / 2 + ir + 1
                p(k) = store(j) + phi(j) * p(1)
                If j < ir Then p(k) = p(k) + p(j + 1)
            Next j
tetrakosiaogthonta:
            ReDim Preserve store(ird)
            For i = 1 To ir
                store(i) = p(i)
            Next i

            ind = 0
            dt = p(1)
            For j = 1 To ir
                phij = phi(j)
                phijdt = phij * dt
                ind2 = (j - 1) * (id2r2 - j) / 2
                ind1 = j * (i45 - j) / 2
                For i = j To ir
                    ind = ind + 1
                    ind2 = ind2 + 1
                    phii = phi(i)
                    p(ind2) = v(ind) + phii * phijdt
                    If j < ir Then p(ind2) = p(ind2) + store(j + 1) * phii
                    If i = ir Then GoTo cycle
                    ind1 = ind1 + 1
                    p(ind2) = p(ind2) + store(i + 1) * phij + p(ind1)
cycle:
                Next i
            Next j

            'predict Y
            ReDim Preserve y(il)
            y(l) = a(1) + mesiTimi
            If id = 0 Then GoTo pentakosiaeikosi
            For j = 1 To id
                irj = ir + j
                y(l) = y(l) + a(irj) * delta(j)
            Next j

            'calculate M.S.E. of Y
pentakosiaeikosi:
            ams = p(1)
            For j = 1 To id
                jrj = ibc + (j - 1) * (idd2 - j) / 2
                irj = ir + j
                ams = ams + two * delta(j) * p(irj) + p(jrj + 1) * delta(j) * delta(j)
            Next j
            For j = 1 To id1
                j1 = j + 1
                jrk = ibc + 1 + (j - 1) * (idd2 - j) / 2
                For i = j1 To id
                    jrk = jrk + 1
                    ams = ams + two * delta(i) * delta(j) * p(jrk)
                Next i
            Next j
            ReDim Preserve amse(il)
            amse(l) = ams * sigma
        Next l

        Exit Sub

    End Sub

    Public Shared Sub starma(ByRef ip As Short, ByRef iq As Short, ByRef ir As Short, ByRef np As Short, ByRef phi() As Double, ByRef theta() As Double, ByRef a() As Double, ByRef p() As Double, ByRef v() As Double, ByRef thetab() As Double, ByRef xnext() As Double, ByRef xrow() As Double, ByRef rbar() As Double, ByRef nrbar As Short, ByRef ifault As Short)

        'ip : input = the value of p
        'iq : input = the value of q
        'ir : input = the value of  r = Max(p, q + 1))
        'np : input = the value of r * (r + 1) / 2
        'phi(ir) : input = the value of ö in the first p locations
        '        : output = contains the first column of T
        'theta(ir) : input = the value of è in the first q locations
        'a(ir) : output = on exit contains a0
        'p(np) : output = on exit contains P0, stored as a lower triangular matrix, column by column
        'v(np) : output = on exit contains RR', stored as a lower triangular matrix, column by column
        'thetab(np) : workspace : used to calculate P
        'xnext (np): workspace : used to calculate P
        'xrow(np) : workspace : used to calculate P
        'rbar(nrbar) : workspace : used to calculate P
        'nrbar : input = the value of np * (np - 1)/2
        'ifault : output = afault indicator


        'sets the values of V and PHI, and obtains the initial values of A and P.
        'initialisation for AR(1) process:
        'v(1) = 1
        'a(1) = 0
        'p(1) = 1 / (1 - phi(1) ^ 2)

        Dim zero As Integer
        Dim one As Integer

        Dim recres, phij, vj, phii, ssqerr, ynext As Double
        Dim npr, j, indn, indi, ind1, ifail, i, ind, ind2, indj, irank, k, npr1 As Short

        'check for failure indication
        ifault = 0
        If ip < 0 Then ifault = 1
        If iq < 0 Then ifault = ifault + 2
        If (ip = 0 And iq = 0) Then ifault = 4
        k = iq + 1
        If k < ip Then k = ip
        If ir <> k Then ifault = 5
        If np <> ir * (ir + 1) / 2 Then ifault = 6
        If nrbar <> np * (np - 1) / 2 Then ifault = 7
        If ir = 1 Then ifault = 8
        If ifault <> 0 Then Exit Sub
        'set A(0), V and PHI
        For i = 2 To ir
            a(i) = zero
            ReDim Preserve phi(i)
            If i > ip Then phi(i) = zero
            v(i) = zero
            If i <= iq + 1 Then v(i) = theta(i - 1)
        Next i
        a(1) = zero
        If ip = 0 Then phi(1) = zero
        v(1) = one
        ind = ir
        For j = 2 To ir
            vj = v(j)
            For i = j To ir
                ind = ind + 1
                v(ind) = v(i) * v(j)
            Next i
        Next j
        'find p(0)
        If ip <> 0 Then
            'the set of equations S*VEC(P0)=NEC(V) is solved for VEC(P(0)).
            'S is generated row by row in the array XNEXT.
            'the ortders of elements in P is changed so as to bring more leading zeros into the rows of S
            'hence achieving a reduction of computing time
            irank = 0
            ssqerr = zero
            ReDim Preserve rbar(nrbar)
            For i = 1 To nrbar
                rbar(i) = zero
            Next i
            ReDim Preserve xnext(np)
            ReDim Preserve thetab(np)
            For i = 1 To np
                p(i) = zero
                thetab(j) = zero
                xnext(i) = zero
            Next i
            ind = 0
            ind1 = 0
            npr = np - ir
            npr1 = npr + 1
            indj = npr1
            ind2 = npr
            For j = 1 To ir
                phij = phi(j)
                xnext(indj) = zero
                indj = indj + 1
                indi = npr1 + j
                For i = j To ir
                    ind = ind + 1
                    ynext = v(ind)
                    phii = phi(i)
                    If j <> ir Then
                        xnext(indj) = -phii
                        If i <> ir Then
                            xnext(indi) = xnext(indi) - phij
                            ind1 = ind1 + 1
                            xnext(indi) = -one
                        End If
                    End If
                    xnext(npr1) = -phii * phij
                    ind2 = ind2 + 1
                    If ind2 > np Then ind2 = 1
                    xnext(ind2) = xnext(ind2) + one
                    ReDim Preserve xrow(np)
                    ReDim Preserve xnext(np)
                    inclu2(np, CDbl(one), xnext, xrow, ynext, p, rbar, thetab, ssqerr, recres, irank, ifail)

                    'no need to check IFAIL as WEIGHT = 1.0
                    xnext(ind2) = zero
                    If i <> ir Then
                        xnext(indi) = zero
                        indi = indi + 1
                        xnext(ind1) = zero
                    End If
                Next i
            Next j

            regres(np, nrbar, rbar, thetab, p)

            're-order P
            ind = npr
            For i = 1 To ir
                ind = ind + 1
                xnext(i) = p(ind)
            Next i
            ind = np
            ind1 = npr
            For i = 1 To npr
                p(ind) = p(ind1)
                ind = ind - 1
                ind1 = ind1 - 1
            Next i
            For i = 1 To ir
                p(i) = xnext(i)
            Next i
            Exit Sub
        End If
        'P(0) is obtained by backsubstitution for a moving average process
        indn = np + 1
        ind = np + 1
        For i = 1 To ir
            For j = 1 To i
                ind = ind - 1
                p(ind) = v(ind)
                If j <> 1 Then
                    indn = indn - 1
                    p(ind) = p(ind) + p(indn)
                End If
            Next j
        Next i

        Exit Sub

    End Sub

    Public Shared Function ACF_FIS(ByRef aDataArray() As Double, _
                                                            ByRef alag As Short) As Double
        Dim MinAcceptedNumber As Double
        Dim i As Integer
        Dim n As Integer
        Dim a As Double
        Dim p As Double
        Dim avy As Double

        MinAcceptedNumber = 10 ^ (-10)

        'Main
        avy = clsCommonMath.MeanOfArray(aDataArray)
        n = UBound(aDataArray)
        a = 0
        p = 0
        For i = 1 To n - alag
            a = a + (aDataArray(i) - avy) * (aDataArray(i + alag) - avy)
        Next i
        For i = 1 To n
            p = p + (aDataArray(i) - avy) ^ 2
        Next i

        If System.Math.Abs(p) > MinAcceptedNumber Then
            ACF_FIS = a / p
        Else
            ACF_FIS = a / MinAcceptedNumber
        End If

    End Function

    Public Shared Function ThetaApoTrivnymo(ByRef b0 As Double, _
                                                                                    ByRef b1 As Double, _
                                                                                    ByRef b2 As Double) As Double

        Dim x1, d, x2 As Double

        d = b1 ^ 2 - 4 * b2 * b0
        If d >= 0 Then
            x1 = (-b1 + System.Math.Sqrt(d)) / (2 * b2)
            x2 = (-b1 - System.Math.Sqrt(d)) / (2 * b2)
            If x1 < 1 And x1 > -1 Then
                ThetaApoTrivnymo = x1
            ElseIf x2 < 1 And x2 > -1 Then
                ThetaApoTrivnymo = x2
            Else
                If System.Math.Abs(x1) - 1 <= System.Math.Abs(x2 - 1) Then
                    ThetaApoTrivnymo = x1
                Else
                    ThetaApoTrivnymo = x2
                End If
            End If
        Else
            ThetaApoTrivnymo = -b1 / 2 * b2
        End If

    End Function

    Public Shared Sub karma(ByRef ip As Short, ByRef iq As Short, ByRef ir As Short, ByRef phi() As Double, ByRef theta() As Double, ByRef a() As Double, ByRef p() As Double, ByRef v() As Double, ByRef n As Short, ByRef w() As Double, ByRef resid() As Double, ByRef sumlog As Double, ByRef ssq As Double, ByRef iupd As Short, ByRef delta As Double, ByRef e() As Double, ByRef nit As Short)

        'ip : input = the value of p
        'iq : input = the value of q
        'ir : input = the value of  r = Max(p, q + 1))
        'np : input = the value of r * (r + 1) / 2
        'phi(ir) : input = the first column of T
        'theta(ir) : input = the value of è in the first q locations
        'a(ir) : input = contains a0
        'p(np) : input = contains P0
        'v(np) : input = contains RR'
        'n : input = n, the number of observations
        'w(n) : input = the observations
        'resid(n) : output = the corresponding standardized prediction errors
        'sumlog : input = initial value of Ólogft (zero if no previous observations)
        '       : output = final value of Ólogft
        'ssq : input = initial value of Óít^2 (zero if no previous observations)
        '    : output = final value of Óít^2
        'iupd : input = if iupd = 1 the predictin equations are bypassed for the first observation.
        '               This is necessary when the value of Po has been obtained from starma.
        'delta : input = when nit = 0 determines the level of approximation.
        '                Negative DELTA ensures that the Kalman filter is used for all observations.
        'e(ir) : workspace = used to store the last q standardized prediction errors.
        'nit : input =  0
        '    : output = number of observations dealt with by the Kalman filter.


        'N.B. Argument NP has been removed
        'invoking this subroutine updates A, p, SUMLOG and SSQ by inclusion of data values W(1) TO w(n).
        'the corresponding values of RESID are also obtained.
        'when FT is less than (! + DELTA), quick recursions are used.

        Dim ut, et, a1, wnext, dt, ft, g As Double
        Dim indn, ind, i, ii, inde, indw As Short
        Dim j, ir1, l As Short
        Dim iArray As Short

        Dim zero As Integer


        ir1 = ir - 1
        'UPGRADE_WARNING: Lower bound of array e was changed from 1 to 0. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="0F1C9BE1-AF9D-476E-83B1-17D43BECFF20"'
        ReDim Preserve e(ir)
        For i = 1 To ir
            e(i) = zero
        Next i
        inde = 1
        'for non-zero values of NIT, perform quick recursions
        If nit = 0 Then
            For i = 1 To n
                wnext = w(i)
                'prediction
                If (iupd <> 1) Or (i <> 1) Then
                    'DT = FT - 1
                    dt = zero
                    If ir <> 1 Then dt = p(ir + 1)
                    If dt < delta Then GoTo ekato
                    a1 = a(1)
                    If ir <> 1 Then
                        For j = 1 To ir1
                            a(j) = a(j + 1)
                        Next j
                    End If
                    a(ir) = zero
                    If ip <> 0 Then
                        For j = 1 To ip
                            a(j) = a(j) + phi(j) * a1
                        Next j
                    End If
                    ind = 0
                    indn = ir
                    For l = 1 To ir
                        For j = l To ir
                            ind = ind + 1
                            p(ind) = v(ind)
                            If j <> ir Then
                                indn = indn + 1
                                p(ind) = p(ind) + p(indn)
                            End If
                        Next j
                    Next l
                End If
                'updatind
                ft = p(1)
                ut = wnext - a(1)
                If ir <> 1 Then
                    ind = ir
                    For j = 2 To ir
                        g = p(j) / ft
                        a(j) = a(j) + g * ut
                        For l = j To ir
                            ind = ind + 1
                            p(ind) = p(ind) - g * p(l)
                        Next l
                    Next j
                End If
                a(1) = wnext
                For iArray = 1 To ir
                    p(iArray) = zero
                Next iArray
                'UPGRADE_WARNING: Lower bound of array resid was changed from 1 to 0. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="0F1C9BE1-AF9D-476E-83B1-17D43BECFF20"'
                ReDim Preserve resid(n)
                resid(i) = ut / System.Math.Sqrt(System.Math.Abs(ft))
                e(inde) = resid(i)
                inde = inde + 1
                If inde > iq Then inde = 1
                ssq = ssq + ut * ut / ft
                sumlog = sumlog + System.Math.Log(System.Math.Abs(ft))
            Next i
            nit = n
            Exit Sub
        End If
        'quick recursions
        i = 1
ekato:
        nit = i - 1
        For ii = 1 To n
            et = w(ii)
            indw = ii
            If ip <> 0 Then
                For j = 1 To ip
                    indw = indw - 1
                    If indw < 1 Then Exit For
                    et = et - phi(j) * w(indw)
                Next j
            End If
            If iq <> 0 Then
                For j = 1 To iq
                    inde = inde - 1
                    If inde = 0 Then inde = iq
                    et = et - theta(j) * w(indw)
                Next j
            End If
            e(inde) = et
            resid(ii) = et
            ssq = ssq + et * et
            inde = inde + 1
            If inde > iq Then inde = 1
        Next ii

        Exit Sub

    End Sub

    Public Shared Sub inclu2(ByRef np As Short, ByRef Weight As Double, ByRef xnext() As Double, ByRef xrow() As Double, ByRef ynext As Double, ByRef d() As Double, ByRef rbar() As Double, ByRef thetab() As Double, ByRef ssqerr As Double, ByRef recres As Double, ByRef irank As Short, ByRef ifault As Short)

        'N.B. argument NRBAR has been removed

        Dim xi, di, wt, y, dpi, xk As Double
        Dim sbar, cbar, rbthis As Double
        Dim ithisr, i, i1, k As Short

        Dim zero As Integer

        'invoking this subroutine updates D, RBAR, THETAB, SSQERR and IRANK by the inclusion of XNEXT and YNEXT
        'with a specified weight. the values of XNEXT, YNEXT and WEIGHT will be conversed.
        'the corresponding value of RECRES is calculated.

        y = ynext
        wt = Weight

        For i = 1 To np
            xrow(i) = xnext(i)
        Next i
        recres = zero
        ifault = 1
        If wt <= zero Then Exit Sub
        ifault = 0

        ithisr = 0
        For i = 1 To np
            If xrow(i) = zero Then
                ithisr = ithisr + np - i
            Else
                xi = xrow(i)
                di = d(i)
                dpi = di + wt * xi * xi
                d(i) = dpi
                cbar = di / dpi
                sbar = wt * xi / dpi
                wt = cbar * wt
                If i <> np Then
                    i1 = i + 1
                    For k = i1 To np
                        ithisr = ithisr + 1
                        xk = xrow(k)
                        rbthis = rbar(ithisr)
                        xrow(k) = xk - xi * rbthis
                        rbar(ithisr) = cbar * rbthis + sbar * xk
                    Next k
                End If
                xk = y
                y = xk - xi * thetab(i)
                thetab(i) = cbar * thetab(i) + sbar * xk
                If di = zero Then GoTo saranta
            End If
        Next i
        ssqerr = ssqerr + wt * y * y
        recres = y * System.Math.Sqrt(wt)
        Exit Sub

saranta:
        irank = irank + 1

        Exit Sub

    End Sub

    Public Shared Sub regres(ByRef np As Short, ByRef nrbar As Short, ByRef rbar() As Double, ByRef thetab() As Double, ByRef beta() As Double)
        'invoking this subroutine obtains BETA by backsubstitution in the triangular system RBAR and THETAB

        Dim bi As Double
        Dim j, im, i, i1, ithisr, jm As Short

        ithisr = nrbar
        im = np
        For i = 1 To np
            bi = thetab(im)
            If im <> np Then
                i1 = i - 1
                jm = np
                For j = 1 To i1
                    bi = bi - rbar(ithisr) * beta(jm)
                    ithisr = ithisr - 1
                    jm = jm - 1
                Next j
            End If
            beta(im) = bi
            im = im - 1
        Next i

    End Sub

    '***************************************************************************************
    ' Moving Average - SimpleN
    '***************************************************************************************
    Public Shared Function MA_SimpleN(ByRef dData() As Double,
                                                                        ByVal iParameter As Integer,
                                                                        ByRef MA() As Double,
                                                                        ByRef iPointsMissingStart As Integer,
                                                                        ByRef iPointsMissingEnd As Integer,
                                                                        ByRef sErrorMessage As String) As Boolean
        Dim i As Integer
        Dim n As Integer
        Dim dSum As Double
        Dim j As Integer
        Dim iStepsBack As Integer
        Dim iSTepsForward As Integer

        Try
            'Áñ÷éêïðïßçóç
            n = UBound(dData)

            'missing values in MA(N)
            If clsCommonMath.IsOdd(iParameter) = True Then
                'ODD
                iPointsMissingStart = (iParameter - 1) / 2
                iPointsMissingEnd = (iParameter - 1) / 2
                iStepsBack = (iParameter - 1) / 2
                iSTepsForward = (iParameter - 1) / 2
            Else
                'EVEN
                iPointsMissingStart = iParameter / 2
                iPointsMissingEnd = (iParameter / 2) - 1
                iStepsBack = iParameter / 2
                iSTepsForward = (iParameter / 2) - 1
            End If

            'estimate the MA(N)
            ReDim MA(n)
            For i = 1 To n
                If i <= iPointsMissingStart Then
                    MA(i) = 0
                ElseIf i > n - iPointsMissingEnd Then
                    MA(i) = 0
                Else
                    dSum = 0
                    For j = i - iStepsBack To i + iSTepsForward
                        dSum = dSum + dData(j)
                    Next j
                    MA(i) = dSum / iParameter
                End If
            Next i

            MA_SimpleN = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            MA_SimpleN = False
        Finally

        End Try

    End Function

    '***************************************************************************************
    ' Moving Average Method  - SimpleN with Backstaging
    '***************************************************************************************
    Public Shared Function MA_SimpleN_Backstaging(ByRef dData() As Double,
                                                                                                ByVal iParameter As Integer,
                                                                                                ByRef MA() As Double,
                                                                                                ByRef sErrorMessage As String) As Boolean
        Dim i As Integer
        Dim n As Integer
        Dim iStepsBack As Integer
        Dim iSTepsForward As Integer
        Dim dSum As Double
        Dim j As Integer

        Try
            'initialize
            n = UBound(dData)

            'missing values in MA(N)
            If clsCommonMath.IsOdd(iParameter) = True Then
                'ODD
                iStepsBack = (iParameter - 1) / 2
                iSTepsForward = (iParameter - 1) / 2
            Else
                'EVEN
                iStepsBack = iParameter / 2
                iSTepsForward = (iParameter / 2) - 1
            End If

            'estimate the MA(N)
            ReDim MA(n)
            For i = 1 To n
                dSum = 0
                For j = i - iStepsBack To i + iSTepsForward
                    If j < 1 Then
                        dSum = dSum + dData(1)
                    ElseIf j > n Then
                        dSum = dSum + dData(n)
                    Else
                        dSum = dSum + dData(j)
                    End If
                Next j
                MA(i) = dSum / iParameter
            Next i

            MA_SimpleN_Backstaging = True

        Catch ex As Exception

            sErrorMessage = ex.Message
            MA_SimpleN_Backstaging = False

        Finally

        End Try

    End Function

    '***************************************************************************************
    ' Moving Average Method  - WeightedN
    '***************************************************************************************
    Public Shared Function MA_WeightedN(ByRef dData() As Double,
                                                                            ByVal iParameter As Integer,
                                                                            ByRef MA() As Double,
                                                                            ByRef iPointsMissingStart As Integer,
                                                                            ByRef iPointsMissingEnd As Integer,
                                                                            ByRef sErrorMessage As String) As Boolean
        Dim i As Integer
        Dim n As Integer
        Dim iStepsBack As Integer
        Dim iSTepsForward As Integer
        Dim dSum As Double
        Dim j As Integer
        Dim S() As Double
        Dim W() As Double
        Dim dWeightTotal As Double
        Dim jw As Integer

        Try
            'Áñ÷éêïðïßçóç
            n = UBound(dData)

            'missing values in MA(N)
            If clsCommonMath.IsOdd(iParameter) = True Then
                'ODD
                iPointsMissingStart = (iParameter - 1) / 2
                iPointsMissingEnd = (iParameter - 1) / 2
                iStepsBack = (iParameter - 1) / 2
                iSTepsForward = (iParameter - 1) / 2
            Else
                'EVEN
                iPointsMissingStart = iParameter / 2
                iPointsMissingEnd = (iParameter / 2) - 1
                iStepsBack = iParameter / 2
                iSTepsForward = (iParameter / 2) - 1
            End If

            'S
            ReDim S(iParameter)
            If clsCommonMath.IsOdd(iParameter) = True Then
                'ODD
                S((iParameter + 1) / 2) = 1
                For j = ((iParameter - 1) / 2) To 1 Step -1
                    S(j) = S(j + 1) / 2
                Next j
                For j = ((iParameter + 3) / 2) To iParameter Step 1
                    S(j) = S(j - 1) / 2
                Next j
            Else
                'EVEN
                S((iParameter) / 2) = 1
                S((iParameter + 2) / 2) = 1
                For j = ((iParameter - 2) / 2) To 1 Step -1
                    S(j) = S(j + 1) / 2
                Next j
                For j = ((iParameter + 4) / 2) To iParameter Step 1
                    S(j) = S(j - 1) / 2
                Next j
            End If
            dWeightTotal = clsCommonMath.SumOfArray(S)

            'Weights
            ReDim W(iParameter)
            For j = 1 To iParameter
                W(j) = S(j) / dWeightTotal
            Next j

            'estimate the MA(N)
            ReDim MA(n)
            For i = 1 To n
                If i <= iPointsMissingStart Then
                    MA(i) = 0
                ElseIf i > n - iPointsMissingEnd Then
                    MA(i) = 0
                Else
                    dSum = 0
                    jw = 0
                    For j = i - iStepsBack To i + iSTepsForward
                        jw = jw + 1
                        dSum = dSum + dData(j) * W(jw)
                    Next j
                    MA(i) = dSum
                End If
            Next i

            MA_WeightedN = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            MA_WeightedN = False
        Finally

        End Try

    End Function

    '***************************************************************************************
    ' Moving Average Method  - WeightedN with Backstage
    '***************************************************************************************
    Public Shared Function MA_WeightedN_Backstaging(ByRef dData() As Double,
                                                                                            ByVal iParameter As Integer,
                                                                                            ByRef MA() As Double,
                                                                                            ByRef sErrorMessage As String) As Boolean
        Dim i As Integer
        Dim n As Integer
        Dim iStepsBack As Integer
        Dim iSTepsForward As Integer
        Dim dSum As Double
        Dim j As Integer
        Dim S() As Double
        Dim W() As Double
        Dim dWeightTotal As Double
        Dim jw As Integer

        Try
            'Áñ÷éêïðïßçóç
            n = UBound(dData)

            'missing values in MA(N)
            If clsCommonMath.IsOdd(iParameter) = True Then
                'ODD
                iStepsBack = (iParameter - 1) / 2
                iSTepsForward = (iParameter - 1) / 2
            Else
                'EVEN
                iStepsBack = iParameter / 2
                iSTepsForward = (iParameter / 2) - 1
            End If

            'S
            ReDim S(iParameter)
            If clsCommonMath.IsOdd(iParameter) = True Then
                'ODD
                S((iParameter + 1) / 2) = 1
                For j = ((iParameter - 1) / 2) To 1 Step -1
                    S(j) = S(j + 1) / 2
                Next j
                For j = ((iParameter + 3) / 2) To iParameter Step 1
                    S(j) = S(j - 1) / 2
                Next j
            Else
                'EVEN
                S((iParameter) / 2) = 1
                S((iParameter + 2) / 2) = 1
                For j = ((iParameter - 2) / 2) To 1 Step -1
                    S(j) = S(j + 1) / 2
                Next j
                For j = ((iParameter + 4) / 2) To iParameter Step 1
                    S(j) = S(j - 1) / 2
                Next j
            End If
            dWeightTotal = clsCommonMath.SumOfArray(S)

            'Weights
            ReDim W(iParameter)
            For j = 1 To iParameter
                W(j) = S(j) / dWeightTotal
            Next j

            'estimate the MA(N)
            ReDim MA(n)
            For i = 1 To n
                dSum = 0
                jw = 0
                For j = i - iStepsBack To i + iSTepsForward
                    jw = jw + 1
                    If j < 1 Then
                        dSum = dSum + dData(1) * W(jw)
                    ElseIf j > n Then
                        dSum = dSum + dData(n) * W(jw)
                    Else
                        dSum = dSum + dData(j) * W(jw)
                    End If
                Next j
                MA(i) = dSum
            Next i

            MA_WeightedN_Backstaging = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            MA_WeightedN_Backstaging = False

        Finally

        End Try

    End Function

    '***************************************************************************************
    ' Moving Average - DoubleN
    '***************************************************************************************
    Public Shared Function MA_DoubleN(ByRef dData() As Double,
                                                                        ByVal iParameter As Integer,
                                                                        ByRef MA() As Double,
                                                                        ByRef iPointsMissingStart As Integer,
                                                                        ByRef iPointsMissingEnd As Integer,
                                                                        ByRef sErrorMessage As String) As Boolean
        Dim i As Integer
        Dim n As Integer
        Dim dSum As Double
        Dim j As Integer
        Dim iStepsBack As Integer
        Dim iSTepsForward As Integer
        Dim MAInterval() As Double

        Try
            'Áñ÷éêïðïßçóç
            n = UBound(dData)

            '1st RUN

            'missing values in MA(N)
            If clsCommonMath.IsOdd(iParameter) = True Then
                'ODD
                iPointsMissingStart = (iParameter - 1) / 2
                iPointsMissingEnd = (iParameter - 1) / 2
                iStepsBack = (iParameter - 1) / 2
                iSTepsForward = (iParameter - 1) / 2
            Else
                'EVEN
                iPointsMissingStart = iParameter / 2
                iPointsMissingEnd = (iParameter / 2) - 1
                iStepsBack = iParameter / 2
                iSTepsForward = (iParameter / 2) - 1
            End If

            'estimate the MA(N)
            ReDim MAInterval(n)
            For i = 1 To n
                If i <= iPointsMissingStart Then
                    MAInterval(i) = 0
                ElseIf i > n - iPointsMissingEnd Then
                    MAInterval(i) = 0
                Else
                    dSum = 0
                    For j = i - iStepsBack To i + iSTepsForward
                        dSum = dSum + dData(j)
                    Next j
                    MAInterval(i) = dSum / iParameter
                End If
            Next i

            '2nd run

            'missing values in MA(N)
            If clsCommonMath.IsOdd(iParameter) = True Then
                'ODD
                iPointsMissingStart = (iParameter - 1)
                iPointsMissingEnd = (iParameter - 1)
                iStepsBack = (iParameter - 1) / 2
                iSTepsForward = (iParameter - 1) / 2
            Else
                'EVEN
                iPointsMissingStart = (iParameter / 2) * 2
                iPointsMissingEnd = ((iParameter / 2) - 1) * 2
                iStepsBack = (iParameter / 2)
                iSTepsForward = ((iParameter / 2) - 1)
            End If

            'estimate the MA(N)
            ReDim MA(n)
            For i = 1 To n
                If i <= iPointsMissingStart Then
                    MA(i) = 0
                ElseIf i > n - iPointsMissingEnd Then
                    MA(i) = 0
                Else
                    dSum = 0
                    For j = i - iStepsBack To i + iSTepsForward
                        dSum = dSum + MAInterval(j)
                    Next j
                    MA(i) = dSum / iParameter
                End If
            Next i

            MA_DoubleN = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            MA_DoubleN = False
        Finally

        End Try

    End Function

    '***************************************************************************************
    ' Moving Average - DoubleN
    '***************************************************************************************
    Public Shared Function MA_DoubleN_Backstaging(ByRef dData() As Double,
                                                                                                ByVal iParameter As Integer,
                                                                                                ByRef MA() As Double,
                                                                                                ByRef sErrorMessage As String) As Boolean
        Dim i As Integer
        Dim n As Integer
        Dim dSum As Double
        Dim j As Integer
        Dim iStepsBack As Integer
        Dim iSTepsForward As Integer
        Dim MAInterval() As Double

        Try
            'Áñ÷éêïðïßçóç
            n = UBound(dData)

            '1st RUN

            'missing values in MA(N)
            If clsCommonMath.IsOdd(iParameter) = True Then
                'ODD
                iStepsBack = (iParameter - 1) / 2
                iSTepsForward = (iParameter - 1) / 2
            Else
                'EVEN
                iStepsBack = iParameter / 2
                iSTepsForward = (iParameter / 2) - 1
            End If

            'estimate the MA(N)
            ReDim MAInterval(n)
            For i = 1 To n
                dSum = 0
                For j = i - iStepsBack To i + iSTepsForward
                    If j < 1 Then
                        dSum = dSum + dData(1)
                    ElseIf j > n Then
                        dSum = dSum + dData(n)
                    Else
                        dSum = dSum + dData(j)
                    End If
                Next j
                MAInterval(i) = dSum / iParameter
            Next i

            '2nd run

            'missing values in MA(N)
            If clsCommonMath.IsOdd(iParameter) = True Then
                'ODD
                iStepsBack = (iParameter - 1) / 2
                iSTepsForward = (iParameter - 1) / 2
            Else
                'EVEN
                iStepsBack = (iParameter / 2)
                iSTepsForward = ((iParameter / 2) - 1)
            End If

            'estimate the MA(N)
            ReDim MA(n)
            For i = 1 To n
                dSum = 0
                For j = i - iStepsBack To i + iSTepsForward
                    If j < 1 Then
                        dSum = dSum + MAInterval(1)
                    ElseIf j > n Then
                        dSum = dSum + MAInterval(n)
                    Else
                        dSum = dSum + MAInterval(j)
                    End If
                Next j
                MA(i) = dSum / iParameter
            Next i

            MA_DoubleN_Backstaging = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            MA_DoubleN_Backstaging = False
        Finally

        End Try

    End Function

    '************************************************************************************************************************************************************************************
    ' SIMPLE LINEAR REGRESSION
    '************************************************************************************************************************************************************************************
    Public Shared Function EstimateLevel_SimpleLinearRegression(ByRef dData() As Double,
                                                                ByRef sErrorMessage As String) As Double
        'Simple Linera Regression
        Dim i As Short
        Dim n As Short
        Dim avx As Double
        Dim avy As Double
        Dim dSumA As Double
        Dim dSumB As Double

        Dim iTime() As Double
        Dim dSlope As Double
        Dim dConstant As Double

        Try
            n = UBound(dData)

            ReDim iTime(n)
            For i = 1 To n
                iTime(i) = i
            Next i

            avy = clsCommonMath.MeanOfArray(dData)
            avx = clsCommonMath.MeanOfArray(iTime)

            For i = 1 To n
                dSumA = dSumA + ((dData(i) - avy) * (i - avx))
                dSumB = dSumB + ((i - avx) * (i - avx))
            Next i
            dSlope = dSumA / dSumB
            dConstant = avy - dSlope * avx


            EstimateLevel_SimpleLinearRegression = dConstant

        Catch ex As Exception

            sErrorMessage = ex.Message
            EstimateLevel_SimpleLinearRegression = 0

        Finally

        End Try


    End Function

    Public Shared Function ReturnLevelSlope_SimpleLinearRegression(ByRef dData() As Double,
                                                                                                                ByRef dLevel As Double,
                                                                                                                ByRef dSlope As Double,
                                                                                                                ByRef sErrorMessage As String) As Boolean
        'Simple Linera Regression
        Dim i As Short
        Dim n As Short
        Dim avx As Double
        Dim avy As Double
        Dim dSumA As Double
        Dim dSumB As Double

        Dim iTime() As Double

        Try
            n = UBound(dData)

            ReDim iTime(n)
            For i = 1 To n
                iTime(i) = i
            Next i

            avy = clsCommonMath.MeanOfArray(dData)
            avx = clsCommonMath.MeanOfArray(iTime)
            For i = 1 To n
                dSumA = dSumA + ((dData(i) - avy) * (i - avx))
                dSumB = dSumB + ((i - avx) * (i - avx))
            Next i
            dSlope = dSumA / dSumB
            dLevel = avy - dSlope * avx

            ReturnLevelSlope_SimpleLinearRegression = True

        Catch ex As Exception

            sErrorMessage = ex.Message
            ReturnLevelSlope_SimpleLinearRegression = False

        Finally

        End Try


    End Function

    Public Shared Function DetectOutliers_MethodA(ByVal dData() As Double,
                                                                                                                ByRef bOutliers() As Boolean,
                                                                                                                ByRef sErrorMessage As String) As Boolean

        Dim n As Integer
        Dim i As Integer
        Dim MA3() As Double
        Dim MA3X3() As Double
        Dim Ratio1() As Double
        Dim dLevel As Double
        Dim dSlope As Double
        Dim F() As Double
        Dim Ratio2() As Double

        Dim a As Double = 0.05
        Dim b As Double = 0.05

        Try

            'count the data
            n = UBound(dData)

            'estimate MA3
            ReDim MA3(n)
            clsForecast_Tools.MA_SimpleN_Backstaging(dData, 3, MA3, sErrorMessage)

            'estimate MA3x3
            ReDim MA3X3(n)
            clsForecast_Tools.MA_DoubleN_Backstaging(dData, 3, MA3X3, sErrorMessage)

            'estimate Ratio1
            ReDim Ratio1(n)
            For i = 1 To n
                Ratio1(i) = dData(i) / MA3X3(i)
            Next i

            'make SLR over the MA3x3 and take the constant and the slope
            clsForecast_Tools.ReturnLevelSlope_SimpleLinearRegression(MA3X3, dLevel, dSlope, sErrorMessage)

            'estimate F
            ReDim F(n)
            For i = 1 To n
                F(i) = dLevel + (i * dSlope)
            Next i

            'estimare Ratio2
            ReDim Ratio2(n)
            For i = 1 To n
                Ratio2(i) = dData(i) / F(i)
            Next i

            'check for outliers
            ReDim bOutliers(n)
            For i = 1 To n
                If ((Ratio1(i) >= (1.1 - a)) Or (Ratio1(i) <= (0.9 + a))) And ((Ratio2(i) >= (1.25 - b)) Or (Ratio2(i) <= (0.75 + b))) Then
                    bOutliers(i) = True
                Else
                    bOutliers(i) = False
                End If
            Next i


            DetectOutliers_MethodA = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            DetectOutliers_MethodA = False
        Finally

        End Try


    End Function

    Public Shared Function DetectOutliers_MethodB(ByVal dData() As Double,
                                                                                            ByRef bOutliers() As Boolean,
                                                                                            ByRef sErrorMessage As String) As Boolean

        Dim n As Integer
        Dim i As Integer
        Dim MA3() As Double
        Dim MA3X3() As Double
        Dim dLevel As Double
        Dim dSlope As Double
        Dim F() As Double

        Dim dAverageData As Double
        Dim dAverageF As Double
        Dim dStDev As Double

        Dim dLimitMax As Double
        Dim dLimitMin As Double
        Dim a As Double = 1

        Try

            'count the data
            n = UBound(dData)

            'estimate MA3
            ReDim MA3(n)
            clsForecast_Tools.MA_SimpleN_Backstaging(dData, 3, MA3, sErrorMessage)

            'estimate MA3x3
            ReDim MA3X3(n)
            clsForecast_Tools.MA_DoubleN_Backstaging(dData, 3, MA3X3, sErrorMessage)

            'make SLR over the MA3x3 and take the constant and the slope
            clsForecast_Tools.ReturnLevelSlope_SimpleLinearRegression(MA3X3, dLevel, dSlope, sErrorMessage)

            'estimate F
            ReDim F(n)
            For i = 1 To n
                F(i) = dLevel + (i * dSlope)
            Next i

            'estimate AVerage of Data
            dAverageData = clsCommonMath.MeanOfArray(dData, False)

            'estimate average F
            dAverageF = clsCommonMath.MeanOfArray(F, False)

            'estimate the standard deviation 
            dStDev = 0
            For i = 1 To n
                dStDev = dStDev + (F(i) - dAverageF) ^ 2
            Next i
            dStDev = dStDev / n
            dStDev = System.Math.Sqrt(dStDev)

            'estimate the limits
            dLimitMax = dAverageData + ((3 - a) * dStDev)
            dLimitMin = dAverageData - ((3 - a) * dStDev)

            'check for outliers
            ReDim bOutliers(n)
            For i = 1 To n
                If (dData(i) >= dLimitMax) Or (dData(i) <= dLimitMin) Then
                    bOutliers(i) = True
                Else
                    bOutliers(i) = False
                End If
            Next i

            DetectOutliers_MethodB = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            DetectOutliers_MethodB = False
        Finally

        End Try


    End Function

    Public Shared Function DetectOutliers_MethodC(ByVal dData() As Double,
                                                                                         ByRef bOutliers() As Boolean,
                                                                                         ByRef sErrorMessage As String) As Boolean

        Dim n As Integer
        Dim i As Integer
        Dim MA5X5() As Double
        Dim MA7X7() As Double
        Dim dRatio() As Double

        Dim a As Double = 0

        Try

            'count the data
            n = UBound(dData)

            'estimate MA5x5
            ReDim MA5X5(n)
            clsForecast_Tools.MA_DoubleN_Backstaging(dData, 5, MA5X5, sErrorMessage)

            'estimate MA7x7
            ReDim MA7X7(n)
            clsForecast_Tools.MA_DoubleN_Backstaging(dData, 7, MA7X7, sErrorMessage)

            'estimate the ratio
            ReDim dRatio(n)
            For i = 1 To n
                dRatio(i) = MA7X7(i) / MA5X5(i)
            Next i

            'check for outliers
            ReDim bOutliers(n)
            For i = 1 To n
                If (dRatio(i) >= (1.05 - (a / 100))) Or (dRatio(i) <= (0.95 + (a / 100))) Then
                    bOutliers(i) = True
                Else
                    bOutliers(i) = False
                End If
            Next i

            DetectOutliers_MethodC = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            DetectOutliers_MethodC = False
        Finally

        End Try


    End Function

    Public Shared Function DetectOutliers_ReplaceValues(ByVal dData() As Double,
                                                                                     ByVal bOutliers() As Boolean,
                                                                                     ByRef sErrorMessage As String) As Boolean

        Dim n As Integer
        Dim i As Integer
        Dim j As Integer

        Dim dGoodPrevious As Double
        Dim dGoodAfter As Double

        Dim bPrevious As Boolean = False
        Dim bAfter As Boolean = False

        Try

            'count the data
            n = UBound(dData)

            'replace values
            For i = 1 To n
                If bOutliers(i) = True Then

                    'init
                    bPrevious = False
                    bAfter = False
                    dGoodAfter = 0
                    dGoodPrevious = 0

                    'find good previous
                    For j = i - 1 To 1 Step -1
                        If bOutliers(j) = False Then
                            bPrevious = True
                            dGoodPrevious = dData(j)
                            Exit For
                        End If
                    Next j

                    'find good after
                    For j = i + 1 To n
                        If bOutliers(j) = False Then
                            bAfter = True
                            dGoodAfter = dData(j)
                            Exit For
                        End If
                    Next j

                    'replace the value
                    If bAfter = True And bPrevious = True Then
                        dData(i) = (dGoodPrevious + dGoodAfter) / 2
                    ElseIf bAfter = True And bPrevious = False Then
                        dData(i) = dGoodAfter
                    ElseIf bAfter = False And bPrevious = True Then
                        dData(i) = dGoodPrevious
                    Else
                        'can not be replaced
                        dData(i) = dData(i)
                    End If

                End If

                'next i to check
            Next i



            DetectOutliers_ReplaceValues = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            DetectOutliers_ReplaceValues = False
        Finally

        End Try


    End Function

End Class
