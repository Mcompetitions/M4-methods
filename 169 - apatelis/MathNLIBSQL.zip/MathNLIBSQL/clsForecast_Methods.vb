﻿Option Strict Off
Option Explicit On

Public Class clsForecast_Methods

    '************************************************************************************************************************************************************************************
    ' NAIVE
    '************************************************************************************************************************************************************************************
    Public Shared Function Naive(ByRef dData() As Double,
                                                            ByVal iHorizon As Integer,
                                                            ByRef dForecasts() As Double) As Boolean
        'ÌÝèïäïò Naive
        Dim i As Short

        On Error GoTo ErrTrap

        'Áñ÷éêïðïßçóç
        ReDim dForecasts(iHorizon)

        'Õðïëïãéóìüò
        For i = 1 To iHorizon
            dForecasts(i) = dData(UBound(dData))
        Next i

        Naive = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        Naive = False

CleanExit:


    End Function

    '************************************************************************************************************************************************************************************
    ' NAIVE REPEAT
    '************************************************************************************************************************************************************************************
    Public Shared Function NaiveRepeat(ByRef dData() As Double,
                                                                    ByVal iHorizon As Integer,
                                                                    ByVal iSeasonality As Integer,
                                                                    ByRef dForecasts() As Double,
                                                                    ByRef sErrorMessage As String) As Boolean
        Dim i As Short
        Dim n As Integer
        Dim j As Integer

        Try
            'initialize
            ReDim dForecasts(iHorizon)

            n = UBound(dData)

            'Forecasts
            If iSeasonality = 1 Then
                'yearly data
                For i = 1 To iHorizon
                    dForecasts(i) = dData(n)
                Next i
            Else
                'not yearly data
                For i = 1 To iHorizon
                    j = i
                    If j > iSeasonality Then
                        j = i - iSeasonality
                    End If
                    dForecasts(i) = dData(n - iSeasonality + j)
                Next i
            End If

            NaiveRepeat = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            NaiveRepeat = False
        Finally

        End Try


    End Function

    '************************************************************************************************************************************************************************************
    ' MEAN
    '************************************************************************************************************************************************************************************
    Public Shared Function Mean(ByRef dData() As Double,
                                                            ByVal iHorizon As Integer,
                                                            ByRef dForecasts() As Double,
                                                            ByRef sErrorMessage As String) As Boolean
        Dim i As Short
        Dim n As Integer
        Dim dMean As Double

        Try
            'Initialize
            n = UBound(dData)
            ReDim dForecasts(iHorizon)

            'mean
            dMean = clsCommonMath.MeanOfArray(dData, False)

            'Forecasts
            For i = 1 To iHorizon
                dForecasts(i) = dMean
            Next i

            Mean = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            Mean = False
        Finally

        End Try

    End Function

    '************************************************************************************************************************************************************************************
    ' MEDIAN
    '************************************************************************************************************************************************************************************
    Public Shared Function Median(ByRef dData() As Double,
                                                            ByVal iHorizon As Integer,
                                                            ByRef dForecasts() As Double,
                                                            ByRef sErrorMessage As String) As Boolean
        Dim i As Short
        Dim n As Integer
        Dim dMedian As Double

        Try
            'Initialize
            n = UBound(dData)
            ReDim dForecasts(iHorizon)

            'mean
            dMedian = clsCommonMath.Median(dData)

            'Forecasts
            For i = 1 To iHorizon
                dForecasts(i) = dMedian
            Next i

            Median = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            Median = False
        Finally

        End Try

    End Function

    '************************************************************************************************************************************************************************************
    'NAIVE TREND
    '************************************************************************************************************************************************************************************
    Public Shared Function Naive_Trend(ByRef dData() As Double,
                                                                    ByRef iTime() As Double,
                                                                    ByVal iHorizon As Integer,
                                                                    ByRef dForecasts() As Double) As Boolean
        'Naive Trend
        Dim i As Integer
        Dim n As Integer
        Dim Mean_X As Double
        Dim Mean_Y As Double
        Dim Sx As Double
        Dim Sxy As Double
        Dim Sx2 As Double
        Dim dConstant As Double
        Dim dSlope As Double

        On Error GoTo ErrTrap

        'Áñ÷éêïðïßçóç
        ReDim dForecasts(iHorizon)

        'Õðïëïãéóìüò ëüãù ôçò ôÜóçò
        If UBound(iTime) = UBound(dData) Then
            n = UBound(iTime) 'ìÞêïò ×Ó
            Mean_Y = clsCommonMath.MeanOfArray(dData) 'ì.ï. Õ
            Mean_X = clsCommonMath.MeanOfArray(iTime) 'ì.ï. ×
            clsForecast_Tools.SumsAndSquares(iTime, Sx, Sx2)
            Sxy = 0
            For i = 1 To n
                Sxy = Sxy + iTime(i) * dData(i)
            Next i
            dSlope = (Sxy / n - Mean_X * Mean_Y) / (Sx2 / n - Mean_X * Mean_X)
            dConstant = Mean_Y - (dSlope * Mean_X)
            dForecasts(1) = dData(UBound(dData)) + dSlope 'naive
            For i = 2 To iHorizon
                dForecasts(i) = dForecasts(i - 1) + dSlope
            Next i
        Else
            'MsgBox("InvalidInput ArraysSizesmustbeequal")
        End If

        Naive_Trend = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        Naive_Trend = False

CleanExit:

    End Function

    '************************************************************************************************************************************************************************************
    ' SIMPLE LINEAR REGRESSION
    '************************************************************************************************************************************************************************************
    Public Shared Function LinearRegression_Simple(ByRef dData() As Double,
                                                    ByRef iTime() As Double,
                                                    ByVal iHorizon As Integer,
                                                    ByRef dForecasts() As Double,
                                                    ByRef sErrorMessage As String) As Boolean
        'Simple Linera Regression
        Dim i As Short
        Dim n As Short
        Dim avx As Double
        Dim avy As Double
        Dim dSlope As Double
        Dim dConstant As Double

        Dim dSumA As Double = 0
        Dim dSumB As Double = 0

        Try
            'Initializations
            ReDim dForecasts(iHorizon)

            'Main
            n = UBound(dData)
            avy = clsCommonMath.MeanOfArray(dData)
            avx = clsCommonMath.MeanOfArray(iTime)
            For i = 1 To n
                dSumA = dSumA + ((dData(i) - avy) * (i - avx))
                dSumB = dSumB + ((i - avx) * (i - avx))
            Next i
            dSlope = dSumA / dSumB
            dConstant = avy - dSlope * avx

            For i = 1 To iHorizon
                dForecasts(i) = dConstant + dSlope * (iTime(n) + i)
            Next i

            LinearRegression_Simple = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            LinearRegression_Simple = False
        Finally

        End Try

    End Function

    '************************************************************************************************************************************************************************************
    ' SIMPLE EXPONENTIAL SMOOTHING
    '************************************************************************************************************************************************************************************
    Public Shared Function ExponentialSmoothing_Simple(ByRef dData() As Double,
                                                                                                    ByVal iHorizon As Integer,
                                                                                                    ByVal aSmoothingParameter As Double,
                                                                                                    ByVal sMethodFirstPoint As String,
                                                                                                    ByRef dForecasts() As Double,
                                                                                                    ByRef sErrorMessage As String) As Boolean
        Dim n As Integer
        Dim S() As Double
        Dim F() As Double
        Dim E() As Double

        Try

            'define n
            ReDim dForecasts(iHorizon)
            n = UBound(dData)

            'Step1. Initialize the first value
            ReDim S(n)
            ReDim F(n)
            ReDim E(n)
            Select Case sMethodFirstPoint
                Case "A"
                    'average of all historical data
                    S(0) = clsCommonMath.SumOfArray(dData) / n
                Case "M"
                    'mean of first 4 historical data
                    If n >= 4 Then
                        S(0) = (dData(1) + dData(2) + dData(3) + dData(4)) / 4
                    Else
                        S(0) = dData(1)
                    End If
                Case "F"
                    'the first historical data
                    S(0) = dData(1)
                Case "L"
                    'the Level for the model of Linear Regression
                    S(0) = clsForecast_Tools.EstimateLevel_SimpleLinearRegression(dData, sErrorMessage)
                Case Else
                    S(0) = dData(1)
            End Select

            'Step2.
            For i = 1 To n
                'forecast
                F(i) = S(i - 1)
                'error
                E(i) = dData(i) - F(i)
                's component
                S(i) = S(i - 1) + aSmoothingParameter * E(i)
            Next i

            'Step3. Forecasts
            For i = 1 To iHorizon
                dForecasts(i) = S(n)
            Next i

            ExponentialSmoothing_Simple = True

        Catch ex As Exception

            sErrorMessage = ex.Message
            ExponentialSmoothing_Simple = False

        Finally

        End Try





    End Function


    '************************************************************************************************************************************************************************************
    'SIMPLE EXPONENTIAL SMOOTHING - TREND
    '************************************************************************************************************************************************************************************
    Public Shared Function ExponentialSmoothing_Simple_Trend(ByRef dData() As Double,
                                                                                                    ByRef iTime() As Double,
                                                                                                    ByVal iHorizon As Integer,
                                                                                                    ByVal aSmoothingParameter As Double,
                                                                                                    ByVal sMethodFirstPoint As String,
                                                                                                    ByRef dForecasts() As Double,
                                                                                                    ByRef sErrorMessage As String) As Boolean

        Dim n As Integer
        Dim S() As Double
        Dim F() As Double
        Dim E() As Double

        Dim avy, Sxy, Sx, avx, Sx2 As Double
        Dim dConstant As Double
        Dim dSlope As Double

        Try

            'define n
            ReDim dForecasts(iHorizon)
            n = UBound(dData)

            'Step1. Initialize the first value
            ReDim S(n)
            ReDim F(n)
            ReDim E(n)
            Select Case sMethodFirstPoint
                Case "A"
                    'average of all historical data
                    S(0) = clsCommonMath.SumOfArray(dData) / n
                Case "M"
                    'mean of first 4 historical data
                    If n >= 4 Then
                        S(0) = (dData(1) + dData(2) + dData(3) + dData(4)) / 4
                    Else
                        S(0) = dData(1)
                    End If
                Case "F"
                    'the first historical data
                    S(0) = dData(1)
                Case "L"
                    'the Level for the model of Linear Regression
                    S(0) = clsForecast_Tools.EstimateLevel_SimpleLinearRegression(dData, sErrorMessage)
                Case Else
                    S(0) = dData(1)
            End Select

            'Step2.
            For i = 1 To n
                'forecast
                F(i) = S(i - 1)
                'error
                E(i) = dData(i) - F(i)
                's component
                S(i) = S(i - 1) + aSmoothingParameter * E(i)
            Next i

            'Step3. Forecasts
            avy = clsCommonMath.MeanOfArray(dData)
            avx = clsCommonMath.MeanOfArray(iTime)
            clsForecast_Tools.SumsAndSquares(iTime, Sx, Sx2)
            Sxy = 0
            For i = 1 To n
                Sxy = Sxy + iTime(i) * dData(i)
            Next i
            dSlope = (Sxy / n - avx * avy) / (Sx2 / n - avx * avx)
            dConstant = avy - dSlope * avx

            For i = 1 To iHorizon
                dForecasts(i) = dConstant + dSlope * (n + i)
            Next i

            ExponentialSmoothing_Simple_Trend = True

        Catch ex As Exception

            sErrorMessage = ex.Message
            ExponentialSmoothing_Simple_Trend = False

        Finally

        End Try

    End Function

    '************************************************************************************************************************************************************************************
    'HOLT 
    '************************************************************************************************************************************************************************************
    Public Shared Function ExponentialSmoothing_Holt(ByRef dData() As Double,
                                                                                                    ByRef iTime() As Double,
                                                                                                    ByVal iHorizon As Integer,
                                                                                                    ByVal aSmoothingParameter As Double,
                                                                                                    ByVal bSmoothingParameter As Double,
                                                                                                    ByVal sMethodFirstPoint As String,
                                                                                                    ByRef dForecasts() As Double,
                                                                                                    ByRef sErrorMessage As String) As Boolean
        Dim n As Integer
        Dim S() As Double
        Dim T() As Double
        Dim F() As Double
        Dim E() As Double

        Dim dLevel As Double = 0
        Dim dSlope As Double = 0


        Try

            'define n
            ReDim dForecasts(iHorizon)
            n = UBound(dData)

            'Step1. Initialize the first value
            ReDim S(n)
            ReDim T(n)
            ReDim F(n)
            ReDim E(n)
            Select Case sMethodFirstPoint
                Case "A"
                    'average of all historical data 
                    S(0) = clsCommonMath.SumOfArray(dData) / n
                    T(0) = (dData(n) - dData(1)) / (n - 1)
                Case "M"
                    'mean of first 4 historical data
                    If n >= 4 Then
                        S(0) = (dData(1) + dData(2) + dData(3) + dData(4)) / 4
                        T(0) = (dData(4) - dData(1)) / 3
                    Else
                        S(0) = (dData(1) + dData(2)) / 2
                        T(0) = dData(2) - dData(1)
                    End If
                Case "F"
                    'the first historical data
                    S(0) = dData(1)
                    T(0) = dData(2) - dData(1)
                Case "L"
                    'the Level for the model of Linear Regression
                    clsForecast_Tools.ReturnLevelSlope_SimpleLinearRegression(dData, dLevel, dSlope, sErrorMessage)
                    S(0) = dLevel
                    T(0) = dSlope
                Case Else
                    S(0) = dData(1)
                    T(0) = dData(2) - dData(1)
            End Select

            'Step2.
            For i = 1 To n
                'forecast
                F(i) = S(i - 1) + T(i - 1)
                'error
                E(i) = dData(i) - F(i)
                'T component
                T(i) = T(i - 1) + (bSmoothingParameter * E(i))
                's component
                S(i) = S(i - 1) + T(i - 1) + aSmoothingParameter * E(i)
            Next i

            'Step3. Forecasts
            For i = 1 To iHorizon
                dForecasts(i) = S(n) + (i - 1) * T(n)
            Next i

            ExponentialSmoothing_Holt = True

        Catch ex As Exception

            sErrorMessage = ex.Message
            ExponentialSmoothing_Holt = False

        Finally

        End Try




    End Function

    '************************************************************************************************************************************************************************************
    'DAMPED 
    '************************************************************************************************************************************************************************************
    Public Shared Function ExponentialSmoothing_Damped(ByRef dData() As Double,
                                                                                                    ByRef iTime() As Double,
                                                                                                    ByVal iHorizon As Integer,
                                                                                                    ByVal aSmoothingParameter As Double,
                                                                                                    ByVal bSmoothingParameter As Double,
                                                                                                    ByVal fSmoothingParameter As Double,
                                                                                                    ByVal sMethodFirstPoint As String,
                                                                                                    ByRef dForecasts() As Double,
                                                                                                    ByRef sErrorMessage As String) As Boolean
        Dim n As Integer
        Dim S() As Double
        Dim T() As Double
        Dim F() As Double
        Dim E() As Double

        Dim dLevel As Double = 0
        Dim dSlope As Double = 0


        Try

            'define n
            ReDim dForecasts(iHorizon)
            n = UBound(dData)

            'Step1. Initialize the first value
            ReDim S(n)
            ReDim T(n)
            ReDim F(n)
            ReDim E(n)
            Select Case sMethodFirstPoint
                Case "A"
                    'average of all historical data 
                    S(0) = clsCommonMath.SumOfArray(dData) / n
                    T(0) = (dData(n) - dData(1)) / (n - 1)
                Case "M"
                    'mean of first 4 historical data
                    If n >= 4 Then
                        S(0) = (dData(1) + dData(2) + dData(3) + dData(4)) / 4
                        T(0) = (dData(4) - dData(1)) / 3
                    Else
                        S(0) = (dData(1) + dData(2)) / 2
                        T(0) = dData(2) - dData(1)
                    End If
                Case "F"
                    'the first historical data
                    S(0) = dData(1)
                    T(0) = dData(2) - dData(1)
                Case "L"
                    'the Level for the model of Linear Regression
                    clsForecast_Tools.ReturnLevelSlope_SimpleLinearRegression(dData, dLevel, dSlope, sErrorMessage)
                    S(0) = dLevel
                    T(0) = dSlope
                Case Else
                    S(0) = dData(1)
                    T(0) = dData(2) - dData(1)
            End Select

            'Step2.
            For i = 1 To n
                'forecast
                F(i) = S(i - 1) + (fSmoothingParameter * T(i - 1))
                'error
                E(i) = dData(i) - F(i)
                'T component
                T(i) = (fSmoothingParameter * T(i - 1)) + (bSmoothingParameter * E(i))
                's component
                S(i) = S(i - 1) + (fSmoothingParameter * T(i - 1)) + aSmoothingParameter * E(i)
            Next i

            'Step3. Forecasts
            For i = 1 To iHorizon
                dForecasts(i) = S(n) + (i - 1) * T(n)
            Next i

            ExponentialSmoothing_Damped = True

        Catch ex As Exception

            sErrorMessage = ex.Message
            ExponentialSmoothing_Damped = False

        Finally

        End Try




    End Function

    '************************************************************************************************************************************************************************************
    'ARIMA
    '************************************************************************************************************************************************************************************
    Public Shared Function ARIMA(ByRef dData() As Double,
                                                            ByRef dForecasts() As Double,
                                                            ByVal iHorizon As Integer,
                                                            ByVal ar As Short,
                                                            ByVal i As Short,
                                                            ByVal ma As Short) As Boolean

        Dim aphi() As Double
        Dim atheta() As Double
        Dim fy() As Double
        Dim j As Integer
        Dim mesiTimi As Double

        On Error GoTo ErrTrap

        '1. Áöáßñåóç ôçí ìÝóç ôéìÞ ôçò ÷ñïíïóåéñÜò
        mesiTimi = clsCommonMath.MeanOfArray(dData)
        For j = 1 To UBound(dData)
            dData(j) = dData(j) - mesiTimi
        Next j

        '2 ÊÜëåóå ôï arima
        ReDim fy(UBound(dForecasts))
        clsForecast_Tools.Method_ARIMA(dData, ar, i, ma, CInt(iHorizon), aphi, atheta, fy)

        For j = 1 To iHorizon
            dForecasts(j) = fy(j)
        Next j

        ARIMA = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        ARIMA = False

CleanExit:

    End Function

    '************************************************************************************************************************************************************************************
    ' CLASSICAL DECOMPOSITION MULTIPLICATIVE
    '************************************************************************************************************************************************************************************
    Public Shared Function Decomposition_Mutliplicative_Classical(ByRef dData() As Double,
                                                                                            ByRef iTime() As Double,
                                                                                            ByVal iHorizon As Integer,
                                                                                            ByRef dForecasts() As Double,
                                                                                            ByVal bDisplayMessage As Boolean) As Boolean
        'Classical Decomposition
        Dim i As Short
        Dim n As Short
        Dim Sx As Double
        Dim Sxy As Double
        Dim avx As Double
        Dim avy As Double
        Dim Sx2 As Double
        Dim CMA3() As Double
        Dim CMA3X3() As Double
        Dim R() As Double
        Dim T() As Double
        Dim C() As Double
        Dim dSlope As Double
        Dim dConstant As Double

        Dim Tcomp As Double
        Dim Ccomp As Double

        On Error GoTo ErrTrap

        'Initializations
        ReDim dForecasts(iHorizon)

        'NOTE --> Since the data are already without seasonality, we have only Trend, Cycle and Random components

        'Main
        If UBound(iTime) = UBound(dData) Then

            'Step 5: Calculate the Trend-Cycle component 
            'That can be achieved, by using the CMA (Central Moving Average) 3x3.
            ReDim CMA3(UBound(dData))
            For i = 2 To UBound(dData) - 1
                CMA3(i) = (dData(i - 1) + dData(i) + dData(i + 1)) / 3
            Next i

            ReDim CMA3X3(UBound(dData))
            CMA3X3(1) = ((dData(1) + dData(2)) / 2) + ((CMA3(2) - CMA3(3)) / 2)
            CMA3X3(2) = CMA3(2)
            For i = 3 To UBound(dData) - 2
                CMA3X3(i) = (CMA3(i - 1) + CMA3(i) + CMA3(i + 1)) / 3
            Next i
            CMA3X3(UBound(dData) - 1) = CMA3(UBound(dData) - 1)
            CMA3X3(UBound(dData)) = ((dData(UBound(dData)) + dData(UBound(dData) - 1)) / 2) + ((CMA3(UBound(dData) - 1) - CMA3(UBound(dData) - 2)) / 2)

            'Step 6: Isolation of the Random Component (optional) --> by dividing the two timeseries
            ReDim R(UBound(dData))
            For i = 1 To UBound(dData)
                R(i) = dData(i) / CMA3X3(i)
            Next i

            'Step 7: Split Trend and Cycle components
            n = UBound(dData)
            avx = clsCommonMath.MeanOfArray(iTime)
            avy = clsCommonMath.MeanOfArray(CMA3X3)
            clsForecast_Tools.SumsAndSquares(iTime, Sx, Sx2)
            Sxy = 0
            For i = 1 To UBound(dData)
                Sxy = Sxy + iTime(i) * CMA3X3(i)
            Next i
            dSlope = (Sxy / n - avx * avy) / (Sx2 / n - avx * avx)
            dConstant = avy - dSlope * avx

            ReDim T(UBound(dData))
            ReDim C(UBound(dData))
            For i = 1 To UBound(dData)
                T(i) = dConstant + dSlope * iTime(i)
                C(i) = CMA3X3(i) / T(i)
            Next i

            'Step Forecast: Estimate Forecast based on Decomposition results
            'Ccomp = clsCommonMath.MeanOfArray(C)
            'Ccomp = (clsCommonMath.SumOfArray(C) - clsCommonMath.Return_Max_FromArray(C, 1, sErrorMessage) - clsCommonMath.Return_Min_FromArray(C, 1, sErrorMessage)) / (UBound(C) - 2)
            If iHorizon <> 8 Then
                Ccomp = clsCommonMath.MeanOfArray(C)
            Else
                Ccomp = (C(UBound(dData) - 2) + C(UBound(dData) - 1) + C(UBound(dData))) / 3
            End If

            For i = 1 To iHorizon
                Tcomp = dConstant + dSlope * (n + i)
                dForecasts(i) = Tcomp * Ccomp
            Next i
        Else
            For i = 1 To 12
                dForecasts(i) = -1
            Next i
            GoTo ErrTrap
        End If

        Decomposition_Mutliplicative_Classical = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        Decomposition_Mutliplicative_Classical = False

CleanExit:

    End Function

    Public Shared Function Decomposition_Mutliplicative_SpecialMovingAverage(ByRef dData() As Double,
                                                                                            ByRef iTime() As Double,
                                                                                            ByVal iHorizon As Integer,
                                                                                            ByVal sTypeMA As String,
                                                                                            ByVal iParameter As Integer,
                                                                                            ByRef dForecasts() As Double,
                                                                                            ByRef sErrorMessage As String) As Boolean
        'Classical Decomposition
        Dim i As Short
        Dim n As Short
        Dim Sx As Double
        Dim Sxy As Double
        Dim avx As Double
        Dim avy As Double
        Dim Sx2 As Double
        Dim CMA() As Double
        Dim R() As Double
        Dim T() As Double
        Dim C() As Double
        Dim dSlope As Double
        Dim dConstant As Double

        Dim Tcomp As Double
        Dim Ccomp As Double

        Dim iPointsMissingStart As Integer
        Dim iPointsMissingEnd As Integer

        On Error GoTo ErrTrap

        'Initializations
        ReDim dForecasts(iHorizon)

        'NOTE --> Since the data are already without seasonality, we have only Trend, Cycle and Random components


        'Step 5: Calculate the Trend-Cycle component 
        ReDim CMA(UBound(dData))
        If sTypeMA = "S" Then
            clsForecast_Tools.MA_SimpleN_Backstaging(dData, iParameter, CMA, sErrorMessage)
        ElseIf sTypeMA = "W" Then
            clsForecast_Tools.MA_WeightedN_Backstaging(dData, iParameter, CMA, sErrorMessage)
        ElseIf sTypeMA = "D" Then
            clsForecast_Tools.MA_DoubleN_Backstaging(dData, iParameter, CMA, sErrorMessage)
        End If


        'Step 6: Isolation of the Random Component (optional) --> by dividing the two timeseries
        ReDim R(UBound(dData))
        For i = 1 To UBound(dData)
            R(i) = dData(i) / CMA(i)
        Next i

        'Step 7: Split Trend and Cycle components
        n = UBound(dData)
        avx = clsCommonMath.MeanOfArray(iTime)
        avy = clsCommonMath.MeanOfArray(CMA)
        clsForecast_Tools.SumsAndSquares(iTime, Sx, Sx2)
        Sxy = 0
        For i = 1 To UBound(dData)
            Sxy = Sxy + iTime(i) * CMA(i)
        Next i
        dSlope = (Sxy / n - avx * avy) / (Sx2 / n - avx * avx)
        dConstant = avy - dSlope * avx

        ReDim T(UBound(dData))
        ReDim C(UBound(dData))
        For i = 1 To UBound(dData)
            T(i) = dConstant + dSlope * iTime(i)
            C(i) = CMA(i) / T(i)
        Next i

        'Step Forecast: Estimate Forecast based on Decomposition results
        'Ccomp = clsCommonMath.MeanOfArray(C)
        'Ccomp = (clsCommonMath.SumOfArray(C) - clsCommonMath.Return_Max_FromArray(C, 1, sErrorMessage) - clsCommonMath.Return_Min_FromArray(C, 1, sErrorMessage)) / (UBound(C) - 2)
        If iHorizon <> 8 Then
            Ccomp = clsCommonMath.MeanOfArray(C)
        Else
            Ccomp = (C(UBound(dData) - 2) + C(UBound(dData) - 1) + C(UBound(dData))) / 3
        End If
        For i = 1 To iHorizon
            Tcomp = dConstant + dSlope * (n + i)
            dForecasts(i) = Tcomp * Ccomp
        Next i

        Decomposition_Mutliplicative_SpecialMovingAverage = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        Decomposition_Mutliplicative_SpecialMovingAverage = False

CleanExit:

    End Function

    '************************************************************************************************************************************************************************************
    ' CLASSICAL DECOMPOSITION ADDITIVE
    '************************************************************************************************************************************************************************************
    Public Shared Function Decomposition_Additive_Classical(ByRef dData() As Double,
                                                                                            ByRef iTime() As Double,
                                                                                            ByVal iHorizon As Integer,
                                                                                            ByRef dForecasts() As Double,
                                                                                            ByVal bDisplayMessage As Boolean) As Boolean
        'Classical Decomposition
        Dim i As Short
        Dim n As Short
        Dim Sx As Double
        Dim Sxy As Double
        Dim avx As Double
        Dim avy As Double
        Dim Sx2 As Double
        Dim CMA3() As Double
        Dim CMA3X3() As Double
        Dim R() As Double
        Dim T() As Double
        Dim C() As Double
        Dim dSlope As Double
        Dim dConstant As Double

        Dim Tcomp As Double
        Dim Ccomp As Double

        On Error GoTo ErrTrap

        'Initializations
        ReDim dForecasts(iHorizon)

        'NOTE --> Since the data are already without seasonality, we have only Trend, Cycle and Random components

        'Main
        If UBound(iTime) = UBound(dData) Then

            'Step 5 Calculate the Trend-Cycle component 
            'That can be achieved, by using the CMA (Central Moving Average) 3x3.
            ReDim CMA3(UBound(dData))
            For i = 2 To UBound(dData) - 1
                CMA3(i) = (dData(i - 1) + dData(i) + dData(i + 1)) / 3
            Next i

            ReDim CMA3X3(UBound(dData))
            CMA3X3(1) = ((dData(1) + dData(2)) / 2) + ((CMA3(2) - CMA3(3)) / 2)
            CMA3X3(2) = CMA3(2)
            For i = 3 To UBound(dData) - 2
                CMA3X3(i) = (CMA3(i - 1) + CMA3(i) + CMA3(i + 1)) / 3
            Next i
            CMA3X3(UBound(dData) - 1) = CMA3(UBound(dData) - 1)
            CMA3X3(UBound(dData)) = ((dData(UBound(dData)) + dData(UBound(dData) - 1)) / 2) + ((CMA3(UBound(dData) - 1) - CMA3(UBound(dData) - 2)) / 2)

            'Step 6: Isolation of the Random Component (optional) --> by dividing the two timeseries
            ReDim R(UBound(dData))
            For i = 1 To UBound(dData)
                R(i) = dData(i) - CMA3X3(i)
            Next i

            ''Step 7: Split Trend and Cycle components
            n = UBound(dData)
            avx = clsCommonMath.MeanOfArray(iTime)
            avy = clsCommonMath.MeanOfArray(CMA3X3)
            clsForecast_Tools.SumsAndSquares(iTime, Sx, Sx2)
            Sxy = 0
            For i = 1 To UBound(dData)
                Sxy = Sxy + iTime(i) * CMA3X3(i)
            Next i
            dSlope = (Sxy / n - avx * avy) / (Sx2 / n - avx * avx)
            dConstant = avy - dSlope * avx

            ReDim T(UBound(dData))
            ReDim C(UBound(dData))
            For i = 1 To UBound(dData)
                T(i) = dConstant + dSlope * iTime(i)
                C(i) = CMA3X3(i) - T(i)
            Next i

            'Step Forecast: Estimate Forecast based on Decomposition results
            Ccomp = clsCommonMath.MeanOfArray(C)
            For i = 1 To iHorizon
                Tcomp = dConstant + dSlope * (n + i)
                dForecasts(i) = Tcomp + Ccomp
            Next i
        Else
            For i = 1 To 12
                dForecasts(i) = -1
            Next i
            GoTo ErrTrap
        End If



        Decomposition_Additive_Classical = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        Decomposition_Additive_Classical = False

CleanExit:

    End Function

    Public Shared Function Decomposition_Additive_SpecialMovingAverage(ByRef dData() As Double,
                                                                                            ByRef iTime() As Double,
                                                                                            ByVal iHorizon As Integer,
                                                                                            ByVal sTypeMA As String,
                                                                                            ByVal iParameter As Integer,
                                                                                            ByRef dForecasts() As Double,
                                                                                            ByRef sErrorMessage As String) As Boolean
        'Classical Decomposition
        Dim i As Short
        Dim n As Short
        Dim Sx As Double
        Dim Sxy As Double
        Dim avx As Double
        Dim avy As Double
        Dim Sx2 As Double
        Dim CMA() As Double
        Dim R() As Double
        Dim T() As Double
        Dim C() As Double
        Dim dSlope As Double
        Dim dConstant As Double

        Dim Tcomp As Double
        Dim Ccomp As Double

        Dim iPointsMissingStart As Integer
        Dim iPointsMissingEnd As Integer

        On Error GoTo ErrTrap

        'Initializations
        ReDim dForecasts(iHorizon)

        'NOTE --> Since the data are already without seasonality, we have only Trend, Cycle and Random components


        'Step 5 Calculate the Trend-Cycle component 
        'That can be achieved, by using the CMA (Central Moving Average) 3x3.
        ReDim CMA(UBound(dData))
        If sTypeMA = "S" Then
            clsForecast_Tools.MA_SimpleN_Backstaging(dData, iParameter, CMA, sErrorMessage)
        ElseIf sTypeMA = "W" Then
            clsForecast_Tools.MA_WeightedN_Backstaging(dData, iParameter, CMA, sErrorMessage)
        ElseIf sTypeMA = "D" Then
            clsForecast_Tools.MA_DoubleN_Backstaging(dData, iParameter, CMA, sErrorMessage)
        End If

        'Step 6: Isolation of the Random Component (optional) --> by dividing the two timeseries
        ReDim R(UBound(dData))
        For i = 1 To UBound(dData)
            R(i) = dData(i) - CMA(i)
        Next i

        ''Step 7: Split Trend and Cycle components
        n = UBound(dData)
        avx = clsCommonMath.MeanOfArray(iTime)
        avy = clsCommonMath.MeanOfArray(CMA)
        clsForecast_Tools.SumsAndSquares(iTime, Sx, Sx2)
        Sxy = 0
        For i = 1 To UBound(dData)
            Sxy = Sxy + iTime(i) * CMA(i)
        Next i
        dSlope = (Sxy / n - avx * avy) / (Sx2 / n - avx * avx)
        dConstant = avy - dSlope * avx

        ReDim T(UBound(dData))
        ReDim C(UBound(dData))
        For i = 1 To UBound(dData)
            T(i) = dConstant + dSlope * iTime(i)
            C(i) = CMA(i) - T(i)
        Next i

        'Step Forecast: Estimate Forecast based on Decomposition results
        Ccomp = clsCommonMath.MeanOfArray(C)
        For i = 1 To iHorizon
            Tcomp = dConstant + dSlope * (n + i)
            dForecasts(i) = Tcomp + Ccomp
        Next i


        Decomposition_Additive_SpecialMovingAverage = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        Decomposition_Additive_SpecialMovingAverage = False

CleanExit:

    End Function

    '***************************************************************************************
    ' Moving Average Method  - SimpleN
    '***************************************************************************************
    Public Shared Function MovingAverage_SimpleN(ByRef dData() As Double,
                                                                                            ByVal iHorizon As Integer,
                                                                                            ByVal iParameter As Integer,
                                                                                            ByRef dForecasts() As Double,
                                                                                            ByRef sErrorMessage As String) As Boolean
        Dim i As Integer
        Dim n As Integer
        Dim MA() As Double
        Dim iPointsMissingStart As Integer
        Dim iPointsMissingEnd As Integer

        On Error GoTo ErrTrap

        'Áñ÷éêïðïßçóç
        ReDim dForecasts(iHorizon)
        n = UBound(dData)

        'MA
        ReDim MA(n)
        clsForecast_Tools.MA_SimpleN(dData, iParameter, MA, iPointsMissingStart, iPointsMissingEnd, sErrorMessage)

        'estimte forecasts
        For i = 1 To iHorizon
            dForecasts(i) = MA(n - iPointsMissingEnd)
        Next i

        MovingAverage_SimpleN = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        MovingAverage_SimpleN = False

CleanExit:

    End Function

    '***************************************************************************************
    ' Moving Average Method  - SimpleN with Backstaging
    '***************************************************************************************
    Public Shared Function MovingAverage_SimpleN_Backstaging(ByRef dData() As Double,
                                                                                                                    ByVal iHorizon As Integer,
                                                                                                                    ByVal iParameter As Integer,
                                                                                                                    ByRef dForecasts() As Double,
                                                                                                                    ByRef sErrorMessage As String) As Boolean
        Dim i As Integer
        Dim n As Integer
        Dim MA() As Double

        On Error GoTo ErrTrap

        'Áñ÷éêïðïßçóç
        ReDim dForecasts(iHorizon)
        n = UBound(dData)

        'estimate the MA(N)
        ReDim MA(n)
        clsForecast_Tools.MA_SimpleN_Backstaging(dData, iParameter, MA, sErrorMessage)

        'estimte forecasts
        For i = 1 To iHorizon
            dForecasts(i) = MA(n)
        Next i

        MovingAverage_SimpleN_Backstaging = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        MovingAverage_SimpleN_Backstaging = False

CleanExit:

    End Function

    '***************************************************************************************
    ' Moving Average Method  - WeightedN
    '***************************************************************************************
    Public Shared Function MovingAverage_WeightedN(ByRef dData() As Double,
                                                                                            ByVal iHorizon As Integer,
                                                                                            ByVal iParameter As Integer,
                                                                                            ByRef dForecasts() As Double,
                                                                                            ByRef sErrorMessage As String) As Boolean
        Dim i As Integer
        Dim n As Integer
        Dim MA() As Double
        Dim iPointsMissingStart As Integer
        Dim iPointsMissingEnd As Integer

        On Error GoTo ErrTrap

        'Áñ÷éêïðïßçóç
        ReDim dForecasts(iHorizon)
        n = UBound(dData)

        'estimate the MA(N)
        ReDim MA(n)
        clsForecast_Tools.MA_WeightedN(dData, iParameter, MA, iPointsMissingStart, iPointsMissingEnd, sErrorMessage)

        'estimte forecasts
        For i = 1 To iHorizon
            dForecasts(i) = MA(n - iPointsMissingEnd)
        Next i

        MovingAverage_WeightedN = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        MovingAverage_WeightedN = False
        Resume

CleanExit:

    End Function

    '***************************************************************************************
    ' Moving Average Method  - WeightedN with Backstage
    '***************************************************************************************
    Public Shared Function MovingAverage_WeightedN_Backstaging(ByRef dData() As Double,
                                                                                            ByVal iHorizon As Integer,
                                                                                            ByVal iParameter As Integer,
                                                                                            ByRef dForecasts() As Double,
                                                                                            ByRef sErrorMessage As String) As Boolean
        Dim i As Integer
        Dim n As Integer
        Dim MA() As Double

        On Error GoTo ErrTrap

        'Áñ÷éêïðïßçóç
        ReDim dForecasts(iHorizon)
        n = UBound(dData)

        'estimate the MA(N)
        ReDim MA(n)
        clsForecast_Tools.MA_WeightedN_Backstaging(dData, iParameter, MA, sErrorMessage)

        'estimte forecasts
        For i = 1 To iHorizon
            dForecasts(i) = MA(n)
        Next i

        MovingAverage_WeightedN_Backstaging = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        MovingAverage_WeightedN_Backstaging = False
        Resume

CleanExit:

    End Function

    '***************************************************************************************
    ' Moving Average Method  - DoubleN
    '***************************************************************************************
    Public Shared Function MovingAverage_DoubleN(ByRef dData() As Double,
                                                                                            ByVal iHorizon As Integer,
                                                                                            ByVal iParameter As Integer,
                                                                                            ByRef dForecasts() As Double,
                                                                                            ByRef sErrorMessage As String) As Boolean
        Dim i As Integer
        Dim n As Integer
        Dim MA() As Double
        Dim iPointsMissingStart As Integer
        Dim iPointsMissingEnd As Integer

        On Error GoTo ErrTrap

        'Áñ÷éêïðïßçóç
        ReDim dForecasts(iHorizon)
        n = UBound(dData)

        'MA
        ReDim MA(n)
        clsForecast_Tools.MA_DoubleN(dData, iParameter, MA, iPointsMissingStart, iPointsMissingEnd, sErrorMessage)


        'estimte forecasts
        For i = 1 To iHorizon
            dForecasts(i) = MA(n - iPointsMissingEnd)
        Next i

        MovingAverage_DoubleN = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        MovingAverage_DoubleN = False

CleanExit:

    End Function

    '***************************************************************************************
    ' Moving Average Method  - WeightedN with Backstage
    '***************************************************************************************
    Public Shared Function MovingAverage_DoubleN_Backstaging(ByRef dData() As Double,
                                                                                            ByVal iHorizon As Integer,
                                                                                            ByVal iParameter As Integer,
                                                                                            ByRef dForecasts() As Double,
                                                                                            ByRef sErrorMessage As String) As Boolean
        Dim i As Integer
        Dim n As Integer
        Dim MA() As Double

        On Error GoTo ErrTrap

        'Áñ÷éêïðïßçóç
        ReDim dForecasts(iHorizon)
        n = UBound(dData)

        'estimate the MA(N)
        ReDim MA(n)
        clsForecast_Tools.MA_DoubleN_Backstaging(dData, iParameter, MA, sErrorMessage)

        'estimte forecasts
        For i = 1 To iHorizon
            dForecasts(i) = MA(n)
        Next i

        MovingAverage_DoubleN_Backstaging = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        MovingAverage_DoubleN_Backstaging = False
        Resume

CleanExit:

    End Function

    '************************************************************************************************************************************************************************************
    'THETA method
    '************************************************************************************************************************************************************************************
    Public Shared Function THETA(ByRef dData() As Double,
                                                            ByRef iTime() As Double,
                                                            ByVal iHorizon As Integer,
                                                            ByVal dThetaParameter As Double,
                                                            ByVal aSmoothingParameter As Double,
                                                            ByVal sMethodFirstPoint As String,
                                                            ByRef dForecasts() As Double,
                                                            ByRef sErrorMessage As String) As Boolean
        'Dim i As Short
        ' Dim dEksomalinsi As Double
        ' Dim dMedian As Double

        Dim n As Integer
        Dim dDataPartA() As Double
        Dim dDataPartB() As Double

        Dim dLevel As Double
        Dim dSlope As Double

        Dim dForecastsPartA() As Double
        Dim dForecastsPartB() As Double

        Dim sErrorMessagePartA As String = String.Empty
        Dim sErrorMessagePartB As String = String.Empty

        Try

            'initialize
            n = UBound(dData)
            ReDim dForecasts(iHorizon)
            ReDim dForecastsPartA(iHorizon)
            ReDim dForecastsPartB(iHorizon)

            ReDim dDataPartA(n)
            ReDim dDataPartB(n)

            'The timeserie is decomposed into two Theta lines, example for θ=0 and θ=2
            'THETA Line(Θ) = (Θ * Data) + (1 - Θ) * LRL 
            'A. Linear Regression
            clsForecast_Tools.ReturnLevelSlope_SimpleLinearRegression(dData, dLevel, dSlope, sErrorMessage)
            For i = 1 To n
                dDataPartA(i) = dLevel + (dSlope * i)
            Next i
            'B. The rest
            For i = 1 To n
                dDataPartB(i) = (dThetaParameter * dData(i)) + ((1 - dThetaParameter) * dDataPartA(i))
            Next i

            'Partial forecasts
            'Part A
            clsForecast_Methods.LinearRegression_Simple(dDataPartA, iTime, iHorizon, dForecastsPartA, sErrorMessage)
            'Part B
            clsForecast_Methods.ExponentialSmoothing_Simple(dDataPartB, iHorizon, aSmoothingParameter, sMethodFirstPoint, dForecastsPartB, sErrorMessage)

            'Add forecasts
            For i = 1 To iHorizon
                dForecasts(i) = ((dForecastsPartB(i)) - ((1 - dThetaParameter) * dForecastsPartA(i))) / dThetaParameter
            Next i

            THETA = True

        Catch ex As Exception
            sErrorMessage = ex.Message
            THETA = False
        Finally

        End Try

    End Function

    '************************************************************************************************************************************************************************************
    'EXPERT
    '************************************************************************************************************************************************************************************
    Public Shared Function Expert(ByRef dData() As Double,
                                                            ByRef dTime() As Double,
                                                            ByVal iHoldout As Integer,
                                                            ByVal iHorizon As Integer,
                                                            ByRef dForecasts() As Double,
                                                            Optional ByVal bDisplayMessage As Boolean = False) As Boolean
        Dim newData() As Double
        Dim newTime() As Double
        Dim dForecasts1() As Double
        Dim dForecasts2() As Double
        Dim dErrors() As Double
        Dim dSum As Double
        Dim lSize As Integer
        Dim dMinimumError As Double
        Dim iBestMethod As Short
        Dim i As Integer
        Dim dConstant As Double
        Dim dSlope As Double
        Dim forec As Double
        Dim actual As Double

        On Error GoTo ErrTrap

        'ÊÏØÅ ÔÁ ÄÅÄÏÌÅÍÁ ÃÉÁ ÍÁ Å×ÏÕÌÅ ÃÉÁ ÓÕÃÊÑÉÓÇ ÌÅ ÔÉÓ ÐÑÏÂËÅØÅÉÓ
        lSize = UBound(dData) - iHorizon

        'Eåëåã÷ïò ÄåäïìÝíùí
        If lSize < 1 Then
            If bDisplayMessage = True Then
                'MsgBox("ÁíåðáñêÞò áñéèìüò äåäïìÝíùí ãéá ðñüâëåøç!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ÓöÜëìá Ðñüâëåøçò")
            End If
            GoTo ErrTrap
        End If

        ReDim newData(lSize)
        ReDim newTime(lSize)

        For i = 1 To lSize
            newData(i) = dData(i)
            newTime(i) = dTime(i)
        Next i

        'ÕÐÏËÏÃÉÓÅ ÐÑÏÂËÅØÅÉÓ ÌÅ ÔÇÍ SIMPLE
        ReDim dForecasts1(iHorizon)
        'SimpleExponentialSmoothing(newData, iHorizon, dForecasts1, bDisplayMessage)

        'ÕÐÏËÏÃÉÓÅ ÐÑÏÂËÅØÅÉÓ ÌÅ ÔÇÍ REGRESSION
        ReDim dForecasts2(iHorizon)
        'SimpleLinearRegression(newData, newTime, iHorizon, dConstant, dSlope, dForecasts2, bDisplayMessage)

        'ÕÐÏËÏÃÉÓÅ ÔÁ ÓÖÁËÌÁÔÁ ÊÁÉ ÌÅ ÔÉÓ 3 ÌEÈÏÄÏÕÓ
        ReDim dErrors(3)
        '1
        dSum = 0
        For i = 1 To iHorizon
            forec = (dForecasts1(i) * 0.5) + (dForecasts2(i) * 0.5)
            actual = dData(UBound(dData) - iHorizon + i)
            dSum = dSum + (forec - actual) ^ 2
        Next i
        dErrors(1) = dSum / iHorizon
        '2
        dSum = 0
        For i = 1 To iHorizon
            forec = (dForecasts1(i) * 0.25) + (dForecasts2(i) * 0.75)
            actual = dData(UBound(dData) - iHorizon + i)
            dSum = dSum + (forec - actual) ^ 2
        Next i
        dErrors(2) = dSum / iHorizon
        '3
        dSum = 0
        For i = 1 To iHorizon
            forec = (dForecasts1(i) * 0.75) + (dForecasts2(i) * 0.25)
            actual = dData(UBound(dData) - iHorizon + i)
            dSum = dSum + (forec - actual) ^ 2
        Next i
        dErrors(3) = dSum / iHorizon

        'ÂÑÅÓ ÐÏÉÁ ÌÅÈÏÄÏÓ ÐÑÏÂÉÂÁÆÅÔÁÉ
        dMinimumError = dErrors(1)
        iBestMethod = 1
        For i = 2 To 3
            If dErrors(i) < dMinimumError Then
                dMinimumError = dErrors(i)
                iBestMethod = i
            End If
        Next i

        'ÊÁÍÅ ÐÑÏÂËÅØÇ ÌÅ ÔÇÍ ÊÁËÕÔÅÑÇ ÌÅÈÏÄÏ

        'ÕÐÏËÏÃÉÓÅ ÐÑÏÂËÅØÅÉÓ ÌÅ ÔÇÍ SIMPLE
        ReDim dForecasts1(iHorizon)
        'SimpleExponentialSmoothing(dData, iHorizon, dForecasts1, bDisplayMessage)

        'ÕÐÏËÏÃÉÓÅ ÐÑÏÂËÅØÅÉÓ ÌÅ ÔÇÍ REGRESSION
        ReDim dForecasts2(iHorizon)
        'SimpleLinearRegression(dData, dTime, iHorizon, dConstant, dSlope, dForecasts2, bDisplayMessage)

        'ÔÅËÉÊÅÓ ÐÑÏÂËÅØÅÉÓ
        ReDim dForecasts(iHorizon)
        Select Case iBestMethod
            Case 1
                For i = 1 To iHorizon
                    dForecasts(i) = (dForecasts1(i) * 0.5) + (dForecasts2(i) * 0.5)
                Next i
            Case 2
                For i = 1 To iHorizon
                    dForecasts(i) = (dForecasts1(i) * 0.25) + (dForecasts2(i) * 0.75)
                Next i
            Case 3
                For i = 1 To iHorizon
                    dForecasts(i) = (dForecasts1(i) * 0.75) + (dForecasts2(i) * 0.25)
                Next i
        End Select

        Expert = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        Expert = False

CleanExit:

    End Function


    '***************************************************************************************
    ' NOT USED --> OLD Algorithms
    '***************************************************************************************

    '***************************************************************************************
    ' Moving Average Mathod 1
    '***************************************************************************************
    Public Shared Function Z_OLD_MovingAverage_1(ByRef dData() As Double,
                                                                                ByVal iHorizon As Integer,
                                                                                ByVal iParameter As Integer,
                                                                                ByRef dForecasts() As Double,
                                                                                ByVal bDisplayMessage As Boolean) As Boolean
        'SOS: Ç ÈÅÓÇ ÌÇÄÅÍ ÓÔÏÕÓ ÐÉÍÁÊÅÓ ÄÅÍ ×ÑÇÓÉÌÏÐÏÉÅÉÔÁ
        Dim i As Integer
        Dim j As Integer
        Dim n As Integer
        Dim s As Double

        On Error GoTo ErrTrap

        'Áñ÷éêïðïßçóç
        ReDim dForecasts(iHorizon)
        n = UBound(dData)
        If n < iParameter Then
            If bDisplayMessage = True Then
                MsgBox("FIS_MovingAverageMethod_NLessThanParam")
                Exit Function
            End If
        End If

        For i = 1 To iHorizon
            s = 0
            For j = 1 To iParameter
                If ((n + i - 1 - iParameter + j) <= n) Then
                    s = s + dData(n + i - 1 - iParameter + j)
                Else
                    s = s + dForecasts(i - (iParameter - j + 1))
                End If
            Next j
            dForecasts(i) = s / iParameter
        Next i

        Z_OLD_MovingAverage_1 = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        Z_OLD_MovingAverage_1 = False

CleanExit:

    End Function

    '************************************************************************************************************************************************************************************
    'MOVING AVERAGE METHOD 2
    '************************************************************************************************************************************************************************************
    Public Shared Function Z_OLD_MovingAverage_2(ByRef dData() As Double,
                                                                                ByVal iHorizon As Integer,
                                                                                ByVal iParameter As Integer,
                                                                                ByRef dForecasts() As Double,
                                                                                ByVal bDisplayMessage As Boolean) As Boolean
        ' Moving Average Mathod 1
        Dim j, i, n As Short
        Dim a, s, b As Double
        Dim s1() As Double
        Dim s2() As Double

        On Error GoTo ErrTrap

        'Áñ÷éêïðïßçóç
        ReDim dForecasts(iHorizon)
        n = UBound(dData)
        If n < iParameter + iParameter Then
            If bDisplayMessage = True Then
                MsgBox("FIS_MovingAverageMethod_NLessThanParam")
                Exit Function
            End If
        End If
        ReDim s1(n)
        ReDim s2(n)

        '1oò ìÝóïò üñïò
        For i = iParameter To n
            s = 0
            For j = 1 To iParameter
                s = s + dData(i - j + 1)
            Next j
            s1(i) = s / iParameter
        Next i

        '2oò ìÝóïò üñïò
        For i = iParameter + iParameter - 1 To n
            s = 0
            For j = 1 To iParameter
                s = s + s1(i - j + 1)
            Next j
            s2(i) = s / iParameter
        Next i

        'a
        a = (2 * s1(n)) - s2(n)
        'b
        b = (2 * (s1(n) - s2(n))) / (iParameter - 1)

        'Ðñüâëåøç
        For i = 1 To iHorizon
            dForecasts(i) = a + (b * i)
        Next i

        Z_OLD_MovingAverage_2 = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        Z_OLD_MovingAverage_2 = False

CleanExit:

    End Function

    '************************************************************************************************************************************************************************************
    ' SIMPLE EXPONENTIAL SMOOTHING
    '************************************************************************************************************************************************************************************
    Public Shared Function Z_OLD_SimpleExponentialSmoothing(ByRef dData() As Double,
                                                                                                    ByVal iHorizon As Integer,
                                                                                                    ByRef dForecasts() As Double,
                                                                                                    ByVal bDisplayMessage As Boolean) As Boolean
        Dim mselb, step_Renamed, mseub As Double
        Dim ub, lb, temp As Double
        Dim uForecast, lForecast As Double
        Dim BestForecast, InitialValue As Double
        Dim StepArray() As Double
        Dim i, Steps As Short

        On Error GoTo ErrTrap

        'Inits for hints
        BestForecast = 0

        'Initialisations
        ReDim dForecasts(iHorizon)
        Steps = 6
        ReDim StepArray(Steps)

        StepArray(1) = 0.17
        StepArray(2) = 0.08
        StepArray(3) = 0.04
        StepArray(4) = 0.02
        StepArray(5) = 0.01
        StepArray(6) = 0 'Dummy just to close the loop
        lb = 0.33
        ub = 0.67
        InitialValue = clsCommonMath.MeanOfArray(dData)

        For i = 1 To Steps
            step_Renamed = StepArray(i)
            mselb = clsForecast_Tools.Calculate_MSE_Simple(lb, InitialValue, dData, lForecast)
            mseub = clsForecast_Tools.Calculate_MSE_Simple(ub, InitialValue, dData, uForecast)
            If mselb > mseub Then
                temp = ub
                ub = (temp + step_Renamed)
                lb = (temp - step_Renamed)
                If i = Steps Then BestForecast = uForecast
            Else
                temp = lb
                ub = (temp + step_Renamed)
                lb = (temp - step_Renamed)
                If i = Steps Then BestForecast = lForecast
            End If
        Next i
        For i = 1 To iHorizon
            dForecasts(i) = BestForecast
        Next i

        Z_OLD_SimpleExponentialSmoothing = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        Z_OLD_SimpleExponentialSmoothing = False

CleanExit:

    End Function

    '************************************************************************************************************************************************************************************
    'SIMPLE EXPONENTIAL SMOOTHING - TREND
    '************************************************************************************************************************************************************************************
    Public Shared Function Z_OLD_SimpleExponentialSmoothing_Trend(ByRef dData() As Double,
                                                                                                                ByRef iTime() As Double,
                                                                                                                ByVal iHorizon As Integer,
                                                                                                                ByRef dForecasts() As Double,
                                                                                                                ByVal bDisplayMessage As Boolean) As Boolean
        Dim mselb, step_Renamed, mseub As Double
        Dim ub, lb, temp As Double
        Dim uForecast, lForecast As Double
        Dim BestForecast, InitialValue As Double
        Dim StepArray() As Double
        Dim i, Steps As Short
        Dim n As Short
        Dim avy, Sxy, Sx, avx, Sx2 As Double
        Dim theConstant As Double
        Dim theSlope As Double

        On Error GoTo ErrTrap

        'Inits for hints
        BestForecast = 0
        'Initialisations
        Dim theforecasts(iHorizon) As Double
        Steps = 6
        ReDim StepArray(Steps)
        ReDim dForecasts(iHorizon)

        StepArray(1) = 0.17
        StepArray(2) = 0.08
        StepArray(3) = 0.04
        StepArray(4) = 0.02
        StepArray(5) = 0.01
        StepArray(6) = 0 'Dummy just to close the loop
        lb = 0.33
        ub = 0.67
        InitialValue = clsCommonMath.MeanOfArray(dData)

        For i = 1 To Steps
            step_Renamed = StepArray(i)
            'mselb = clsForecast_Tools.Calculate_MSE_Simple(lb, InitialValue, dData, lForecast)
            'mseub = clsForecast_Tools.Calculate_MSE_Simple(ub, InitialValue, dData, uForecast)
            If mselb > mseub Then
                temp = ub
                ub = (temp + step_Renamed)
                lb = (temp - step_Renamed)
                If i = Steps Then BestForecast = uForecast
            Else
                temp = lb
                ub = (temp + step_Renamed)
                lb = (temp - step_Renamed)
                If i = Steps Then BestForecast = lForecast
            End If
        Next i

        'For i = 1 To ahorizon
        '    theforecasts(i) = BestForecast
        'Next i

        'Õðïëïãéóìüò ëüãù ôçò ôÜóçò
        If UBound(iTime) = UBound(dData) Then
            n = UBound(iTime) 'ìÞêïò ×Ó
            avy = clsCommonMath.MeanOfArray(dData) 'ì.ï. Õ
            avx = clsCommonMath.MeanOfArray(iTime) 'ì.ï. ×
            clsForecast_Tools.SumsAndSquares(iTime, Sx, Sx2)
            Sxy = 0
            For i = 1 To n
                Sxy = Sxy + iTime(i) * dData(i)
            Next i
            theSlope = (Sxy / n - avx * avy) / (Sx2 / n - avx * avx)
            theConstant = avy - theSlope * avx
            theforecasts(1) = BestForecast 'SimpleESMethod
            dForecasts(1) = BestForecast 'SimpleESMethod
            For i = 2 To iHorizon
                theforecasts(i) = theforecasts(i - 1) + theSlope
                dForecasts(i) = dForecasts(i - 1) + theSlope
            Next i
        Else
            'MsgBox("InvalidInput ArraysSizesmustbeequal")
            GoTo ErrTrap
        End If

        Z_OLD_SimpleExponentialSmoothing_Trend = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        Z_OLD_SimpleExponentialSmoothing_Trend = False

CleanExit:

    End Function

    '************************************************************************************************************************************************************************************
    'HOLT 
    '************************************************************************************************************************************************************************************
    Public Shared Function Z_OLD_Holt_ExponentialSmoothing(ByRef dData() As Double,
                                                                                                ByVal iHorizon As Integer,
                                                                                                ByRef dForecasts() As Double,
                                                                                                ByVal bDisplayMessage As Boolean) As Boolean
        Dim StepArray() As Double
        Dim h(2, 2) As Double
        Dim val1, Steps, val2 As Short
        Dim j, i, l As Short
        Dim mse, vima, new_mse As Double
        Dim v1, v2 As Double

        Dim n As Short
        Dim avy, Sxy, Sx, avx, Sx2 As Double
        Dim theConstant As Double
        Dim theSlope As Double

        On Error GoTo ErrTrap

        'Áñ÷éêïðïßçóç
        Dim theforecasts(iHorizon) As Object
        Steps = 8
        ReDim StepArray(Steps)
        StepArray(0) = 0.17
        StepArray(1) = 0.08
        StepArray(2) = 0.04
        StepArray(3) = 0.02
        StepArray(4) = 0.015
        StepArray(5) = 0.0005
        StepArray(6) = 0.0001
        StepArray(7) = 0

        For i = 1 To 2
            h(i, 1) = 0.33
            h(i, 2) = 0.67
        Next i
        mse = 1.7 * 10 ^ 308

        'Inits for hints
        val1 = 0
        val2 = 0

        'Main
        For l = 0 To Steps - 1
            For i = 1 To 2
                For j = 1 To 2
                    new_mse = clsForecast_Tools.Calculate_MSE_Holt(h(1, i), h(2, j), CShort(iHorizon), dData, dForecasts)
                    If mse > new_mse Then
                        val1 = i
                        val2 = j
                        mse = new_mse
                    End If
                Next j
            Next i
            vima = StepArray(l)
            v1 = h(1, val1)
            h(1, 1) = v1 - vima
            h(1, 2) = v1 + vima
            v2 = h(2, val2)
            h(2, 1) = v2 - vima
            h(2, 2) = v2 + vima
        Next l

        clsForecast_Tools.Calculate_MSE_Holt(h(1, val1), h(2, val2), CShort(iHorizon), dData, dForecasts)

        Z_OLD_Holt_ExponentialSmoothing = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        Z_OLD_Holt_ExponentialSmoothing = False

CleanExit:

    End Function

    '************************************************************************************************************************************************************************************
    'DAMPEN EXPONENTIAL SMOOTHING
    '************************************************************************************************************************************************************************************
    Public Shared Function Z_OLD_DampenExponentialSmoothing(ByRef dData() As Double,
                                                                                                        ByVal iHorizon As Integer,
                                                                                                        ByRef dForecasts() As Double,
                                                                                                        ByVal bDisplayMessage As Boolean) As Boolean
        'SOS: Ç ÈÅÓÇ ÌÇÄÅÍ ÓÔÏÕÓ ÐÉÍÁÊÅÓ ÄÅÍ ×ÑÇÓÉÌÏÐÏÉÅÉÔÁ
        Dim StepArray() As Double
        Dim h(3, 2) As Double
        Dim val2, Steps, val1, val3 As Short
        Dim k, i, j, l As Short
        Dim mse, vima, new_mse As Double
        Dim v2, v1, v3 As Double

        On Error GoTo ErrTrap

        'Áñ÷éêïðïßçóç
        ReDim dForecasts(iHorizon)
        Steps = 8
        ReDim StepArray(Steps)
        StepArray(1) = 0.17
        StepArray(2) = 0.08
        StepArray(3) = 0.04
        StepArray(4) = 0.02
        StepArray(5) = 0.01
        StepArray(5) = 0.015
        StepArray(6) = 0.0005
        StepArray(7) = 0.0001
        StepArray(8) = 0

        For i = 1 To 3
            h(i, 1) = 0.33
            h(i, 2) = 0.67
        Next
        mse = 1.7 * 10 ^ 308

        'Inits for hints
        val1 = 0
        val2 = 0
        val3 = 0

        'Main
        For l = 1 To Steps
            vima = StepArray(l)
            For i = 1 To 2
                For j = 1 To 2
                    For k = 1 To 2
                        new_mse = clsForecast_Tools.Calculate_MSE_Damped(h(1, i), h(2, j), h(3, k), CShort(iHorizon), dData, dForecasts)
                        If mse > new_mse Then
                            val1 = i
                            val2 = j
                            val3 = k
                            mse = new_mse
                        End If
                    Next k
                Next j
            Next i
            v1 = h(1, val1)
            h(1, 1) = v1 - vima
            h(1, 2) = v1 + vima
            v2 = h(2, val2)
            h(2, 1) = v2 - vima
            h(2, 2) = v2 + vima
            v3 = h(3, val3)
            h(3, 1) = v3 - vima
            h(3, 2) = v3 + vima
        Next l

        clsForecast_Tools.Calculate_MSE_Damped(h(1, val1), h(2, val2), h(3, val3), CInt(iHorizon), dData, dForecasts)

        Z_OLD_DampenExponentialSmoothing = True

        GoTo CleanExit

        Exit Function

ErrTrap:
        Z_OLD_DampenExponentialSmoothing = False

CleanExit:

    End Function

    '************************************************************************************************************************************************************************************
    'MULTIPLE REGRESSION
    '************************************************************************************************************************************************************************************
    Public Shared Function Z_OLD_LinearRegression_Multiple(ByRef aDataArray() As Double,
                                                                                    ByRef aDateArray() As Date,
                                                                                    ByRef ahorizon As Short,
                                                                                    ByRef theforecasts() As Double) As Boolean
        ' Multiple Regression
        Dim gnorm As Double
        Dim w() As Double
        Dim y() As Double
        Dim rxmatrix() As Double
        Dim xmatrix() As Double
        Dim j As Short
        Dim irow As Short

        'ÂÜëå ôçí ìåôáâëçôÞ Y
        '        irow = UBound(aDataArray)
        '        ReDim Preserve y(irow)
        '        For j = 1 To irow
        '            y(j) = aDataArray(j)
        '        Next j

        '        'ÄéÜâáóå ðüóåò ÷ñïíïóåéñÝò Ý÷åé ó÷åôéêÝò
        '        Dim multNames() As String
        '        Dim multData() As Double
        '        Call MethodsManager.MultData_Count(irow, aDateArray(1), aDateArray(UBound(aDateArray)), ncol, varname(), rxmatrix)

        '        ReDim coef(ncol)
        '        ReDim g(ncol)
        '        ReDim r(ncol)
        '        ReDim p(ncol)
        '        ReDim s(ncol, ncol)
        '        ReDim UTU(ncol, ncol)
        '        ReDim U(ncol)
        '        If ncol = 1 Then
        '            '   ÔÅËÏÓ --> ÕÐÏËÏÃÉÓÅ ÔÉÓ ÐÑÏÂËÅØÅÉÓ ÓÏÕ (DEN EXOUN ORISTI SXETIKES XRONOSEIRES
        '            For j = 1 To ahorizon
        '                theforecasts(j) = 0
        '            Next j
        '            Exit Sub
        '        End If

        '        'ÔÅËÏÓ ÌÅ ÔÁ ÄÅÄÏÌÅÍÁ --> ÓÕÍÅ×ÉÓÅ ÌÅ ÔÏÕÓ ÕÐÏËÏÃÉÓÌÏÕÓ
        '        nrow = irow
        '        ReDim xmatrix(nrow, ncol) 'use constant

        '        '    For j = 1 To ncol - 1
        '        '        If j = 1 Then varname(j) = "Const"
        '        '        If j > 1 Then varname(j) = varname(j)
        '        '    Next j
        '        '
        '        Dim i As Integer
        '        For i = 1 To nrow
        '            For j = 1 To ncol
        '                If j = 1 Then xmatrix(i, 1) = 1 'constant term
        '                If j > 1 Then xmatrix(i, j) = rxmatrix(j - 1, i)
        '            Next j
        '        Next i

        '        ReDim w(nrow)
        '        ReDim ResId(nrow) As Double
        '            ReDim yhat(nrow) As Double

        '            Dim l As Integer
        '        Dim m As Integer
        '        For j = 1 To nrow
        '            For l = 1 To ncol
        '                For m = 1 To ncol
        '                    s(l, m) = s(l, m) + xmatrix(j, l) * xmatrix(j, m)
        '                Next m
        '                U(l) = U(l) + xmatrix(j, l) * y(j)
        '            Next l
        '        Next j

        '        Dim rtrold As Double
        '        rtrold = 0
        '        For j = 1 To ncol
        '            coef(j) = 0
        '            r(j) = U(j)
        '            rtrold = rtrold + r(j) ^ 2
        '            p(j) = 0
        '            g(j) = 0
        '        Next j
        '        Call conjug(s, r, p, g, rtrold, ncol)

        '        For j = 1 To ncol
        '            coef(j) = g(j)
        '            g(j) = 0
        '        Next j

        '        Dim iter As Integer
        '        For iter = 1 To 100
        '            gnorm = 0
        '            If iter > 1 Then
        '                For j = 1 To ncol
        '                    coef(j) = coef(j) + g(j)
        '                    gnorm = gnorm + Abs(g(j))
        '                Next j
        '                If gnorm < 0.00001 Then
        '                    GoTo conv
        '                    Exit Sub
        '                End If
        '            End If

        '            For l = 1 To ncol
        '                For m = 1 To ncol
        '                    s(l, m) = 0
        '                Next m
        '                U(l) = 0
        '            Next l

        '            Dim sse As Double
        '            Dim i1 As Integer
        '            sse = 0
        '            For i1 = 1 To nrow
        '                yhat(i1) = 0
        '                For j = 1 To ncol
        '                    yhat(i1) = yhat(i1) + xmatrix(i1, j) * coef(j)
        '                Next j
        '                ResId(i1) = y(i1) - yhat(i1)
        '                sse = sse + ResId(i1) ^ 2
        '                For l = 1 To ncol
        '                    For m = 1 To ncol
        '                        s(l, m) = s(l, m) + xmatrix(i1, l) * xmatrix(i1, m)
        '                    Next m
        '                    U(l) = U(l) + xmatrix(i1, l) * ResId(i1)
        '                Next l
        '            Next i1

        '            rtrold = 0
        '            For j = 1 To ncol
        '                r(j) = U(j)
        '                rtrold = rtrold + r(j) ^ 2
        '                p(j) = 0
        '                g(j) = 0
        '            Next j
        '            Call conjug(s, r, p, g, rtrold, ncol)

        '            DoEvents
        '            'Form2.Text1.Text = Form2.Text1.Text + "SSE: " & Format(sse, "0.00000000") & Chr(13) & Chr(10)

        '        Next iter
        'conv:

        '        mse = sse / (nrow - ncol)

        '        If ncol > 1 Then Call eigen1(ncol, s)

        '        Call converge
        '        Dim R2 As Double
        '        R2 = R2est(y, xmatrix, coef)
        '        Dim R2adj As Double, F As Double
        '        R2adj = 1 - ((1 - R2) * ((nrow - 1) / (nrow - ncol)))
        '        F = (R2 / (ncol - 1)) / ((1 - R2) / (nrow - ncol))
        '        'Form2.Text1.Text = Form2.Text1.Text & "R2" & Chr(9) & Chr(9)
        '        'Form2.Text1.Text = Form2.Text1.Text & "R2adj" & Chr(9) & Chr(9)
        '        'Form2.Text1.Text = Form2.Text1.Text + "F" & Chr(9) & Chr(9)
        '        'Form2.Text1.Text = Form2.Text1.Text & nl
        '        'Form2.Text1.Text = Form2.Text1.Text + Format(Exp(R2), "0.000000000") & Chr(9)
        '        'Form2.Text1.Text = Form2.Text1.Text + Format(Exp(R2adj), "0.000000000") & Chr(9)
        '        'Form2.Text1.Text = Form2.Text1.Text + Format(Exp(F), "0.000000000") & Chr(9)

        '        'Óþóå ôá óôáôéóôéêÜ ôçò ðïëëáðëÞò ðáëéíäñüìéóçò
        '        Call PISFISManager.UpdateMultipleData(R2, F, coef(), se(), varname())

        '        '   ÔÅËÏÓ --> ÕÐÏËÏÃÉÓÅ ÔÉÓ ÐÑÏÂËÅØÅÉÓ ÓÏÕ
        '        Dim sum As Double
        '        Dim nextDate As Date
        '        Dim nextValue As Double
        '        sum = 0
        '        nextDate = aDateArray(UBound(aDateArray))
        '        For i = 1 To ahorizon
        '            sum = coef(1)
        '            nextDate = PISFISManager.ipologismos_epomenis_imerominias(nextDate, iTimeserieSeasonality)
        '            For j = 1 To UBound(coef) - 1
        '                nextValue = MethodsManager.MultData_nextValue(Val(Right(varname(j), Len(varname(j)) - 1)), nextDate)
        '                sum = sum + nextValue * coef(j + 1)
        '            Next j
        '            theforecasts(i) = sum
        '        Next i

        '        MultipleRegression = False

        Z_OLD_LinearRegression_Multiple = False

    End Function

End Class
