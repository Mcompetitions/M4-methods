﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("PATMathNLIBSQL")>
<Assembly: AssemblyDescription("PAT ActiveX .NET MathSQL Library")>
<Assembly: AssemblyCompany("Patelis Alexander")>
<Assembly: AssemblyProduct("PATMathNLIBSQL")>
<Assembly: AssemblyCopyright("Patelis Alexander")>
<Assembly: AssemblyTrademark("PATMathNLIBSQL")>

<Assembly: ComVisible(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("38699809-11d6-4133-b937-70a9ce86da13")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("4.7.0.0")>
<Assembly: AssemblyFileVersion("4.7.0.0")>
