Calculate PDF according to R-method.
