# -*- coding: utf-8 -*-
from ._rdensity import ffi, lib


def density(n, m, series, nthreads=1):
    """
    n - alphabet size
    m - analysis depth
    """
    if n < 2:
        raise ValueError('invalid alphabet size')
    if m < 0:
        raise ValueError('invalid analysis depth')
    t = len(series)
    if t < 2:
        raise ValueError('invalid series length')
    x = ffi.new("double[{}]".format(t), series)
    dens = ffi.new("double[{}]".format(n))
    lib.density(n, m, x, t, dens, nthreads)
    return dens
