from setuptools import setup

librdensity = ('rdensity', {
    'sources': ['cppsrc/rdensity.cpp'],
    'cflags': ['-fopenmp',
               '-fsigned-char',
               '-fno-rtti',
               '-fomit-frame-pointer']
})

setup(
    name="rdensity",
    version="0.0.1",
    description="Calculate PDF according to R-method",
    author="zaquest",
    packages=['rdensity'],
    libraries=[librdensity],
    license="zlib",
    setup_requires=["cffi>=1.0.0"],
    cffi_modules=["rdensity_build.py:ffibuilder"],
    install_requires=["cffi>=1.0.0"]
)
