#pragma once

#include <vector>
#include <unordered_map>
#include <math.h>

// Simple Markov counts

// markov_counts_simple could be faster with a simple map
// should probably try a some faster hash function or idk
#include <map>
template<typename K, typename V> using map = std::map<K, V>;
//template<typename K, typename V> using map = std::unordered_map<K, V>;

template<typename C> using context_simple = std::vector<C>;

template<typename C>
struct std::hash<context_simple<C>> {
    uint operator()(const context_simple<C> &ctx) const {
        std::hash<C> chash;
        uint hash = 0;
        for (uint i = 0, ie = ctx.size(); i < ie; ++i) {
            hash ^= chash(ctx[i]) << 1;
        }
        return hash;
    }
};

template<typename C> using char_counts = map<C, uint>;

template <typename C>
struct markov_counts_simple {
    const std::vector<C> &x;
    const uint m;

    typedef context_simple<C> context;
    typedef map<context, char_counts<C>> context_counts;
    context_counts counts;

    markov_counts_simple(const std::vector<C> &_x, uint _m, [[maybe_unused]] C n=0)
        : x(_x), m(_m), counts()
    {
        for (uint i = 0, ie = x.size() - m; i < ie; ++i) {
            context ctx(&x[i], &x[i+m]);
            ++counts[ctx][x[i+m]];
        }
    }

    typename context_counts::const_iterator find(uint idx) const {
        context ctx(&x[idx], &x[idx+m]);
        return counts.find(ctx);
    }

    typename context_counts::const_iterator begin() const {
        return counts.begin();
    }

    typename context_counts::const_iterator end() const {
        return counts.end();
    }
};

//template<typename C>
//void print(const markov_counts_simple<C> &mc) {
//    for (auto ctx : mc) {
//        for (auto ch : ctx.first) { fmt::print("{} ", ch); }
//        fmt::print("\n");
//        for (auto ch : ctx.second) {
//            fmt::print("  {} {}\n", ch.first, ch.second);
//        }
//    }
//}

// Markov counts using rolling hash

struct context_rolling {
    uint idx;
    uint hash;
};

template<typename C>
struct context_hash_sum {
    typedef context_rolling context;

    const std::vector<C> &x;
    const uint m;

    context_hash_sum(const std::vector<C> &_x, uint _m) : x(_x), m(_m) { }

    uint operator()(const context &ctx) const { return ctx.hash; }

    uint first(uint idx) const {
        uint h = 0;
        for (uint i = idx, ie = idx+m; i < ie; ++i) { h += x[i]; }
        return h;
    }

    void next(context &ctx) const {
        ctx.hash = ctx.hash - x[ctx.idx] + x[ctx.idx+m];
        ++ctx.idx;
    }
};

// faster, thanks to no add/sub/mul
template<typename C>
struct context_hash_cyclic {
    typedef context_rolling context;

    const std::vector<C> &x;
    const uint m;
    // use bit-wise and with mask to avoid %
    // (8 * 1 [sizeof(uchar)]) - 1 = 8 - 1 = 7 = 0b111; x & 0b111 == x % 8
    // (8 * 2 [sizeof(ushort)]) - 1 = 16 - 1 = 15 = 0b1111; x & 0b1111 == x % 16
    // (8 * 4 [sizeof(uint)]) - 1 = 32 - 1 = 31 = 0b11111; x & 0b11111 == x % 32
    constexpr static uint mask = (CHAR_BIT * sizeof(C)) - 1;

    context_hash_cyclic(const std::vector<C> &_x, uint _m) : x(_x), m(_m) { }

    uint operator()(const context &ctx) const { return ctx.hash; }

    uint first(uint idx) const {
        if (m == 0) { return 0; }
        C h = rotl<C>(x[idx], (m-1) & mask);
        for (uint i = 1; i < m; ++i) {
            h ^= rotl<C>(x[idx+i], (m-i-1) & mask);
        }
        return h;
    }

    void next(context &ctx) const {
        ctx.hash = rotl<C>(ctx.hash, 1) ^ rotl<C>(x[ctx.idx], m & mask) ^ x[ctx.idx+m];
        ++ctx.idx;
    }
};

//template<typename C> using context_hash = context_hash_sum<C>;
template<typename C> using context_hash = context_hash_cyclic<C>;

template<typename C>
struct context_equal {
    typedef context_rolling context;

    const std::vector<C> &x;
    const uint m;

    context_equal(const std::vector<C> &_x, uint _m) : x(_x), m(_m) { }

    uint operator()(const context &a, const context &b) const {
        return a.hash == b.hash
            && (a.idx == b.idx
                    || std::equal(&x[a.idx], &x[a.idx+m], &x[b.idx]));
    }
};

uint markov_cnt_bucket_hint(uint n, uint m, uint t) {
    uint by_len = t - m;
    if (!n) { return by_len; }
    uint r = std::min(uint(pow(n, m)), by_len);
    return r;
}

template<typename C>
struct markov_counts_rolling {
    typedef context_rolling context;

    context_hash<C> hash;
    context_equal<C> eq;

    typedef std::unordered_map<context,
                               char_counts<C>,
                               context_hash<C>,
                               context_equal<C>> context_counts;
    context_counts counts;

    markov_counts_rolling(const std::vector<C> &x, uint m, C n = 0)
        : hash(x, m), eq(x, m),
          counts(markov_cnt_bucket_hint(n, m, x.size()), hash, eq)
    {
        uint h = hash.first(0);
        context ctx{0, h};
        counts[ctx][x[m]] = 1;
        for (uint i = 1, ie = x.size()-m; i < ie; ++i) {
            hash.next(ctx);
            ++counts[ctx][x[i+m]];
        }
    }

    typename context_counts::const_iterator find(uint idx) const {
        context ctx{idx, hash.first(idx)};
        return counts.find(ctx);
    }

    typename context_counts::const_iterator begin() const {
        return counts.begin();
    }

    typename context_counts::const_iterator end() const {
        return counts.end();
    }
};

//template<typename C>
//void print(const markov_counts_rolling<C> &mc) {
//    const std::vector<C> &x = mc.hash.x;
//    const uint m = mc.hash.m;
//
//    for (auto &ctx : mc.counts) {
//        for (uint i = ctx.first.idx, ie = i+m; i < ie; ++i) {
//            fmt::print("{} ", x[i]);
//        }
//        fmt::print("\n");
//        for (auto &ch : ctx.second) {
//            fmt::print("  {} {}\n", ch.first, ch.second);
//        }
//    }
//}
