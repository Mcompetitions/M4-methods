#include "rdensity.h"
#include "utils.h"
#include "gmpmm.h"
#include "count.h"
#include "gamma.h"
#include "r_decompose.h"
#include <omp.h>

typedef unsigned char uchar;
typedef unsigned short ushort;

typedef mpf_class real_t;
typedef gamma_cache<1, real_t> gamma_t;

void density(uint n, uint m, const double *x, uint t, double *result, uint nthreads) {
    omp_set_num_threads(nthreads);
    omp_set_schedule(omp_sched_dynamic, 8);

    std::vector<double> y(x, x+t);
    std::vector<double> dens;
    if (n < 255) {
        dens = r_density<real_t, gamma_t, markov_counts_rolling, uchar, double>(n, m, y);
    } else if (n < 65535) {
        dens = r_density<real_t, gamma_t, markov_counts_rolling, ushort, double>(n, m, y);
    } else {
        dens = r_density<real_t, gamma_t, markov_counts_rolling, uint, double>(n, m, y);
    }
    memcpy(result, dens.data(), sizeof(double) * n);
}
