#pragma once

#include <ctgmath>

template<typename Real>
Real weight(uint n) { return 1 / log2(n+2) - 1 / log2(n+3); }

template<typename Real>
Real weight_last(uint n) { return 1 / log2(n+3); }
