#pragma once

#include <gmpxx.h>
#include "utils.h"

mpq_class pow(const mpq_class &a, uint b) {
    mpq_class r(0);
    mpz_pow_ui(r.get_num_mpz_t(), a.get_num_mpz_t(), b);
    mpz_pow_ui(r.get_den_mpz_t(), a.get_den_mpz_t(), b);
    return r;
}

mpf_class pow(const mpf_class &a, uint b) {
    mpf_class r(a);
    mpf_pow_ui(r.get_mpf_t(), a.get_mpf_t(), b);
    return r;
}

template <>
double conv<mpf_class, double>(const mpf_class &x) {
    return mpf_get_d(x.get_mpf_t());
}

template <>
double conv<mpz_class, double>(const mpz_class &x) {
    return mpz_get_d(x.get_mpz_t());
}

template <>
double conv<mpq_class, double>(const mpq_class &x) {
    return mpf_get_d(mpf_class(x).get_mpf_t());
}

template <>
float conv<mpf_class, float>(const mpf_class &x) {
    return mpf_get_d(x.get_mpf_t());
}

template <>
float conv<mpz_class, float>(const mpz_class &x) {
    return mpz_get_d(x.get_mpz_t());
}

template <>
float conv<mpq_class, float>(const mpq_class &x) {
    return mpf_get_d(mpf_class(x).get_mpf_t());
}
