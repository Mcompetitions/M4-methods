#pragma once

#include <cassert>
#include <algorithm>
#include <limits>
#include "utils.h"

template<typename Real, typename Level>
struct QuantizedAlphabet {
    typedef Real real_t;
    typedef Level level_t;
    typedef std::pair<real_t, real_t> bounds_t;

    const level_t levels;
    const real_t start, end;
    const real_t level_size;

    QuantizedAlphabet(level_t _levels, real_t _start, real_t _end)
        : levels(_levels),
          start(_start),
          end(_end),
          level_size((_end - _start) / _levels) {
        assert(levels > 0 && "Invalid number of `levels`");
        assert(start < end && "`start` should be smaller than `end`");
    }

    level_t quantize(real_t value) const {
        assert(start <= value && value <= end && "`value` is out of range");
        return clamp<level_t>((value - start) / level_size, 0, levels-1);
    }

    bounds_t bounds(level_t level) const {
        assert(0 <= level && level < levels && "Invalid `level` index");
        return {start + level_size * level, start + level_size * (level + 1)};
    }

    real_t middle(level_t level) const {
        auto bs = bounds(level);
        return (bs.first + bs.second) / 2.0;
    }
};


template<typename Char, typename Real=float>
std::vector<Char> quantize(const std::vector<Real> &x, uint levels) {
    Real min = std::numeric_limits<Real>::max(),
         max = std::numeric_limits<Real>::min();
    for (Real v : x) {
        if (v < min) { min = v; }
        if (v > max) { max = v; }
    }
    std::vector<Char> qx(x.size());
    QuantizedAlphabet<Real, Char> ab(levels, min, max);
    std::transform(x.cbegin(), x.cend(), qx.begin(),
            [&ab](Real v) -> Char { return ab.quantize(v); });
    return qx;
}
