#pragma once

typedef unsigned int uint;

#ifdef __cplusplus
extern "C" {
#endif

void density(uint alphabet_size, uint analysis_depth, const double *series, uint series_len, double *density, uint nthreads);

#ifdef __cplusplus
}
#endif
