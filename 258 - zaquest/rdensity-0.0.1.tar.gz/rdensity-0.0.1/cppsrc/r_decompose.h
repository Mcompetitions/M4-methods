#pragma once

// n - alphabet size
// t - series length
// m - analysis depth / context length

// http://wiki.zaquest.org/PDF_forecasting_using_Krichevsky_measure

#include <vector>
#include <unistd.h>

#include "common.h"
#include "krichevsky.h"

template<typename M>
inline typename M::mapped_type get(
    const M &map,
    const typename M::key_type &k,
    typename M::mapped_type def
) {
    typename M::const_iterator it = map.find(k);
    return it == map.end() ? def : it->second;
}

// mpq addition is slow, hence this function is much faster with mpf
// If mpq have to be used one might want to define a different version
// of this function where R is explicitly mpf_class.
template<typename Real, typename AT, typename BT>
Real dot(const uint n, const AT A[], const BT B[]) {
    Real R = 0;
    for (uint i = 0; i < n; ++i) { R += A[i] * B[i]; }
    return R;
}

template<typename Real,
         typename GammaT,
         template <typename> class CountsT,
         typename Char,
         typename T>
std::vector<T> r_density(const Char n, const uint m, std::vector<T> &x) {
#ifdef __linux__
    const uint cache_alignment = sysconf(_SC_LEVEL1_DCACHE_LINESIZE);
#else
    const uint cache_alignment = 64; // a popular cache line size :P
#endif

    const uint t = x.size(); // Series length
    const Char q = n - 1; // Quantizing to 1 level is useless

    // Depth weighting
    double *Wm = (double *)aligned_alloc(cache_alignment, sizeof(double) * (m+1));
    for (uint i = 0; i <= m; ++i) { Wm[i] = weight<double>(i); }
    //Wm[m-1] = weight_last<double>(m-2);

    // Quantization weighting
    void *Wq_p = aligned_alloc(cache_alignment, sizeof(Real) * q);
    Real *Wq = new (Wq_p) Real[q];
    for (Char i = 0; i < q; ++i) { Wq[i] = weight<double>(i); }
    //Wq[q-1] = weight_last<double>(q-2);

    // K * Wm vector, base case
    void *base_K_Wm_p = aligned_alloc(cache_alignment, sizeof(Real) * q);
    Real *base_K_Wm = new (base_K_Wm_p) Real[q];

    // K * Wm vector, per Char
    using K_Wm_t = Real[n][q];
    Real *K_Wm_p = (Real *)aligned_alloc(cache_alignment, sizeof(Real) * n * q);
    K_Wm_t &K_Wm = *(K_Wm_t *)(new (K_Wm_p) Real[n * q]);

    // Output density
    std::vector<T> dens(n);

    #pragma omp parallel
    {
        GammaT g1(1);

        // Base matrix of Krichevsky measures
        Real *K = new Real[m+1];

        // Krichevsky measure multiplier for the
        // Current [char][depth]
        using C_t = double[n][m+1];
        double *Cp = new double[n * (m+1)];
        C_t &C = *(C_t *)Cp;

        // Updated Krichevsky measures for the current Char
        Real *Kc = new Real[m+1];

        // Leveraging schedule policy to runtime. One should find
        // an appropriate block size taking into accout cache line
        // size and sizes of the types used. For example:
        //
        // cache line size 64 bytes
        //
        // sizeof(mpf_class) == 24
        // (24 * 8) / 64 = 3
        //
        // sizeof(double) = 8
        // (8 * 8) / 64 = 1
        //
        // Hence with block size 8 there should be no false sharing
        // for arrays of types mpf_class and double.
        //
        // One should always take double into account because it's
        // used internally.
        //
        // It is more important to use dynamic scheduling than
        // correctly choosing the block size, because iterations
        // are not equal. YMMV
        #pragma omp for schedule(runtime)
        for (Char qi = 2; qi <= n; ++qi) {
            GammaT gn(qi);
            Wq[qi-2] *= pow(Real(qi), t);
            const auto qx = quantize<Char>(x, qi);
            std::vector<uint> qxx(qx.begin(), qx.end());
            const double qlvlsz = double(qi) / n;
            for (uint mi = 0; mi <= m; ++mi) {
                const CountsT<Char> counts(qx, mi, qi);
                K[mi] = krichevsky<Real>(qi, t, mi, counts, g1, gn);

                const auto ctxcntp = counts.find(t-mi);

                if (ctxcntp == counts.end()) {
                    for (Char c = 0; c < n; ++c) {
                        C[c][mi] = 1.0 / qi;
                    }
                } else {
                    const auto &ctxcounts = ctxcntp->second;

                    uint total = 0;
                    for (auto kv : ctxcounts) { total += kv.second; }
                    const double denom = total + qi / 2.0;

                    for (Char c = 0; c < n; ++c) {
                        Char qc = (c + 0.5) * qlvlsz;
                        uint cnt = get(ctxcounts, qc, 0);
                        C[c][mi] = (cnt + 0.5) / denom;
                    }
                }
            }

            base_K_Wm[qi-2] = dot<Real>(m+1, K, Wm);
            for (Char c = 0; c < n; ++c) {
                for (uint mi = 0; mi <= m; ++mi) {
                    Kc[mi] = K[mi] * C[c][mi];
                }
                K_Wm[c][qi-2] = dot<Real>(m+1, Kc, Wm);
            }
        }

        delete[] K;
        delete[] Cp;
        delete[] Kc;
    }

    const Real rux = dot<Real>(q, Wq, base_K_Wm);
    for (uint qi = 2; qi <= n; ++qi) { Wq[qi-2] *= qi; }

    for (Char c = 0; c < n; ++c) {
        Real ruxc = dot<Real>(q, Wq, K_Wm[c]);
        dens[c] = conv<Real, T>(ruxc / rux);
    }

    free(Wm);

    for (uint i = 0; i < q; ++i) { Wq[i].~Real(); }
    free(Wq_p);

    for (uint i = 0; i < q; ++i) { base_K_Wm[i].~Real(); }
    free(base_K_Wm_p);

    for (uint i = 0, ie = n * q; i < ie; ++i) { K_Wm_p[i].~Real(); }
    free(K_Wm_p);

    return dens;
}
