#pragma once

template<typename Real, template <typename> class CountsT, typename Char, typename GammaT>
Real krichevsky(const Char n, const uint t, const uint m,
        const CountsT<Char> &counts, GammaT &g1, GammaT &gn) {
    if (t <= m) { return 1.0 / pow(Real(n), t); }
    Real prod = 1.0;
    for (auto &ctx : counts) {
        uint total = 0;
        for (auto &ch : ctx.second) {
            uint cnt = ch.second;
            prod *= g1[cnt];
            total += cnt;
        }
        prod /= gn[total];
    }
    return prod / pow(Real(n), m);
}
