#pragma once

template<uint Scale, typename T>
struct gamma_frac {
    const double k;

    gamma_frac(double _k) : k(_k * 0.5 * Scale) { }

    T operator[](uint n) {
        T result = 1.0;
        for (double i = k, ie = Scale * n + k; i < ie; i += Scale) {
            result *= i;
        }
        return result;
        //T result = 1.0;
        //for (uint i = 0; i < n; ++i) {
        //    result *= Scale * i + k;
        //}
        //return result;
    }
};

// Implements gamma cache.
// gamma_cache<2, int_t> g1(1), gn(n) - Rakitsky method
// gamma_cache<1, real_t> g1(0.5), gn(n/2)- my method
template<uint Scale, typename T>
struct gamma_cache {
    const double k;
    std::vector<T> values;

    gamma_cache(double _k) : k(_k * 0.5 * Scale), values{0, k} { }

    void grow(uint n) {
        uint m = values.size()-1;
        for (; m < n; ++m) {
            values.push_back(values[m] * (Scale * m + k));
        }
    }

    T &operator[](uint n) {
        grow(n);
        return values[n];
    }
};
