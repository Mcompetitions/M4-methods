#pragma once

#include <sstream>
#include <vector>
#include <limits>
#include <limits.h>
#include <gmpxx.h>

template<typename T>
inline T clamp(T val, T min, T max) {
    return val < min ? min : val > max ? max : val;
}

// Render object to string
template<typename T>
std::string show(const T& ab) {
    std::ostringstream sstr;
    sstr << ab;
    return sstr.str();
}

template<typename T>
std::ostream &operator<<(std::ostream &out, const std::vector<T> &v) {
    if (!v.size()) { return out << "std::vector{}"; }
    out << "std::vector{" << v[0];
    for (uint i = 1, ie = v.size(); i < ie; ++i) {
        out << ", " << v[i];
    }
    return out << "}";
}

template<typename T>
struct bounds { T min, max; };

template<typename T>
bounds<T> minmax(const std::vector<T> &xs) {
    T min = std::numeric_limits<T>::max(),
      max = std::numeric_limits<T>::lowest();
    for (T x : xs) {
        if (x < min) { min = x; }
        if (x > max) { max = x; }
    }
    return {min, max};
}

template<typename T>
std::ostream &operator<<(std::ostream &out, const bounds<T> &bb) {
    return out << "bounds{min = " << bb.min << ", max = " << bb.max << "}";
}

template<typename Real>
Real measure_counting(const uint n, const uint t) {
    return 1 / pow(Real(n), t);
}

template<typename T>
T rotl(T x, uint n) {
    constexpr uint bits = CHAR_BIT * sizeof(T);
    return (x << n) | (x >> (bits - n));
}

template <typename F, typename T>
T conv(const F &x) {
    return x;
}

double pow(const double &a, uint b) {
    return pow(a, double(b));
}
