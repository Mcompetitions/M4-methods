# -*- coding: utf-8 -*-

from cffi import FFI
import os.path

CPPSRC = "cppsrc"
HEADER = os.path.join(CPPSRC, "rdensity.h")


def readlines(path):
    with open(path) as f:
        return f.readlines()


ffibuilder = FFI()
ffibuilder.set_source("rdensity._rdensity", '#include "rdensity.h"',
                      libraries=['rdensity', 'stdc++', 'gmp', 'gmpxx', 'gomp', 'm'],
                      library_dirs=[CPPSRC],
                      include_dirs=[CPPSRC])

# skip CPP directives and extern "C"
defs = "\n".join(l for l in readlines(HEADER)
                 if not (l.startswith("#")
                         or l.startswith("extern")
                         or l.startswith("}")))
ffibuilder.cdef(defs)

if __name__ == "__main__":
    ffibuilder.compile(verbose=True)
