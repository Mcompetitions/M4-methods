#!/usr/bin/env python

from setuptools import setup

setup(name='m4rmethod',
      version='1.0',
      description='M4 Competition R-method code',
      author='zaquest',
      author_email='web.elektro.net@gmail.com',
      url='https://zaquest.org/',
      packages=['m4'],
      install_requires=['SQLAlchemy',
                        'tqdm',
                        'psycopg2-binary',
                        'rdensity',
                        'numpy',
                        'scipy',
                        'arch'])
