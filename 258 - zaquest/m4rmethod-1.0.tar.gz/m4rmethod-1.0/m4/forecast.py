from math import log2, sqrt, isnan, isinf
import warnings
from collections import defaultdict

import numpy as np

from m4.quantized import QuantizedAlphabet
from rdensity import density as cppdensity

with warnings.catch_warnings():
    warnings.simplefilter('ignore')
    from scipy import stats
    from scipy import special
    from arch.unitroot import KPSS


def is_constant(xs):
    return len(xs) == 0 or all(x == xs[0] for x in xs)


def density(ab, m, xs):
    return list(enumerate(cppdensity(ab.levels, m, xs)))


"""
Series transform is a callable which takes a series and possibly some
parameters and returns transformed series and another callable that
can undo the transform given only series.

We're using a trick with redefining `__new__` to keep do/undo out
of global scope but separate.
"""


class ndiff:

    def __new__(cls, xs, alpha=0.05, maxdiff=2):
        lags = int(3 * sqrt(len(xs)) / 13)
        firsts = []
        d = maxdiff
        while d > 0:
            if is_constant(xs):
                break
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                try:
                    pvalue = KPSS(xs, trend='c', lags=lags).pvalue
                except ValueError:
                    break
            if pvalue > alpha:
                break
            firsts.append(xs[0])
            xs = np.diff(xs)
            d -= 1
        return list(xs), lambda ys: cls.undo(ys, firsts)

    @staticmethod
    def undo(xs, firsts):
        for d in reversed(firsts):
            xs = np.cumsum([d] + list(xs))
        return list(xs)


class boxcox:

    def __new__(cls, xs):
        xs = np.array(xs)
        if is_constant(xs):
            return xs, lambda ys: ys
        sample_min = min(xs)
        offset = abs(sample_min) + 1 if sample_min <= 0 else 0
        ys = xs + offset
        with warnings.catch_warnings():
            warnings.simplefilter('error')
            try:
                ys, lmb = stats.boxcox(xs)
            except RuntimeWarning:
                return xs, lambda ys: ys
        return list(ys), lambda ys: cls.undo(ys, offset, lmb)

    @staticmethod
    def undo(xs, offset, lmb):
        if lmb is not None:
            xs = special.inv_boxcox(xs, lmb)
        else:
            xs = np.array(xs)
        xs -= offset
        return list(xs)


class combine:

    def __new__(cls, xs, transforms):
        undos = []
        for t in transforms:
            xs, undo = t(xs)
            undos.append(undo)
        return xs, lambda ys: cls.undo(ys, undos)

    @staticmethod
    def undo(xs, undos):
        for undo in reversed(undos):
            xs = undo(xs)
        return xs


class LvlStat:

    def __init__(self):
        self.sum = 0
        self.count = 0

    def add(self, val):
        self.sum += val
        self.count += 1

    def mean(self, default):
        if self.count == 0:
            return default
        return self.sum / self.count


def series_means(xs, ab):
    stats = defaultdict(LvlStat)
    for x in xs:
        xc = ab.quantize(x)
        stats[xc].count += 1
        stats[xc].sum += x
    return [stats[lvl].mean(ab.middle(lvl)) for lvl in ab]


def normalize(density):
    total = sum(p for _, p in density)
    return [(lvl, p/total) for lvl, p in density]


def forecast_mean(means, dens):
    dens = normalize(dens)
    lvl = max(dens, key=lambda p: p[1])[0]
    return means[lvl]


def auto_r_forecast_multistep_mean(sample, m, h):
    lo, hi = min(sample), max(sample)
    levels = int(log2(len(sample))) + 5
    ab = QuantizedAlphabet(levels, lo, hi)

    means = series_means(sample, ab)

    forecasted = []
    for _ in range(h):
        dens = density(ab, m, sample + forecasted)
        val = forecast_mean(means, dens)
        forecasted.append(val)

    return forecasted


def forecast(xs, h, m=None, transforms=(boxcox, ndiff,)):
    xs, undo = combine(xs, transforms)
    m = len(xs) - 1 if m is None else m

    if is_constant(xs):
        vals = [xs[0]] * h
    else:
        vals = auto_r_forecast_multistep_mean(xs[:], m=m, h=h)

    return undo(xs + vals)[-h:]


def m4forecast(sample, horizon):
    forecasted = forecast(sample, horizon, m=5)
    if any(map(lambda x: isnan(x) or isinf(x), forecasted)):
        forecasted = forecast(sample, horizon, m=5, transforms=(ndiff,))
    return forecasted
