# -*- coding: utf-8 -*-
# vim: cc=70

from itertools import product
from math import isclose


class QuantizedAlphabet:
    """ Class representing alphabet given by division of
    `[start, end]` segment in `n` uniform levels.
    """

    def __init__(self, levels, start, end):
        """
        QuantaziedAlphabet : Int x Float x Float -> QuantizedAlphabet

        `QuantizedAlphabet(n, start, end)`, where `n` is a
        positive integer, `start`, `end` - real values such that
        `start < end`, returns alphabet of `n` levels of
        `[start, end]` segment. Levels go from `0` to `n-1`.

        Returned quantized alphabet `qa` has following attributes:

         * `qa.start` is a quantized interval's start point.
         * `qa.end` is a quantized intervals' end point.
         * `qa.levels` is a number of levels `qa.levels == len(qa)`.
         * `qa.level_size` is a length of each level's interval.
        """
        self.start = start
        self.end = end
        self.levels = levels
        self.level_size = (end - start) / levels

    def __len__(self):
        """ len : QuantizedAlphabet -> Int

        `len(qa)` returns a number of levels `len(qa) == qa.levels`.

        >>> len(QuantizedAlphabet(5, 0, 1))
        5
        """
        return self.levels

    def __iter__(self):
        """ iter : QuantizedAlphabet -> Iter Int

        `iter(qa)` returns an iterator over alphabet's levels.

        >>> print("".join(str(c) for c in QuantizedAlphabet(3, 0, 1)))
        012
        """
        return iter(range(self.levels))

    def bounds(self, n):
        """ bounds : Int -> (Float, Float)

        `qa.bounds(n)`, where `n` is a valid level
        `0 <= n < len(qa)`, returns tuple `(start, end)` giving lower
        and upper bounds of a level `n` respectively.

        >>> QuantizedAlphabet(4, 0, 1).bounds(1)
        (0.25, 0.5)
        """
        if 0 <= n and n < self.levels:
            return (self.start + self.level_size * n,
                    self.start + self.level_size * (n + 1))
        else:
            raise IndexError("Invalid level index {}".format(n))

    def quantize(self, val, char = None):
        """ quantize : Float -> Int

        `qa.quantize(val)`, where `val` is a value inside a segment
        quantized by `qa` `qa.start <= val <= qa.end`, returns a level
        to which `val` belongs. `val` is said to belong to a level `n`
        when `start <= val < end` where `[start, end)` gives `n`-th
        level semi-interval.

        >>> QuantizedAlphabet(3, 0, 1).quantize(0.4)
        1
        """
        if self.start <= val and val <= self.end:
            v = (val - self.start) / self.level_size
            if isclose(v, int(v)+1):
                v = int(v) + 1
            else:
                v = int(v)
            return min(v, self.levels - 1)
        else:
            raise ValueError("Value {} is out of range ({}, {})"
                             .format(val, self.start, self.end))

    def middle(self, lvl):
        """ middle : Int -> Float

        `qa.middle(n)`, where `n` is a valid level `0 <= n < len(qa)`,
        returns a middle point of a `n`-the level.

        >>> QuantizedAlphabet(2, 0, 1).middle(0)
        0.25
        """
        s, e = self.bounds(lvl)
        return (s + e) / 2

    def __repr__(self):
        return 'QuantizedAlphabet({},{},{})' \
                    .format(self.levels, self.start, self.end)

    def __pow__(self, n):
        """ pow : QuantizedAlphabet -> Iter [PyVal]

        `pow(fa, n)`, where `n` is a positive integer, returns an
        iterable over `n`-lists of all possible `n`-permutations of
        alphabet's letters.

        >>> list(pow(QuantizedAlphabet(2, 0, 100), 2))
        [(0, 0), (0, 1), (1, 0), (1, 1)]
        """
        elems = tuple(range(self.levels))
        return map(tuple, product(*([elems] * n)))
