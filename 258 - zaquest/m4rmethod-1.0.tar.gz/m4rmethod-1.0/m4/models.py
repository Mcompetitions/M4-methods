from sqlalchemy import Column, Integer, String
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


Base = declarative_base()


class Series(Base):
    __tablename__ = 'series'

    NONE = 0
    IN_PROGRESS = 1
    FORECASTED = 2
    ERROR = 3

    id = Column(String(6), primary_key=True)
    status = Column(Integer, index=True, default=NONE)
    horizon = Column(Integer, nullable=False)
    sample = Column(JSON(none_as_null=True), nullable=False)
    forecast = Column(JSON(none_as_null=True), nullable=True, default=None)
    error = Column(String, nullable=True, default=None)


# Create an engine that stores data in the local directory's
# sqlalchemy_example.db file.
engine = create_engine(
    'postgresql://m4:qwerty123@5.128.210.30/m4',
    isolation_level='SERIALIZABLE'
)


Session = sessionmaker(bind=engine)


def create_tables():
    Base.metadata.create_all(engine)
