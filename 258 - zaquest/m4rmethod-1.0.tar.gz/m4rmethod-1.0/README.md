Series length `t`
Alphabet size is `n = ceil(log2(t)) + 5` (Рябко, Лысяк, 2016)
