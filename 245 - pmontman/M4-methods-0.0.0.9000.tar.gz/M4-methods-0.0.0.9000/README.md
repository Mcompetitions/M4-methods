# M4-methods
Includes the source code to reproduce the forecasts of the methods which participated in the M4 Competition 
