library(gtools)

OUTPUT_DIR<-"Micro_Test"
dir.create(OUTPUT_DIR, recursive = T)
MODEL_DIR<-"models"

model_files<-list.files(MODEL_DIR)
model_sorted_files<-mixedsort(sort(model_files))

INPUT_SIZE_MULTIP=1.25
maxForecastHorizon=8

OUTPUT_P12=paste(OUTPUT_DIR,"lstm_12",sep='/')

  for (idr in 5316:11335) {
    print(paste0("time series:",idr))
    rdf_path<-paste(MODEL_DIR,model_sorted_files[idr],sep='/')
    ets_model <- readRDS(rdf_path)
    
    ets_residual<-as.numeric(ets_model$residuals)
    
    y<-ets_residual
    
    n=length(y)
    stlAdj<-cbind(y)
    
    inputSize=as.integer(INPUT_SIZE_MULTIP*maxForecastHorizon)
    inn=inputSize
    
    for (inn in inputSize:(n)) {
      sav_df=data.frame(id=paste(idr,'|i',sep=''));
      
      for (ii in 1:inputSize) {
        sav_df[,paste('r',ii,sep='')]=stlAdj[inn-inputSize+ii,1]  #inputs: past values normalized by the level
      }
      
      write.table(sav_df, file="Micro_Test/Micro_Test.txt", row.names = F, col.names=F, sep=" ", quote=F,append = TRUE)
      
    } #steps
  }#through all series from one file