library(forecast)
library(M4comp2018)
data(M4)


m4_yearly_df<-read.csv("M4file.txt", sep = "," ,header = TRUE)

yearly_M4 <- Filter(function(l) l$period == "Daily", M4)

for (idr in 1: nrow(m4_yearly_df)) {
  oneLine_df=m4_yearly_df[idr,]
  
  forecast_df= as.numeric(oneLine_df[5:ncol(oneLine_df)])
  
  if((sum(forecast_df < 0))>=1){
    print(idr)
    time_series_horizon<-as.numeric(yearly_M4[[idr]]$h)
    time_series_data<-as.numeric(yearly_M4[[idr]]$x)
    time_series_data<-log(time_series_data)
    y <- msts(time_series_data, seasonal.periods=c(7,365.25))
    ets_model = tbats(y)
    ets_forecast = forecast(ets_model, h= time_series_horizon)
    m4_yearly_df[idr,5:ncol(oneLine_df)] <- as.numeric(exp(ets_forecast$mean))
  } else{
    m4_yearly_df[idr,5:ncol(oneLine_df)] <- forecast_df
  }
}

write.table(m4_yearly_df, file="M4_fixed.txt", row.names = F, col.names=T, sep=",", quote=F)


