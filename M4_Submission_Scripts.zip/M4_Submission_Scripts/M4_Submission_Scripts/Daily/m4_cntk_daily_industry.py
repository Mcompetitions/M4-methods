import numpy as np
import pandas as pd
import random
import math as m

import sys
import os
import csv

from bayes_opt import BayesianOptimization

from cntk.device import *
from cntk import Trainer
from cntk.layers import *
from cntk.layers.typing import *
from cntk.learners import *
from cntk.ops import *
from cntk.logging import *
from cntk.metrics import *
from cntk.losses import *
from cntk.io import *
from cntk import sequence

import cntk
import cntk.ops as o
import cntk.layers as l

from _cntk_py import set_fixed_random_seed, force_deterministic_algorithms

# Input/Output Window size.
INPUT_SIZE = 17
OUTPUT_SIZE = 14

# LSTM specific configurations.
LSTM_USE_PEEPHOLES = True
LSTM_USE_STABILIZATION = True
BIAS = False

# Training and Validation file paths.
train_file_path = '/home/hban0001/Documents/M4_competetion/m4_competetion/Yearly/Macro/lstm_12i7.txt'
validate_file_path = '/home/hban0001/Documents/M4_competetion/m4_competetion/Yearly/Macro/lstm_12i7v.txt'


# Custom error measure.
def sMAPELoss(z, t):
    loss = o.reduce_mean(o.abs(t - z) / (t + z)) * 2
    return loss

def L1Loss(z, t):
    loss = o.reduce_mean(o.abs(t - z))
    return loss

# Preparing training dataset.
def create_train_data():
    listOfTuplesOfInputsLabels = []

    # Reading the training dataset.
    train_df = pd.read_csv(train_file_path, nrows=10)

    float_cols = [c for c in train_df if train_df[c].dtype == "float64"]
    float32_cols = {c: np.float32 for c in float_cols}

    train_df = pd.read_csv(train_file_path, sep=" ", header=None, engine='c', dtype=float32_cols)

    train_df = train_df.rename(columns={0: 'series'})

    # Returns unique number of time series in the dataset.
    series = np.unique(train_df['series'])

    print(len(series))

    # Construct input and output training tuples for each time series.
    for ser in series:
        oneSeries_df = train_df[train_df['series'] == ser]
        inputs_df = oneSeries_df.iloc[:, range(1, (INPUT_SIZE + 1))]
        labels_df = oneSeries_df.iloc[:, range((INPUT_SIZE + 2), (INPUT_SIZE + OUTPUT_SIZE + 2))]
        tup = (np.ascontiguousarray(inputs_df, dtype=np.float32), np.ascontiguousarray(labels_df, dtype=np.float32))
        listOfTuplesOfInputsLabels.append(tup)

    listOfTestTuples = []
    listOfTestInputs = []
    listOfTestLabels = []

    # Reading the validation dataset.
    val_df = pd.read_csv(validate_file_path, nrows=10)

    float_cols = [c for c in val_df if val_df[c].dtype == "float64"]
    float32_cols = {c: np.float32 for c in float_cols}

    val_df = pd.read_csv(validate_file_path, sep=" ", header=None, engine='c', dtype=float32_cols)

    val_df = val_df.rename(columns={0: 'series'})
    val_df = val_df.rename(columns={(INPUT_SIZE + OUTPUT_SIZE + 3): 'level'})
    series = np.unique(val_df['series'])

    for ser in series:
        oneSeries_df = val_df[val_df['series'] == ser]
        inputs_df_test = oneSeries_df.iloc[:, range(1, (INPUT_SIZE + 1))]
        labels_df_test = oneSeries_df.iloc[:, range((INPUT_SIZE + 2), (INPUT_SIZE + OUTPUT_SIZE + 2))]
        trueValues_df = oneSeries_df.iloc[
            oneSeries_df.shape[0] - 1, range((INPUT_SIZE + 2), (INPUT_SIZE + OUTPUT_SIZE + 2))]
        tup = (
            np.ascontiguousarray(inputs_df_test, dtype=np.float32), 
            np.ascontiguousarray(labels_df_test, dtype=np.float32),
            np.ascontiguousarray(trueValues_df, dtype=np.float32),
            )
        listOfTestTuples.append(tup)
        listOfTestInputs.append(tup[0])
        listOfTestLabels.append(tup[1])

    return listOfTuplesOfInputsLabels, listOfTestTuples, listOfTestInputs


def train_model(learningRate, lstmCellDimension, mbSize, maxEpochSize, maxNumOfEpochs,l2_regularization,
                    gaussianNoise):

    input = o.sequence.input_variable((INPUT_SIZE), np.float32)
    label = o.sequence.input_variable((OUTPUT_SIZE), np.float32)

    netout = Sequential([For(range(2), lambda i: Recurrence(
        LSTM(int(lstmCellDimension), use_peepholes=LSTM_USE_PEEPHOLES,enable_self_stabilization=LSTM_USE_STABILIZATION))),
                         Dense(OUTPUT_SIZE, bias=BIAS)])(input)


    ce = L1Loss(netout, label)
    #em = sMAPELoss(o.exp(netout), o.exp(label))

    lr_schedule = cntk.learning_parameter_schedule(learningRate)
    learner = cntk.adagrad(netout.parameters, lr=lr_schedule, l2_regularization_weight=l2_regularization,
                           gaussian_noise_injection_std_dev=gaussianNoise)
    progress_printer = ProgressPrinter(1)
    trainer = Trainer(netout, ce, learner, progress_printer)


    INFO_FREQ = 1;
    sMAPE_final_list = []
    epsilon = 0.1

    for iscan in range(int(maxNumOfEpochs)):
        sMAPE_epoch_list = []
        print("Epoch->", iscan)
        random.shuffle(listofTuplesOfInputsLabels)
        numberOfTimeseries = 0
        listOfInputs = []; listOfLabels = []

        for epochsize in range(int(maxEpochSize)):
            sMAPE_list = []
            for isseries in range(len(listofTuplesOfInputsLabels)):
                series = listofTuplesOfInputsLabels[isseries]
                listOfInputs.append(series[0])
                listOfLabels.append(series[1])
                numberOfTimeseries += 1
                if numberOfTimeseries >= int(mbSize) or isseries == len(listofTuplesOfInputsLabels) - 1:
                    trainer.train_minibatch({input: listOfInputs, label: listOfLabels})
                    numberOfTimeseries=0
                    listOfInputs = []; listOfLabels = []

            if iscan % INFO_FREQ == 0:

                test_output = trainer.model.eval({input: listOfTestInputs})

                for il in range(len(test_output)):
                    series = listOfTestTuples[il]
                    oneTestOut = test_output[il]
                    lastOneTestOutput = oneTestOut[oneTestOut.shape[0] - 1, ]
                    testOutputUnwind = (lastOneTestOutput)
                    trueValues = series[2][range(series[2].shape[0] - OUTPUT_SIZE, series[2].shape[0])]
                    actualValue = (trueValues)
                    summ = np.maximum(np.abs(actualValue) + np.abs(testOutputUnwind) + epsilon, 0.5 + epsilon)
                    sMAPE = np.abs(testOutputUnwind - actualValue) / summ * 2.0
                    sMAPE_list.append(sMAPE)

            sMAPEprint = np.mean(sMAPE_list)
            sMAPE_epoch_list.append(sMAPEprint)

        sMAPE_validation = np.mean(sMAPE_epoch_list)
        sMAPE_final_list.append(sMAPE_validation)

    sMAPE_final = np.mean(sMAPE_final_list)
    max_value= 1/(sMAPE_final)

    return max_value


if __name__ == '__main__':
    cntk.device.try_set_default_device(cpu())
    np.random.seed(1235)
    random.seed(1235)
    cntk.cntk_py.set_fixed_random_seed(1235)
    cntk.cntk_py.force_deterministic_algorithms()  # force_deterministic_algorithms(true)

    init_points = 4
    num_iter = 2

    listofTuplesOfInputsLabels, listOfTestTuples, listOfTestInputs = create_train_data()

    lstmBaysian = BayesianOptimization(train_model, {'learningRate': (1e-6, 8e-6),
                                                     'lstmCellDimension': (50, 100),
                                                     'mbSize': (50,80),
                                                     'maxEpochSize': (1, 2),
                                                     'maxNumOfEpochs': (2, 5),
                                                     'l2_regularization': (0.0001, 0.0008),
                                                     'gaussianNoise': (0.0001, 0.0008)})

    lstmBaysian.maximize(init_points=init_points, n_iter=num_iter)
    print(lstmBaysian.res['max'])
