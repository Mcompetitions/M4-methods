import numpy as np
import pandas as pd
import random
import math as m

import sys
import os
import csv

from cntk.device import *
from cntk import Trainer
from cntk.layers import *
from cntk.layers.typing import *
from cntk.learners import *
from cntk.ops import *
from cntk.logging import *
from cntk.metrics import *
from cntk.losses import *
from cntk.io import *
from cntk import sequence

import cntk
import cntk.ops as o
import cntk.layers as l

from _cntk_py import set_fixed_random_seed, force_deterministic_algorithms

# Input/Output Window size.
INPUT_SIZE = 17
OUTPUT_SIZE = 14


# LSTM specific configurations.
LSTM_USE_PEEPHOLES = True
LSTM_USE_STABILIZATION = True
BIAS = False

# Training and Validation file paths.
train_file_path = '/home/hban0001/Documents/M4_competetion/m4_competetion/Yearly/Industry/lstm_12i7v.txt'
validate_file_path = '/home/hban0001/Documents/M4_competetion/m4_competetion/Yearly/Industry/lstm_12i7v.txt'
test_file_path = '/home/hban0001/Documents/M4_competetion/m4_competetion/Yearly/Industry_Test/Industry_Test.txt'


# Custom error measure.
def sMAPELoss(z, t):
    loss = o.reduce_mean(o.abs(t - z) / (t + z)) * 2
    return loss

def L1Loss(z, t):
    loss = o.reduce_mean(o.abs(t - z))
    return loss

# Preparing training dataset.
def create_train_data():
    listOfTuplesOfInputsLabels = []

    # Reading the training dataset.
    train_df = pd.read_csv(train_file_path, nrows=10)

    float_cols = [c for c in train_df if train_df[c].dtype == "float64"]
    float32_cols = {c: np.float32 for c in float_cols}

    train_df = pd.read_csv(train_file_path, sep=" ", header=None, engine='c', dtype=float32_cols)

    train_df = train_df.rename(columns={0: 'series'})

    # Returns unique number of time series in the dataset.
    series = np.unique(train_df['series'])

    print(len(series))

    # Construct input and output training tuples for each time series.
    for ser in series:
        oneSeries_df = train_df[train_df['series'] == ser]
        inputs_df = oneSeries_df.iloc[:, range(1, (INPUT_SIZE + 1))]
        labels_df = oneSeries_df.iloc[:, range((INPUT_SIZE + 2), (INPUT_SIZE + OUTPUT_SIZE + 2))]
        tup = (np.ascontiguousarray(inputs_df, dtype=np.float32), np.ascontiguousarray(labels_df, dtype=np.float32))
        listOfTuplesOfInputsLabels.append(tup)

    #############################################
    # Reading the test file.
    testInputs = []

    test_df = pd.read_csv(test_file_path, nrows=10)

    float_cols = [c for c in test_df if test_df[c].dtype == "float64"]
    float32_cols = {c: np.float32 for c in float_cols}

    test_df = pd.read_csv(test_file_path, sep=" ", header=None, engine='c', dtype=float32_cols)

    test_df = test_df.rename(columns={0: 'series'})

    series1 = np.unique(test_df['series'])

    print(len(series))

    for ser in series1:
        test_series_df = test_df[test_df['series'] == ser]
        test_inputs_df = test_series_df.iloc[:, range(1, (INPUT_SIZE + 1))]
        test_tup = (np.ascontiguousarray(test_inputs_df, dtype=np.float32))
        testInputs.append(test_tup[0])

    return listOfTuplesOfInputsLabels, testInputs


# Training the time series
def train_model(listofTuplesOfInputsLabels, testInputs):

    maxNumOfEpochs = 3
    maxEpochSize = 2.0
    learningRate =  4.823727683398676e-06
    lstmCellDimension = 51
    l2_regularization =  0.0005360547925753057
    gaussianNoise = 0.00012784988716864869
    mbSize =400

    input = o.sequence.input_variable((INPUT_SIZE), np.float32)
    label = o.sequence.input_variable((OUTPUT_SIZE), np.float32)

    netout = Sequential([For(range(2), lambda i: Recurrence(
        LSTM(int(lstmCellDimension), use_peepholes=LSTM_USE_PEEPHOLES,
             enable_self_stabilization=LSTM_USE_STABILIZATION))),
                         Dense(OUTPUT_SIZE, bias=BIAS)])(input)

    ce = L1Loss(netout, label)
    #em = sMAPELoss(o.exp(netout), o.exp(label))

    lr_schedule = cntk.learning_parameter_schedule(learningRate)
    learner = cntk.adagrad(netout.parameters, lr=lr_schedule, l2_regularization_weight=l2_regularization,
                           gaussian_noise_injection_std_dev=gaussianNoise)

    progress_printer = ProgressPrinter(1)
    trainer = Trainer(netout, ce, learner, progress_printer)

    for iscan in range(int(maxNumOfEpochs)):
        print("Epoch->", iscan)
        random.shuffle(listofTuplesOfInputsLabels)
        numberOfTimeseries = 0
        listOfInputs = [];
        listOfLabels = []

        for epochsize in range(int(maxEpochSize)):
            for isseries in range(len(listofTuplesOfInputsLabels)):
                series = listofTuplesOfInputsLabels[isseries]
                listOfInputs.append(series[0])
                listOfLabels.append(series[1])
                numberOfTimeseries += 1
                if numberOfTimeseries >= int(mbSize) or isseries == len(listofTuplesOfInputsLabels) - 1:
                    trainer.train_minibatch({input: listOfInputs, label: listOfLabels})
                    # trainer.train_minibatch(({input:listOfInputs, label:listOfLabels},newSeqList))
                    # training_loss = get_train_loss(trainer)
                    # loss.append(training_loss)
                    numberOfTimeseries = 0
                    listOfInputs = []
                    listOfLabels = []

    # Finally applying the model to test dataset.
    test_final = trainer.model.eval({input: testInputs})

    return test_final


if __name__ == '__main__':
    cntk.device.try_set_default_device(cpu())
    np.random.seed(1)
    random.seed(1)
    cntk.cntk_py.set_fixed_random_seed(1)
    cntk.cntk_py.force_deterministic_algorithms()  # force_deterministic_algorithms(true)

    listofTuplesOfInputsLabels, testInputs = create_train_data()
    test_model = train_model(listofTuplesOfInputsLabels,testInputs)

    listOfTestOutput = []

    # Writes the last test output(i.e Forecast) of each time series to a file
    for kl in range(len(test_model)):
        seriesPrint = test_model[kl]
        listvalue = seriesPrint[seriesPrint.shape[0]-1, ]
        finallistvalue = np.array(listvalue).tolist()
        listOfTestOutput.append(finallistvalue)

    with open("Daily_Industry.txt", "w") as output:
        writer = csv.writer(output, lineterminator='\n')
        writer.writerows(listOfTestOutput)
