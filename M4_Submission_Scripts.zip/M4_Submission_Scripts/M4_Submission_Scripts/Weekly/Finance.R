library(gtools)

OUTPUT_DIR<-"Finance"
dir.create(OUTPUT_DIR, recursive = T)
MODEL_DIR<-"models"

model_files<-list.files(MODEL_DIR)
model_sorted_files<-mixedsort(sort(model_files))

INPUT_SIZE_MULTIP=1.25
maxForecastHorizon=13

OUTPUT_P12=paste(OUTPUT_DIR,"lstm_12",sep='/')

if (INPUT_SIZE_MULTIP!=1) {
  inputSize=as.integer(INPUT_SIZE_MULTIP*13)
  OUTPUT_P12=paste(OUTPUT_P12,'i',inputSize,sep='')
}

for (validation in c(TRUE,FALSE)) {# 
  OUTPUT_PA12=OUTPUT_P12
  if (validation) {
    OUTPUT_PA12=paste(OUTPUT_PA12,'v',sep='')
  }
  OUTPUT_PATH12=paste(OUTPUT_PA12,'txt',sep='.')
  
  unlink(OUTPUT_PATH12)
  
  firstTime=TRUE; save12_df=NULL;

  for (idr in 60:223) {
    sav_df = NULL
    print(paste0("time series:",idr))
    rdf_path<-paste(MODEL_DIR,model_sorted_files[idr],sep='/')
    ets_model <- readRDS(rdf_path)
    
    ets_residual<-as.numeric(ets_model$errors)
    
    y<-exp(ets_residual)
    
    n=length(y)
    if (!validation) {
      n=n-maxForecastHorizon
      y=y[1:n]
    }
    
    stlAdj<-cbind(y)
    
    inputSize=as.integer(INPUT_SIZE_MULTIP*maxForecastHorizon)
    inn=inputSize
    
    for (inn in inputSize:(n-maxForecastHorizon)) {
      sav_df=data.frame(id=paste(idr,'|i',sep=''));
      
      for (ii in 1:inputSize) {
        sav_df[,paste('r',ii,sep='')]=stlAdj[inn-inputSize+ii,1]  #inputs: past values normalized by the level
      }
      
      sav_df[,'o']='|o'
      for (ii in 1:maxForecastHorizon) {
        sav_df[,paste('o',ii,sep='')]=stlAdj[inn+ii,1] #outputs: future values normalized by the level.
      }
      
      write.table(sav_df, file=OUTPUT_PATH12, row.names = F, col.names=F, sep=" ", quote=F, append = TRUE)
      
    } #steps
  }#through all series from one file
}