m4_yearly_df<-read.csv("Weekly_forecasts.txt", sep = "," ,header = TRUE)

for(idr in 2: ncol(m4_yearly_df)){
  forecast<-m4_yearly_df[,idr]
  forecast[forecast<0] <- 0
  m4_yearly_df[,idr]<-forecast
}

write.table(m4_yearly_df, file="M4_final_weekly_forecasts.txt", row.names = F, col.names=T, sep=",", quote=F)