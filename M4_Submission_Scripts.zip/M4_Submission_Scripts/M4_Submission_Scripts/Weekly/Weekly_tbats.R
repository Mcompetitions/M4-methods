library(forecast)
library(M4comp2018)
data(M4)

dir.create("models")

monthly_M4 <- Filter(function(l) l$period == "Weekly", M4)

save_df= NULL

ts_length<-vector()
forcast_horizon<-vector()
NA_values<-vector()

for(index in 1 : length(monthly_M4)){
  print(paste0("Executing time series==>",index))
  
  #time series id.
  ts_id<-monthly_M4[[index]]$st
  timeseries_df <-data.frame(ts_id)
  
  #time series type.
  time_series_type<-monthly_M4[[index]]$type
  timeseries_df[,'type']<-time_series_type
  
  #time series length.
  time_series_length<-as.numeric(monthly_M4[[index]]$n)
  timeseries_df[,'length']<-time_series_length
  ts_length<-append(ts_length,time_series_length)
  
  #time series forecasting horizon.
  time_series_horizon<-as.numeric(monthly_M4[[index]]$h)
  timeseries_df[,'horizon']<-time_series_horizon
  forcast_horizon<-append(forcast_horizon,time_series_horizon)
  
  #time series data.
  time_series_data<-as.numeric(monthly_M4[[index]]$x)
  
  #log transformation
  time_series_data<-log(time_series_data)
  
  #Checking for NAs
  number0fNA<-sum(is.na(time_series_data))
  NA_values<-append(NA_values,number0fNA)
  
  ets_model = tbats(time_series_data,seasonal.periods=c(52),use.parallel=TRUE, num.cores=2)
  
  model<-paste0("ets_",index,".rda")
  ets_model_path<-paste0("models/", model)
  
  #saves ets model.
  saveRDS(ets_model, file = ets_model_path)
  
  ets_forecast = forecast(ets_model, h= time_series_horizon)
  
  timeseries_df[,5:(5+(time_series_horizon-1))]<-as.numeric(exp(ets_forecast$mean))
  
  if(is.null(save_df)){
    save_df = timeseries_df
  }else{
    save_df = rbind(save_df,timeseries_df)
  }
}

write.table(save_df, file="M4file.ext", row.names = F, col.names=T, sep=",", quote=F)

