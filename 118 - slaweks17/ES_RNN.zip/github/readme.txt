ES-RNN programs, related script, and docs. 
M4 Forecasting Competition, 2018
Slawek Smyl, Uber.

The programs are in C++ and use Dynet - a Dynamic Graph NN system (https://github.com/clab/dynet)




