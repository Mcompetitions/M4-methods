This is Visual Studio 15 solution, with 4 projects, one for each .cc file.
Two targets are defined: Debug and RelWitDebug, which is Release with debug info, that I used normally.
You will need to update include and link paths to point to your installation of Dynet.
In x64\RelWithDebug directory you will find two example scripts to run the executables 
in conjunction with one program started interactively inside VS.