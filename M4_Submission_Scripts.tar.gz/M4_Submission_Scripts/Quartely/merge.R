m4_yearly_df<-read.csv("M4_fixed.txt", sep = "," ,header = TRUE)

m4_yearly_df_selected<-m4_yearly_df[,c(1,5: ncol(m4_yearly_df))]

m4_yearly_macro_df<-read.csv("Quartely_Macro.txt", sep = "," ,header = FALSE)

m4_yearly_micro_df<-read.csv("Quartely_Micro.txt", sep = "," ,header = FALSE)

m4_yearly_demo_df<-read.csv("Quartely_Demographic.txt", sep = "," ,header = FALSE)

m4_yearly_industry_df<-read.csv("Quartely_Industry.txt", sep = "," ,header = FALSE)

m4_yearly_fianance_df<-read.csv("Quartely_Finance.txt", sep = "," ,header = FALSE)

m4_yearly_other_df<-read.csv("Quartely_other.txt", sep = "," ,header = FALSE)

total_df<-nrow(m4_yearly_macro_df) + nrow(m4_yearly_micro_df)+ nrow(m4_yearly_demo_df)+ nrow(m4_yearly_industry_df)+ nrow(m4_yearly_fianance_df)+ nrow(m4_yearly_other_df)

combine_df<-rbind(m4_yearly_macro_df,m4_yearly_micro_df,m4_yearly_demo_df,m4_yearly_industry_df,m4_yearly_fianance_df,m4_yearly_other_df)

residual_add<-combine_df + m4_yearly_df_selected[2:ncol(m4_yearly_df_selected)] 

M4_Yearly_forecasts<-cbind(m4_yearly_df_selected[1], residual_add)

write.table(M4_Yearly_forecasts, file="Quartely_forecasts.txt", row.names = F, col.names=T, sep=",", quote=F)



