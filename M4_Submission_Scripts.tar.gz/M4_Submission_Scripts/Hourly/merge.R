m4_yearly_df<-read.csv("M4_fixed.txt", sep = "," ,header = TRUE)

m4_hourly_df_selected<-m4_yearly_df[,c(1,5: ncol(m4_yearly_df))]

m4_hourly_other_df<-read.csv("Hourly_other.txt", sep = "," ,header = FALSE)

total_df<-nrow(m4_hourly_other_df)

combine_df<-rbind(m4_hourly_other_df)

residual_add<-combine_df + m4_hourly_df_selected[2:ncol(m4_hourly_df_selected)] 

M4_Yearly_forecasts<-cbind(m4_hourly_df_selected[1], residual_add)

write.table(M4_Yearly_forecasts, file="Hourly_forecasts.txt", row.names = F, col.names=T, sep=",", quote=F)
